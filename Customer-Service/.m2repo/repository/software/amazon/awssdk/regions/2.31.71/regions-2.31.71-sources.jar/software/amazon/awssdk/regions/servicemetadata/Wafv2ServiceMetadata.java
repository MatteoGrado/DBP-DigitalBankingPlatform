/*
 * Copyright 2020-2025 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is located at
 * 
 * http://aws.amazon.com/apache2.0
 * 
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package software.amazon.awssdk.regions.servicemetadata;

import java.net.URI;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import software.amazon.awssdk.annotations.Generated;
import software.amazon.awssdk.annotations.SdkPublicApi;
import software.amazon.awssdk.regions.EndpointTag;
import software.amazon.awssdk.regions.PartitionEndpointKey;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.regions.ServiceEndpointKey;
import software.amazon.awssdk.regions.ServiceMetadata;
import software.amazon.awssdk.regions.ServicePartitionMetadata;
import software.amazon.awssdk.regions.internal.DefaultServicePartitionMetadata;
import software.amazon.awssdk.regions.internal.util.ServiceMetadataUtils;
import software.amazon.awssdk.utils.ImmutableMap;
import software.amazon.awssdk.utils.Pair;

@Generated("software.amazon.awssdk:codegen")
@SdkPublicApi
public final class Wafv2ServiceMetadata implements ServiceMetadata {
    private static final String ENDPOINT_PREFIX = "wafv2";

    private static final List<Region> REGIONS = Collections.unmodifiableList(Arrays.asList(Region.of("af-south-1"),
            Region.of("ap-east-1"), Region.of("ap-northeast-1"), Region.of("ap-northeast-2"), Region.of("ap-northeast-3"),
            Region.of("ap-south-1"), Region.of("ap-south-2"), Region.of("ap-southeast-1"), Region.of("ap-southeast-2"),
            Region.of("ap-southeast-3"), Region.of("ap-southeast-4"), Region.of("ap-southeast-5"), Region.of("ap-southeast-7"),
            Region.of("ca-central-1"), Region.of("ca-west-1"), Region.of("eu-central-1"), Region.of("eu-central-2"),
            Region.of("eu-north-1"), Region.of("eu-south-1"), Region.of("eu-south-2"), Region.of("eu-west-1"),
            Region.of("eu-west-2"), Region.of("eu-west-3"), Region.of("fips-af-south-1"), Region.of("fips-ap-east-1"),
            Region.of("fips-ap-northeast-1"), Region.of("fips-ap-northeast-2"), Region.of("fips-ap-northeast-3"),
            Region.of("fips-ap-south-1"), Region.of("fips-ap-southeast-1"), Region.of("fips-ap-southeast-2"),
            Region.of("fips-ca-central-1"), Region.of("fips-eu-central-1"), Region.of("fips-eu-north-1"),
            Region.of("fips-eu-south-1"), Region.of("fips-eu-west-1"), Region.of("fips-eu-west-2"), Region.of("fips-eu-west-3"),
            Region.of("fips-me-south-1"), Region.of("fips-sa-east-1"), Region.of("fips-us-east-1"), Region.of("fips-us-east-2"),
            Region.of("fips-us-west-1"), Region.of("fips-us-west-2"), Region.of("il-central-1"), Region.of("me-central-1"),
            Region.of("me-south-1"), Region.of("mx-central-1"), Region.of("sa-east-1"), Region.of("us-east-1"),
            Region.of("us-east-2"), Region.of("us-west-1"), Region.of("us-west-2"), Region.of("cn-north-1"),
            Region.of("cn-northwest-1"), Region.of("fips-cn-north-1"), Region.of("fips-cn-northwest-1"),
            Region.of("fips-us-gov-east-1"), Region.of("fips-us-gov-west-1"), Region.of("us-gov-east-1"),
            Region.of("us-gov-west-1")));

    private static final List<ServicePartitionMetadata> PARTITIONS = Collections.unmodifiableList(Arrays.asList(
            new DefaultServicePartitionMetadata("aws", null), new DefaultServicePartitionMetadata("aws-cn", null),
            new DefaultServicePartitionMetadata("aws-us-gov", null)));

    private static final Map<ServiceEndpointKey, String> SIGNING_REGIONS_BY_REGION = ImmutableMap
            .<ServiceEndpointKey, String> builder()
            .put(ServiceEndpointKey.builder().region(Region.of("af-south-1")).build(), "af-south-1")
            .put(ServiceEndpointKey.builder().region(Region.of("af-south-1")).tags(EndpointTag.of("fips")).build(), "af-south-1")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-east-1")).build(), "ap-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-east-1")).tags(EndpointTag.of("fips")).build(), "ap-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-1")).build(), "ap-northeast-1")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-1")).tags(EndpointTag.of("fips")).build(),
                    "ap-northeast-1")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-2")).build(), "ap-northeast-2")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-2")).tags(EndpointTag.of("fips")).build(),
                    "ap-northeast-2")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-3")).build(), "ap-northeast-3")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-3")).tags(EndpointTag.of("fips")).build(),
                    "ap-northeast-3")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-south-1")).build(), "ap-south-1")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-south-1")).tags(EndpointTag.of("fips")).build(), "ap-south-1")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-south-2")).build(), "ap-south-2")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-south-2")).tags(EndpointTag.of("fips")).build(), "ap-south-2")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-1")).build(), "ap-southeast-1")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-1")).tags(EndpointTag.of("fips")).build(),
                    "ap-southeast-1")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-2")).build(), "ap-southeast-2")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-2")).tags(EndpointTag.of("fips")).build(),
                    "ap-southeast-2")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-3")).build(), "ap-southeast-3")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-3")).tags(EndpointTag.of("fips")).build(),
                    "ap-southeast-3")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-4")).build(), "ap-southeast-4")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-4")).tags(EndpointTag.of("fips")).build(),
                    "ap-southeast-4")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-5")).build(), "ap-southeast-5")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-5")).tags(EndpointTag.of("fips")).build(),
                    "ap-southeast-5")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-7")).build(), "ap-southeast-7")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-7")).tags(EndpointTag.of("fips")).build(),
                    "ap-southeast-7")
            .put(ServiceEndpointKey.builder().region(Region.of("ca-central-1")).build(), "ca-central-1")
            .put(ServiceEndpointKey.builder().region(Region.of("ca-central-1")).tags(EndpointTag.of("fips")).build(),
                    "ca-central-1")
            .put(ServiceEndpointKey.builder().region(Region.of("ca-west-1")).build(), "ca-west-1")
            .put(ServiceEndpointKey.builder().region(Region.of("ca-west-1")).tags(EndpointTag.of("fips")).build(), "ca-west-1")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-central-1")).build(), "eu-central-1")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-central-1")).tags(EndpointTag.of("fips")).build(),
                    "eu-central-1")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-central-2")).build(), "eu-central-2")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-central-2")).tags(EndpointTag.of("fips")).build(),
                    "eu-central-2")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-north-1")).build(), "eu-north-1")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-north-1")).tags(EndpointTag.of("fips")).build(), "eu-north-1")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-south-1")).build(), "eu-south-1")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-south-1")).tags(EndpointTag.of("fips")).build(), "eu-south-1")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-south-2")).build(), "eu-south-2")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-south-2")).tags(EndpointTag.of("fips")).build(), "eu-south-2")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-1")).build(), "eu-west-1")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-1")).tags(EndpointTag.of("fips")).build(), "eu-west-1")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-2")).build(), "eu-west-2")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-2")).tags(EndpointTag.of("fips")).build(), "eu-west-2")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-3")).build(), "eu-west-3")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-3")).tags(EndpointTag.of("fips")).build(), "eu-west-3")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-af-south-1")).build(), "af-south-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ap-east-1")).build(), "ap-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ap-northeast-1")).build(), "ap-northeast-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ap-northeast-2")).build(), "ap-northeast-2")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ap-northeast-3")).build(), "ap-northeast-3")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ap-south-1")).build(), "ap-south-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ap-southeast-1")).build(), "ap-southeast-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ap-southeast-2")).build(), "ap-southeast-2")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ca-central-1")).build(), "ca-central-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-eu-central-1")).build(), "eu-central-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-eu-north-1")).build(), "eu-north-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-eu-south-1")).build(), "eu-south-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-eu-west-1")).build(), "eu-west-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-eu-west-2")).build(), "eu-west-2")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-eu-west-3")).build(), "eu-west-3")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-me-south-1")).build(), "me-south-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-sa-east-1")).build(), "sa-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-east-1")).build(), "us-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-east-2")).build(), "us-east-2")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-west-1")).build(), "us-west-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-west-2")).build(), "us-west-2")
            .put(ServiceEndpointKey.builder().region(Region.of("il-central-1")).build(), "il-central-1")
            .put(ServiceEndpointKey.builder().region(Region.of("il-central-1")).tags(EndpointTag.of("fips")).build(),
                    "il-central-1")
            .put(ServiceEndpointKey.builder().region(Region.of("me-central-1")).build(), "me-central-1")
            .put(ServiceEndpointKey.builder().region(Region.of("me-central-1")).tags(EndpointTag.of("fips")).build(),
                    "me-central-1")
            .put(ServiceEndpointKey.builder().region(Region.of("me-south-1")).build(), "me-south-1")
            .put(ServiceEndpointKey.builder().region(Region.of("me-south-1")).tags(EndpointTag.of("fips")).build(), "me-south-1")
            .put(ServiceEndpointKey.builder().region(Region.of("mx-central-1")).build(), "mx-central-1")
            .put(ServiceEndpointKey.builder().region(Region.of("mx-central-1")).tags(EndpointTag.of("fips")).build(),
                    "mx-central-1")
            .put(ServiceEndpointKey.builder().region(Region.of("sa-east-1")).build(), "sa-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("sa-east-1")).tags(EndpointTag.of("fips")).build(), "sa-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("us-east-1")).build(), "us-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("us-east-1")).tags(EndpointTag.of("fips")).build(), "us-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("us-east-2")).build(), "us-east-2")
            .put(ServiceEndpointKey.builder().region(Region.of("us-east-2")).tags(EndpointTag.of("fips")).build(), "us-east-2")
            .put(ServiceEndpointKey.builder().region(Region.of("us-west-1")).build(), "us-west-1")
            .put(ServiceEndpointKey.builder().region(Region.of("us-west-1")).tags(EndpointTag.of("fips")).build(), "us-west-1")
            .put(ServiceEndpointKey.builder().region(Region.of("us-west-2")).build(), "us-west-2")
            .put(ServiceEndpointKey.builder().region(Region.of("us-west-2")).tags(EndpointTag.of("fips")).build(), "us-west-2")
            .put(ServiceEndpointKey.builder().region(Region.of("cn-north-1")).build(), "cn-north-1")
            .put(ServiceEndpointKey.builder().region(Region.of("cn-north-1")).tags(EndpointTag.of("fips")).build(), "cn-north-1")
            .put(ServiceEndpointKey.builder().region(Region.of("cn-northwest-1")).build(), "cn-northwest-1")
            .put(ServiceEndpointKey.builder().region(Region.of("cn-northwest-1")).tags(EndpointTag.of("fips")).build(),
                    "cn-northwest-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-cn-north-1")).build(), "cn-north-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-cn-northwest-1")).build(), "cn-northwest-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-gov-east-1")).build(), "us-gov-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-gov-west-1")).build(), "us-gov-west-1")
            .put(ServiceEndpointKey.builder().region(Region.of("us-gov-east-1")).build(), "us-gov-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("us-gov-east-1")).tags(EndpointTag.of("fips")).build(),
                    "us-gov-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("us-gov-west-1")).build(), "us-gov-west-1")
            .put(ServiceEndpointKey.builder().region(Region.of("us-gov-west-1")).tags(EndpointTag.of("fips")).build(),
                    "us-gov-west-1").build();

    private static final Map<Pair<String, PartitionEndpointKey>, String> SIGNING_REGIONS_BY_PARTITION = ImmutableMap
            .<Pair<String, PartitionEndpointKey>, String> builder().build();

    private static final Map<ServiceEndpointKey, String> DNS_SUFFIXES_BY_REGION = ImmutableMap
            .<ServiceEndpointKey, String> builder().build();

    private static final Map<Pair<String, PartitionEndpointKey>, String> DNS_SUFFIXES_BY_PARTITION = ImmutableMap
            .<Pair<String, PartitionEndpointKey>, String> builder().build();

    private static final Map<ServiceEndpointKey, String> HOSTNAMES_BY_REGION = ImmutableMap
            .<ServiceEndpointKey, String> builder()
            .put(ServiceEndpointKey.builder().region(Region.of("af-south-1")).build(), "wafv2.af-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("af-south-1")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.af-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-east-1")).build(), "wafv2.ap-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-east-1")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.ap-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-1")).build(), "wafv2.ap-northeast-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-1")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.ap-northeast-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-2")).build(), "wafv2.ap-northeast-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-2")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.ap-northeast-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-3")).build(), "wafv2.ap-northeast-3.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-3")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.ap-northeast-3.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-south-1")).build(), "wafv2.ap-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-south-1")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.ap-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-south-2")).build(), "wafv2.ap-south-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-south-2")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.ap-south-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-1")).build(), "wafv2.ap-southeast-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-1")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.ap-southeast-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-2")).build(), "wafv2.ap-southeast-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-2")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.ap-southeast-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-3")).build(), "wafv2.ap-southeast-3.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-3")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.ap-southeast-3.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-4")).build(), "wafv2.ap-southeast-4.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-4")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.ap-southeast-4.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-5")).build(), "wafv2.ap-southeast-5.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-5")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.ap-southeast-5.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-7")).build(), "wafv2.ap-southeast-7.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-7")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.ap-southeast-7.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ca-central-1")).build(), "wafv2.ca-central-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ca-central-1")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.ca-central-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ca-west-1")).build(), "wafv2.ca-west-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("ca-west-1")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.ca-west-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-central-1")).build(), "wafv2.eu-central-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-central-1")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.eu-central-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-central-2")).build(), "wafv2.eu-central-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-central-2")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.eu-central-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-north-1")).build(), "wafv2.eu-north-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-north-1")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.eu-north-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-south-1")).build(), "wafv2.eu-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-south-1")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.eu-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-south-2")).build(), "wafv2.eu-south-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-south-2")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.eu-south-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-1")).build(), "wafv2.eu-west-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-1")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.eu-west-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-2")).build(), "wafv2.eu-west-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-2")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.eu-west-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-3")).build(), "wafv2.eu-west-3.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-3")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.eu-west-3.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-af-south-1")).build(), "wafv2-fips.af-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ap-east-1")).build(), "wafv2-fips.ap-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ap-northeast-1")).build(),
                    "wafv2-fips.ap-northeast-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ap-northeast-2")).build(),
                    "wafv2-fips.ap-northeast-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ap-northeast-3")).build(),
                    "wafv2-fips.ap-northeast-3.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ap-south-1")).build(), "wafv2-fips.ap-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ap-southeast-1")).build(),
                    "wafv2-fips.ap-southeast-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ap-southeast-2")).build(),
                    "wafv2-fips.ap-southeast-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ca-central-1")).build(),
                    "wafv2-fips.ca-central-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-eu-central-1")).build(),
                    "wafv2-fips.eu-central-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-eu-north-1")).build(), "wafv2-fips.eu-north-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-eu-south-1")).build(), "wafv2-fips.eu-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-eu-west-1")).build(), "wafv2-fips.eu-west-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-eu-west-2")).build(), "wafv2-fips.eu-west-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-eu-west-3")).build(), "wafv2-fips.eu-west-3.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-me-south-1")).build(), "wafv2-fips.me-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-sa-east-1")).build(), "wafv2-fips.sa-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-east-1")).build(), "wafv2-fips.us-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-east-2")).build(), "wafv2-fips.us-east-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-west-1")).build(), "wafv2-fips.us-west-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-west-2")).build(), "wafv2-fips.us-west-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("il-central-1")).build(), "wafv2.il-central-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("il-central-1")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.il-central-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("me-central-1")).build(), "wafv2.me-central-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("me-central-1")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.me-central-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("me-south-1")).build(), "wafv2.me-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("me-south-1")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.me-south-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("mx-central-1")).build(), "wafv2.mx-central-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("mx-central-1")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.mx-central-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("sa-east-1")).build(), "wafv2.sa-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("sa-east-1")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.sa-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-east-1")).build(), "wafv2.us-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-east-1")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.us-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-east-2")).build(), "wafv2.us-east-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-east-2")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.us-east-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-west-1")).build(), "wafv2.us-west-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-west-1")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.us-west-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-west-2")).build(), "wafv2.us-west-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-west-2")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.us-west-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("cn-north-1")).build(), "wafv2.cn-north-1.amazonaws.com.cn")
            .put(ServiceEndpointKey.builder().region(Region.of("cn-north-1")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.cn-north-1.amazonaws.com.cn")
            .put(ServiceEndpointKey.builder().region(Region.of("cn-northwest-1")).build(),
                    "wafv2.cn-northwest-1.amazonaws.com.cn")
            .put(ServiceEndpointKey.builder().region(Region.of("cn-northwest-1")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.cn-northwest-1.amazonaws.com.cn")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-cn-north-1")).build(),
                    "wafv2-fips.cn-north-1.amazonaws.com.cn")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-cn-northwest-1")).build(),
                    "wafv2-fips.cn-northwest-1.amazonaws.com.cn")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-gov-east-1")).build(),
                    "wafv2-fips.us-gov-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-gov-west-1")).build(),
                    "wafv2-fips.us-gov-west-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-gov-east-1")).build(), "wafv2.us-gov-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-gov-east-1")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.us-gov-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-gov-west-1")).build(), "wafv2.us-gov-west-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-gov-west-1")).tags(EndpointTag.of("fips")).build(),
                    "wafv2-fips.us-gov-west-1.amazonaws.com").build();

    private static final Map<Pair<String, PartitionEndpointKey>, String> HOSTNAMES_BY_PARTITION = ImmutableMap
            .<Pair<String, PartitionEndpointKey>, String> builder().build();

    @Override
    public List<Region> regions() {
        return REGIONS;
    }

    @Override
    public List<ServicePartitionMetadata> servicePartitions() {
        return PARTITIONS;
    }

    @Override
    public URI endpointFor(ServiceEndpointKey key) {
        return ServiceMetadataUtils.endpointFor(ServiceMetadataUtils.hostname(key, HOSTNAMES_BY_REGION, HOSTNAMES_BY_PARTITION),
                ENDPOINT_PREFIX, key.region().id(),
                ServiceMetadataUtils.dnsSuffix(key, DNS_SUFFIXES_BY_REGION, DNS_SUFFIXES_BY_PARTITION));
    }

    @Override
    public Region signingRegion(ServiceEndpointKey key) {
        return ServiceMetadataUtils.signingRegion(key, SIGNING_REGIONS_BY_REGION, SIGNING_REGIONS_BY_PARTITION);
    }
}
