/*
 * Copyright 2020-2025 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is located at
 * 
 * http://aws.amazon.com/apache2.0
 * 
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package software.amazon.awssdk.regions.servicemetadata;

import java.net.URI;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import software.amazon.awssdk.annotations.Generated;
import software.amazon.awssdk.annotations.SdkPublicApi;
import software.amazon.awssdk.regions.EndpointTag;
import software.amazon.awssdk.regions.PartitionEndpointKey;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.regions.ServiceEndpointKey;
import software.amazon.awssdk.regions.ServiceMetadata;
import software.amazon.awssdk.regions.ServicePartitionMetadata;
import software.amazon.awssdk.regions.internal.DefaultServicePartitionMetadata;
import software.amazon.awssdk.regions.internal.util.ServiceMetadataUtils;
import software.amazon.awssdk.utils.ImmutableMap;
import software.amazon.awssdk.utils.Pair;

@Generated("software.amazon.awssdk:codegen")
@SdkPublicApi
public final class ApiTunnelingIotServiceMetadata implements ServiceMetadata {
    private static final String ENDPOINT_PREFIX = "api.tunneling.iot";

    private static final List<Region> REGIONS = Collections.unmodifiableList(Arrays.asList(Region.of("ap-east-1"),
            Region.of("ap-northeast-1"), Region.of("ap-northeast-2"), Region.of("ap-south-1"), Region.of("ap-southeast-1"),
            Region.of("ap-southeast-2"), Region.of("ca-central-1"), Region.of("eu-central-1"), Region.of("eu-north-1"),
            Region.of("eu-west-1"), Region.of("eu-west-2"), Region.of("eu-west-3"), Region.of("fips-ca-central-1"),
            Region.of("fips-us-east-1"), Region.of("fips-us-east-2"), Region.of("fips-us-west-1"), Region.of("fips-us-west-2"),
            Region.of("me-central-1"), Region.of("me-south-1"), Region.of("sa-east-1"), Region.of("us-east-1"),
            Region.of("us-east-2"), Region.of("us-west-1"), Region.of("us-west-2"), Region.of("cn-north-1"),
            Region.of("cn-northwest-1"), Region.of("fips-us-gov-east-1"), Region.of("fips-us-gov-west-1"),
            Region.of("us-gov-east-1"), Region.of("us-gov-west-1")));

    private static final List<ServicePartitionMetadata> PARTITIONS = Collections.unmodifiableList(Arrays.asList(
            new DefaultServicePartitionMetadata("aws", null), new DefaultServicePartitionMetadata("aws-cn", null),
            new DefaultServicePartitionMetadata("aws-us-gov", null)));

    private static final Map<ServiceEndpointKey, String> SIGNING_REGIONS_BY_REGION = ImmutableMap
            .<ServiceEndpointKey, String> builder()
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ca-central-1")).build(), "ca-central-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-east-1")).build(), "us-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-east-2")).build(), "us-east-2")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-west-1")).build(), "us-west-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-west-2")).build(), "us-west-2")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-gov-east-1")).build(), "us-gov-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-gov-west-1")).build(), "us-gov-west-1").build();

    private static final Map<Pair<String, PartitionEndpointKey>, String> SIGNING_REGIONS_BY_PARTITION = ImmutableMap
            .<Pair<String, PartitionEndpointKey>, String> builder().build();

    private static final Map<ServiceEndpointKey, String> DNS_SUFFIXES_BY_REGION = ImmutableMap
            .<ServiceEndpointKey, String> builder().build();

    private static final Map<Pair<String, PartitionEndpointKey>, String> DNS_SUFFIXES_BY_PARTITION = ImmutableMap
            .<Pair<String, PartitionEndpointKey>, String> builder()
            .put(Pair.of("aws", PartitionEndpointKey.builder().tags(EndpointTag.of("fips")).build()), "amazonaws.com")
            .put(Pair.of("aws", PartitionEndpointKey.builder().tags(EndpointTag.of("dualstack"), EndpointTag.of("fips")).build()),
                    "api.aws")
            .put(Pair.of("aws", PartitionEndpointKey.builder().tags(EndpointTag.of("dualstack")).build()), "api.aws")
            .put(Pair.of("aws-cn", PartitionEndpointKey.builder().tags(EndpointTag.of("fips")).build()), "amazonaws.com.cn")
            .put(Pair.of("aws-cn", PartitionEndpointKey.builder().tags(EndpointTag.of("dualstack"), EndpointTag.of("fips"))
                    .build()), "api.amazonwebservices.com.cn")
            .put(Pair.of("aws-cn", PartitionEndpointKey.builder().tags(EndpointTag.of("dualstack")).build()),
                    "api.amazonwebservices.com.cn")
            .put(Pair.of("aws-us-gov", PartitionEndpointKey.builder().tags(EndpointTag.of("fips")).build()), "amazonaws.com")
            .put(Pair.of("aws-us-gov", PartitionEndpointKey.builder().tags(EndpointTag.of("dualstack"), EndpointTag.of("fips"))
                    .build()), "api.aws")
            .put(Pair.of("aws-us-gov", PartitionEndpointKey.builder().tags(EndpointTag.of("dualstack")).build()), "api.aws")
            .build();

    private static final Map<ServiceEndpointKey, String> HOSTNAMES_BY_REGION = ImmutableMap
            .<ServiceEndpointKey, String> builder()
            .put(ServiceEndpointKey.builder().region(Region.of("ap-east-1")).tags(EndpointTag.of("dualstack")).build(),
                    "api.iot-tunneling.ap-east-1.api.aws")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-1")).tags(EndpointTag.of("dualstack")).build(),
                    "api.iot-tunneling.ap-northeast-1.api.aws")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-northeast-2")).tags(EndpointTag.of("dualstack")).build(),
                    "api.iot-tunneling.ap-northeast-2.api.aws")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-south-1")).tags(EndpointTag.of("dualstack")).build(),
                    "api.iot-tunneling.ap-south-1.api.aws")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-1")).tags(EndpointTag.of("dualstack")).build(),
                    "api.iot-tunneling.ap-southeast-1.api.aws")
            .put(ServiceEndpointKey.builder().region(Region.of("ap-southeast-2")).tags(EndpointTag.of("dualstack")).build(),
                    "api.iot-tunneling.ap-southeast-2.api.aws")
            .put(ServiceEndpointKey.builder().region(Region.of("ca-central-1"))
                    .tags(EndpointTag.of("dualstack"), EndpointTag.of("fips")).build(),
                    "api.iot-tunneling-fips.ca-central-1.api.aws")
            .put(ServiceEndpointKey.builder().region(Region.of("ca-central-1")).tags(EndpointTag.of("dualstack")).build(),
                    "api.iot-tunneling.ca-central-1.api.aws")
            .put(ServiceEndpointKey.builder().region(Region.of("ca-central-1")).tags(EndpointTag.of("fips")).build(),
                    "api.tunneling.iot-fips.ca-central-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-central-1")).tags(EndpointTag.of("dualstack")).build(),
                    "api.iot-tunneling.eu-central-1.api.aws")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-north-1")).tags(EndpointTag.of("dualstack")).build(),
                    "api.iot-tunneling.eu-north-1.api.aws")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-1")).tags(EndpointTag.of("dualstack")).build(),
                    "api.iot-tunneling.eu-west-1.api.aws")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-2")).tags(EndpointTag.of("dualstack")).build(),
                    "api.iot-tunneling.eu-west-2.api.aws")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-west-3")).tags(EndpointTag.of("dualstack")).build(),
                    "api.iot-tunneling.eu-west-3.api.aws")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-ca-central-1")).build(),
                    "api.tunneling.iot-fips.ca-central-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-east-1")).build(),
                    "api.tunneling.iot-fips.us-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-east-2")).build(),
                    "api.tunneling.iot-fips.us-east-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-west-1")).build(),
                    "api.tunneling.iot-fips.us-west-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-west-2")).build(),
                    "api.tunneling.iot-fips.us-west-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("me-central-1")).tags(EndpointTag.of("dualstack")).build(),
                    "api.iot-tunneling.me-central-1.api.aws")
            .put(ServiceEndpointKey.builder().region(Region.of("me-south-1")).tags(EndpointTag.of("dualstack")).build(),
                    "api.iot-tunneling.me-south-1.api.aws")
            .put(ServiceEndpointKey.builder().region(Region.of("sa-east-1")).tags(EndpointTag.of("dualstack")).build(),
                    "api.iot-tunneling.sa-east-1.api.aws")
            .put(ServiceEndpointKey.builder().region(Region.of("us-east-1"))
                    .tags(EndpointTag.of("dualstack"), EndpointTag.of("fips")).build(),
                    "api.iot-tunneling-fips.us-east-1.api.aws")
            .put(ServiceEndpointKey.builder().region(Region.of("us-east-1")).tags(EndpointTag.of("dualstack")).build(),
                    "api.iot-tunneling.us-east-1.api.aws")
            .put(ServiceEndpointKey.builder().region(Region.of("us-east-1")).tags(EndpointTag.of("fips")).build(),
                    "api.tunneling.iot-fips.us-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-east-2"))
                    .tags(EndpointTag.of("dualstack"), EndpointTag.of("fips")).build(),
                    "api.iot-tunneling-fips.us-east-2.api.aws")
            .put(ServiceEndpointKey.builder().region(Region.of("us-east-2")).tags(EndpointTag.of("dualstack")).build(),
                    "api.iot-tunneling.us-east-2.api.aws")
            .put(ServiceEndpointKey.builder().region(Region.of("us-east-2")).tags(EndpointTag.of("fips")).build(),
                    "api.tunneling.iot-fips.us-east-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-west-1"))
                    .tags(EndpointTag.of("dualstack"), EndpointTag.of("fips")).build(),
                    "api.iot-tunneling-fips.us-west-1.api.aws")
            .put(ServiceEndpointKey.builder().region(Region.of("us-west-1")).tags(EndpointTag.of("dualstack")).build(),
                    "api.iot-tunneling.us-west-1.api.aws")
            .put(ServiceEndpointKey.builder().region(Region.of("us-west-1")).tags(EndpointTag.of("fips")).build(),
                    "api.tunneling.iot-fips.us-west-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-west-2"))
                    .tags(EndpointTag.of("dualstack"), EndpointTag.of("fips")).build(),
                    "api.iot-tunneling-fips.us-west-2.api.aws")
            .put(ServiceEndpointKey.builder().region(Region.of("us-west-2")).tags(EndpointTag.of("dualstack")).build(),
                    "api.iot-tunneling.us-west-2.api.aws")
            .put(ServiceEndpointKey.builder().region(Region.of("us-west-2")).tags(EndpointTag.of("fips")).build(),
                    "api.tunneling.iot-fips.us-west-2.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("cn-north-1")).tags(EndpointTag.of("dualstack")).build(),
                    "api.iot-tunneling.cn-north-1.api.amazonwebservices.com.cn")
            .put(ServiceEndpointKey.builder().region(Region.of("cn-northwest-1")).tags(EndpointTag.of("dualstack")).build(),
                    "api.iot-tunneling.cn-northwest-1.api.amazonwebservices.com.cn")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-gov-east-1")).build(),
                    "api.tunneling.iot-fips.us-gov-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("fips-us-gov-west-1")).build(),
                    "api.tunneling.iot-fips.us-gov-west-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-gov-east-1"))
                    .tags(EndpointTag.of("dualstack"), EndpointTag.of("fips")).build(),
                    "api.iot-tunneling-fips.us-gov-east-1.api.aws")
            .put(ServiceEndpointKey.builder().region(Region.of("us-gov-east-1")).tags(EndpointTag.of("dualstack")).build(),
                    "api.iot-tunneling.us-gov-east-1.api.aws")
            .put(ServiceEndpointKey.builder().region(Region.of("us-gov-east-1")).tags(EndpointTag.of("fips")).build(),
                    "api.tunneling.iot-fips.us-gov-east-1.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("us-gov-west-1"))
                    .tags(EndpointTag.of("dualstack"), EndpointTag.of("fips")).build(),
                    "api.iot-tunneling-fips.us-gov-west-1.api.aws")
            .put(ServiceEndpointKey.builder().region(Region.of("us-gov-west-1")).tags(EndpointTag.of("dualstack")).build(),
                    "api.iot-tunneling.us-gov-west-1.api.aws")
            .put(ServiceEndpointKey.builder().region(Region.of("us-gov-west-1")).tags(EndpointTag.of("fips")).build(),
                    "api.tunneling.iot-fips.us-gov-west-1.amazonaws.com").build();

    private static final Map<Pair<String, PartitionEndpointKey>, String> HOSTNAMES_BY_PARTITION = ImmutableMap
            .<Pair<String, PartitionEndpointKey>, String> builder()
            .put(Pair.of("aws", PartitionEndpointKey.builder().tags(EndpointTag.of("fips")).build()),
                    "api.tunneling.iot-fips.{region}.{dnsSuffix}")
            .put(Pair.of("aws", PartitionEndpointKey.builder().tags(EndpointTag.of("dualstack"), EndpointTag.of("fips")).build()),
                    "api.iot-tunneling-fips.{region}.{dnsSuffix}")
            .put(Pair.of("aws", PartitionEndpointKey.builder().tags(EndpointTag.of("dualstack")).build()),
                    "api.iot-tunneling.{region}.{dnsSuffix}")
            .put(Pair.of("aws-cn", PartitionEndpointKey.builder().tags(EndpointTag.of("fips")).build()),
                    "api.tunneling.iot-fips.{region}.{dnsSuffix}")
            .put(Pair.of("aws-cn", PartitionEndpointKey.builder().tags(EndpointTag.of("dualstack"), EndpointTag.of("fips"))
                    .build()), "api.iot-tunneling-fips.{region}.{dnsSuffix}")
            .put(Pair.of("aws-cn", PartitionEndpointKey.builder().tags(EndpointTag.of("dualstack")).build()),
                    "api.iot-tunneling.{region}.{dnsSuffix}")
            .put(Pair.of("aws-us-gov", PartitionEndpointKey.builder().tags(EndpointTag.of("fips")).build()),
                    "api.tunneling.iot-fips.{region}.{dnsSuffix}")
            .put(Pair.of("aws-us-gov", PartitionEndpointKey.builder().tags(EndpointTag.of("dualstack"), EndpointTag.of("fips"))
                    .build()), "api.iot-tunneling-fips.{region}.{dnsSuffix}")
            .put(Pair.of("aws-us-gov", PartitionEndpointKey.builder().tags(EndpointTag.of("dualstack")).build()),
                    "api.iot-tunneling.{region}.{dnsSuffix}").build();

    @Override
    public List<Region> regions() {
        return REGIONS;
    }

    @Override
    public List<ServicePartitionMetadata> servicePartitions() {
        return PARTITIONS;
    }

    @Override
    public URI endpointFor(ServiceEndpointKey key) {
        return ServiceMetadataUtils.endpointFor(ServiceMetadataUtils.hostname(key, HOSTNAMES_BY_REGION, HOSTNAMES_BY_PARTITION),
                ENDPOINT_PREFIX, key.region().id(),
                ServiceMetadataUtils.dnsSuffix(key, DNS_SUFFIXES_BY_REGION, DNS_SUFFIXES_BY_PARTITION));
    }

    @Override
    public Region signingRegion(ServiceEndpointKey key) {
        return ServiceMetadataUtils.signingRegion(key, SIGNING_REGIONS_BY_REGION, SIGNING_REGIONS_BY_PARTITION);
    }
}
