/*
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is located at
 * 
 * http://aws.amazon.com/apache2.0
 * 
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package software.amazon.awssdk.services.sts.endpoints.internal;

import java.net.URI;
import java.util.Arrays;
import java.util.concurrent.CompletableFuture;
import software.amazon.awssdk.annotations.Generated;
import software.amazon.awssdk.annotations.SdkInternalApi;
import software.amazon.awssdk.awscore.endpoints.AwsEndpointAttribute;
import software.amazon.awssdk.awscore.endpoints.authscheme.SigV4AuthScheme;
import software.amazon.awssdk.core.exception.SdkClientException;
import software.amazon.awssdk.endpoints.Endpoint;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.sts.endpoints.StsEndpointParams;
import software.amazon.awssdk.services.sts.endpoints.StsEndpointProvider;
import software.amazon.awssdk.utils.CompletableFutureUtils;
import software.amazon.awssdk.utils.Validate;

@Generated("software.amazon.awssdk:codegen")
@SdkInternalApi
public final class DefaultStsEndpointProvider implements StsEndpointProvider {
    @Override
    public CompletableFuture<Endpoint> resolveEndpoint(StsEndpointParams params) {
        Validate.notNull(params.useDualStack(), "Parameter 'UseDualStack' must not be null");
        Validate.notNull(params.useFips(), "Parameter 'UseFIPS' must not be null");
        Validate.notNull(params.useGlobalEndpoint(), "Parameter 'UseGlobalEndpoint' must not be null");
        try {
            Region region = params.region();
            String regionId = region == null ? null : region.id();
            RuleResult result = endpointRule0(params, regionId);
            if (result.canContinue()) {
                throw SdkClientException.create("Rule engine did not reach an error or endpoint result");
            }
            if (result.isError()) {
                String errorMsg = result.error();
                if (errorMsg.contains("Invalid ARN") && errorMsg.contains(":s3:::")) {
                    errorMsg += ". Use the bucket name instead of simple bucket ARNs in GetBucketLocationRequest.";
                }
                throw SdkClientException.create(errorMsg);
            }
            return CompletableFuture.completedFuture(result.endpoint());
        } catch (Exception error) {
            return CompletableFutureUtils.failedFuture(error);
        }
    }

    private static RuleResult endpointRule0(StsEndpointParams params, String region) {
        RuleResult result = endpointRule1(params, region);
        if (result.isResolved()) {
            return result;
        }
        result = endpointRule19(params);
        if (result.isResolved()) {
            return result;
        }
        result = endpointRule23(params, region);
        if (result.isResolved()) {
            return result;
        }
        return RuleResult.error("Invalid Configuration: Missing Region");
    }

    private static RuleResult endpointRule1(StsEndpointParams params, String region) {
        if (params.useGlobalEndpoint() && params.endpoint() == null && region != null) {
            RulePartition partitionResult = RulesFunctions.awsPartition(region);
            if (partitionResult != null) {
                if (!params.useFips() && !params.useDualStack()) {
                    if ("ap-northeast-1".equals(region)) {
                        return RuleResult.endpoint(Endpoint
                                .builder()
                                .url(URI.create("https://sts.amazonaws.com"))
                                .putAttribute(
                                        AwsEndpointAttribute.AUTH_SCHEMES,
                                        Arrays.asList(SigV4AuthScheme.builder().signingName("sts").signingRegion("us-east-1")
                                                .build())).build());
                    }
                    if ("ap-south-1".equals(region)) {
                        return RuleResult.endpoint(Endpoint
                                .builder()
                                .url(URI.create("https://sts.amazonaws.com"))
                                .putAttribute(
                                        AwsEndpointAttribute.AUTH_SCHEMES,
                                        Arrays.asList(SigV4AuthScheme.builder().signingName("sts").signingRegion("us-east-1")
                                                .build())).build());
                    }
                    if ("ap-southeast-1".equals(region)) {
                        return RuleResult.endpoint(Endpoint
                                .builder()
                                .url(URI.create("https://sts.amazonaws.com"))
                                .putAttribute(
                                        AwsEndpointAttribute.AUTH_SCHEMES,
                                        Arrays.asList(SigV4AuthScheme.builder().signingName("sts").signingRegion("us-east-1")
                                                .build())).build());
                    }
                    if ("ap-southeast-2".equals(region)) {
                        return RuleResult.endpoint(Endpoint
                                .builder()
                                .url(URI.create("https://sts.amazonaws.com"))
                                .putAttribute(
                                        AwsEndpointAttribute.AUTH_SCHEMES,
                                        Arrays.asList(SigV4AuthScheme.builder().signingName("sts").signingRegion("us-east-1")
                                                .build())).build());
                    }
                    if ("aws-global".equals(region)) {
                        return RuleResult.endpoint(Endpoint
                                .builder()
                                .url(URI.create("https://sts.amazonaws.com"))
                                .putAttribute(
                                        AwsEndpointAttribute.AUTH_SCHEMES,
                                        Arrays.asList(SigV4AuthScheme.builder().signingName("sts").signingRegion("us-east-1")
                                                .build())).build());
                    }
                    if ("ca-central-1".equals(region)) {
                        return RuleResult.endpoint(Endpoint
                                .builder()
                                .url(URI.create("https://sts.amazonaws.com"))
                                .putAttribute(
                                        AwsEndpointAttribute.AUTH_SCHEMES,
                                        Arrays.asList(SigV4AuthScheme.builder().signingName("sts").signingRegion("us-east-1")
                                                .build())).build());
                    }
                    if ("eu-central-1".equals(region)) {
                        return RuleResult.endpoint(Endpoint
                                .builder()
                                .url(URI.create("https://sts.amazonaws.com"))
                                .putAttribute(
                                        AwsEndpointAttribute.AUTH_SCHEMES,
                                        Arrays.asList(SigV4AuthScheme.builder().signingName("sts").signingRegion("us-east-1")
                                                .build())).build());
                    }
                    if ("eu-north-1".equals(region)) {
                        return RuleResult.endpoint(Endpoint
                                .builder()
                                .url(URI.create("https://sts.amazonaws.com"))
                                .putAttribute(
                                        AwsEndpointAttribute.AUTH_SCHEMES,
                                        Arrays.asList(SigV4AuthScheme.builder().signingName("sts").signingRegion("us-east-1")
                                                .build())).build());
                    }
                    if ("eu-west-1".equals(region)) {
                        return RuleResult.endpoint(Endpoint
                                .builder()
                                .url(URI.create("https://sts.amazonaws.com"))
                                .putAttribute(
                                        AwsEndpointAttribute.AUTH_SCHEMES,
                                        Arrays.asList(SigV4AuthScheme.builder().signingName("sts").signingRegion("us-east-1")
                                                .build())).build());
                    }
                    if ("eu-west-2".equals(region)) {
                        return RuleResult.endpoint(Endpoint
                                .builder()
                                .url(URI.create("https://sts.amazonaws.com"))
                                .putAttribute(
                                        AwsEndpointAttribute.AUTH_SCHEMES,
                                        Arrays.asList(SigV4AuthScheme.builder().signingName("sts").signingRegion("us-east-1")
                                                .build())).build());
                    }
                    if ("eu-west-3".equals(region)) {
                        return RuleResult.endpoint(Endpoint
                                .builder()
                                .url(URI.create("https://sts.amazonaws.com"))
                                .putAttribute(
                                        AwsEndpointAttribute.AUTH_SCHEMES,
                                        Arrays.asList(SigV4AuthScheme.builder().signingName("sts").signingRegion("us-east-1")
                                                .build())).build());
                    }
                    if ("sa-east-1".equals(region)) {
                        return RuleResult.endpoint(Endpoint
                                .builder()
                                .url(URI.create("https://sts.amazonaws.com"))
                                .putAttribute(
                                        AwsEndpointAttribute.AUTH_SCHEMES,
                                        Arrays.asList(SigV4AuthScheme.builder().signingName("sts").signingRegion("us-east-1")
                                                .build())).build());
                    }
                    if ("us-east-1".equals(region)) {
                        return RuleResult.endpoint(Endpoint
                                .builder()
                                .url(URI.create("https://sts.amazonaws.com"))
                                .putAttribute(
                                        AwsEndpointAttribute.AUTH_SCHEMES,
                                        Arrays.asList(SigV4AuthScheme.builder().signingName("sts").signingRegion("us-east-1")
                                                .build())).build());
                    }
                    if ("us-east-2".equals(region)) {
                        return RuleResult.endpoint(Endpoint
                                .builder()
                                .url(URI.create("https://sts.amazonaws.com"))
                                .putAttribute(
                                        AwsEndpointAttribute.AUTH_SCHEMES,
                                        Arrays.asList(SigV4AuthScheme.builder().signingName("sts").signingRegion("us-east-1")
                                                .build())).build());
                    }
                    if ("us-west-1".equals(region)) {
                        return RuleResult.endpoint(Endpoint
                                .builder()
                                .url(URI.create("https://sts.amazonaws.com"))
                                .putAttribute(
                                        AwsEndpointAttribute.AUTH_SCHEMES,
                                        Arrays.asList(SigV4AuthScheme.builder().signingName("sts").signingRegion("us-east-1")
                                                .build())).build());
                    }
                    if ("us-west-2".equals(region)) {
                        return RuleResult.endpoint(Endpoint
                                .builder()
                                .url(URI.create("https://sts.amazonaws.com"))
                                .putAttribute(
                                        AwsEndpointAttribute.AUTH_SCHEMES,
                                        Arrays.asList(SigV4AuthScheme.builder().signingName("sts").signingRegion("us-east-1")
                                                .build())).build());
                    }
                    return RuleResult.endpoint(Endpoint
                            .builder()
                            .url(URI.create("https://sts." + region + "." + partitionResult.dnsSuffix()))
                            .putAttribute(AwsEndpointAttribute.AUTH_SCHEMES,
                                    Arrays.asList(SigV4AuthScheme.builder().signingName("sts").signingRegion(region).build()))
                            .build());
                }
            }
        }
        return RuleResult.carryOn();
    }

    private static RuleResult endpointRule19(StsEndpointParams params) {
        if (params.endpoint() != null) {
            if (params.useFips()) {
                return RuleResult.error("Invalid Configuration: FIPS and custom endpoint are not supported");
            }
            if (params.useDualStack()) {
                return RuleResult.error("Invalid Configuration: Dualstack and custom endpoint are not supported");
            }
            return RuleResult.endpoint(Endpoint.builder().url(URI.create(params.endpoint())).build());
        }
        return RuleResult.carryOn();
    }

    private static RuleResult endpointRule23(StsEndpointParams params, String region) {
        if (region != null) {
            return endpointRule24(params, region);
        }
        return RuleResult.carryOn();
    }

    private static RuleResult endpointRule24(StsEndpointParams params, String region) {
        RulePartition partitionResult = RulesFunctions.awsPartition(region);
        if (partitionResult != null) {
            RuleResult result = endpointRule25(params, partitionResult, region);
            if (result.isResolved()) {
                return result;
            }
            result = endpointRule29(params, partitionResult, region);
            if (result.isResolved()) {
                return result;
            }
            result = endpointRule34(params, partitionResult, region);
            if (result.isResolved()) {
                return result;
            }
            if ("aws-global".equals(region)) {
                return RuleResult.endpoint(Endpoint
                        .builder()
                        .url(URI.create("https://sts.amazonaws.com"))
                        .putAttribute(AwsEndpointAttribute.AUTH_SCHEMES,
                                Arrays.asList(SigV4AuthScheme.builder().signingName("sts").signingRegion("us-east-1").build()))
                        .build());
            }
            return RuleResult.endpoint(Endpoint.builder()
                    .url(URI.create("https://sts." + region + "." + partitionResult.dnsSuffix())).build());
        }
        return RuleResult.carryOn();
    }

    private static RuleResult endpointRule25(StsEndpointParams params, RulePartition partitionResult, String region) {
        if (params.useFips() && params.useDualStack()) {
            RuleResult result = endpointRule26(params, partitionResult, region);
            if (result.isResolved()) {
                return result;
            }
            return RuleResult.error("FIPS and DualStack are enabled, but this partition does not support one or both");
        }
        return RuleResult.carryOn();
    }

    private static RuleResult endpointRule26(StsEndpointParams params, RulePartition partitionResult, String region) {
        if (partitionResult.supportsFIPS() && partitionResult.supportsDualStack()) {
            return RuleResult.endpoint(Endpoint.builder()
                    .url(URI.create("https://sts-fips." + region + "." + partitionResult.dualStackDnsSuffix())).build());
        }
        return RuleResult.carryOn();
    }

    private static RuleResult endpointRule29(StsEndpointParams params, RulePartition partitionResult, String region) {
        if (params.useFips()) {
            RuleResult result = endpointRule30(params, partitionResult, region);
            if (result.isResolved()) {
                return result;
            }
            return RuleResult.error("FIPS is enabled but this partition does not support FIPS");
        }
        return RuleResult.carryOn();
    }

    private static RuleResult endpointRule30(StsEndpointParams params, RulePartition partitionResult, String region) {
        if (partitionResult.supportsFIPS()) {
            if ("aws-us-gov".equals(partitionResult.name())) {
                return RuleResult
                        .endpoint(Endpoint.builder().url(URI.create("https://sts." + region + ".amazonaws.com")).build());
            }
            return RuleResult.endpoint(Endpoint.builder()
                    .url(URI.create("https://sts-fips." + region + "." + partitionResult.dnsSuffix())).build());
        }
        return RuleResult.carryOn();
    }

    private static RuleResult endpointRule34(StsEndpointParams params, RulePartition partitionResult, String region) {
        if (params.useDualStack()) {
            RuleResult result = endpointRule35(params, partitionResult, region);
            if (result.isResolved()) {
                return result;
            }
            return RuleResult.error("DualStack is enabled but this partition does not support DualStack");
        }
        return RuleResult.carryOn();
    }

    private static RuleResult endpointRule35(StsEndpointParams params, RulePartition partitionResult, String region) {
        if (partitionResult.supportsDualStack()) {
            return RuleResult.endpoint(Endpoint.builder()
                    .url(URI.create("https://sts." + region + "." + partitionResult.dualStackDnsSuffix())).build());
        }
        return RuleResult.carryOn();
    }

    @Override
    public boolean equals(Object rhs) {
        return rhs != null && getClass().equals(rhs.getClass());
    }

    @Override
    public int hashCode() {
        return getClass().hashCode();
    }
}
