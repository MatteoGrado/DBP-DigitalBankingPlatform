/*
 * Copyright (c) 2015-2025 VMware Inc. or its affiliates, All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package reactor.core.publisher;

import reactor.core.CoreSubscriber;
import reactor.util.context.Context;

/**
 *
 * @param <I> input operator consumed type
 * @param <O> output operator produced type
 *
 * @author Stephane Maldini
 */
interface InnerOperator<I, O>
		extends InnerConsumer<I>, InnerProducer<O> {

	@Override
	default Context currentContext() {
		CoreSubscriber<? super O> actual = actual();
		assert actual != null : "actual subscriber can not be null in inner operator";
		return actual.currentContext();
	}
}
