package io.sentry;

import java.lang.String;

public final class BuildConfig {
  public static final String SENTRY_JAVA_SDK_NAME = "sentry.java";

  public static final String VERSION_NAME = "8.27.0";

  private BuildConfig() {
  }
}
