package io.sentry;

import java.lang.String;

public final class BuildConfig {
  public static final String SENTRY_JAVA_SDK_NAME = "sentry.java";

  public static final String VERSION_NAME = "8.48.0";

  private BuildConfig() {
  }
}
