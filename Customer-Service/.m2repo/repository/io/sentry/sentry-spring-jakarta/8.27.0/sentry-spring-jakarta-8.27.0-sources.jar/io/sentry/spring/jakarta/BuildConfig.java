package io.sentry.spring.jakarta;

import java.lang.String;

public final class BuildConfig {
  public static final String SENTRY_SPRING_JAKARTA_SDK_NAME = "sentry.java.spring.jakarta";

  public static final String VERSION_NAME = "8.27.0";

  private BuildConfig() {
  }
}
