package io.sentry.spring.jakarta;

import java.lang.String;

public final class BuildConfig {
  public static final String SENTRY_SPRING_JAKARTA_SDK_NAME = "sentry.java.spring.jakarta";

  public static final String VERSION_NAME = "8.48.0";

  private BuildConfig() {
  }
}
