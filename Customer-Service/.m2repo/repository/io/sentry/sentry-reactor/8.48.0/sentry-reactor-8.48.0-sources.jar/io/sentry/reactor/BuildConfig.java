package io.sentry.reactor;

import java.lang.String;

public final class BuildConfig {
  public static final String SENTRY_REACTOR_SDK_NAME = "sentry.java.reactor";

  public static final String VERSION_NAME = "8.48.0";

  private BuildConfig() {
  }
}
