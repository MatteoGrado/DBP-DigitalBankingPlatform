package io.sentry.spring.boot.jakarta;

import java.lang.String;

public final class BuildConfig {
  public static final String SENTRY_SPRING_BOOT_JAKARTA_SDK_NAME = "sentry.java.spring-boot.jakarta";

  public static final String VERSION_NAME = "8.48.0";

  private BuildConfig() {
  }
}
