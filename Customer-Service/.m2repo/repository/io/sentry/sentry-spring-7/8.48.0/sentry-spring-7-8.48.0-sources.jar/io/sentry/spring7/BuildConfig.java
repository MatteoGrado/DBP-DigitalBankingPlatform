package io.sentry.spring7;

import java.lang.String;

public final class BuildConfig {
  public static final String SENTRY_SPRING_7_SDK_NAME = "sentry.java.spring-7";

  public static final String VERSION_NAME = "8.48.0";

  private BuildConfig() {
  }
}
