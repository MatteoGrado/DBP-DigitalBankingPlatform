package io.sentry.spring.boot4;

import java.lang.String;

public final class BuildConfig {
  public static final String SENTRY_SPRING_BOOT_4_SDK_NAME = "sentry.java.spring-boot-4";

  public static final String VERSION_NAME = "8.48.0";

  private BuildConfig() {
  }
}
