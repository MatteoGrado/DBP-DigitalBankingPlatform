package io.sentry.spring.boot4;

import java.lang.String;

public final class BuildConfig {
  public static final String SENTRY_SPRING_BOOT_4_SDK_NAME = "sentry.java.spring-boot-4";

  public static final String VERSION_NAME = "8.27.0";

  private BuildConfig() {
  }
}
