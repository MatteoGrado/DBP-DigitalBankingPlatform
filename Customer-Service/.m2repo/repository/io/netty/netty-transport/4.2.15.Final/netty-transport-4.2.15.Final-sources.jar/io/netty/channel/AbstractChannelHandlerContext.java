/*
 * Copyright 2012 The Netty Project
 *
 * The Netty Project licenses this file to you under the Apache License,
 * version 2.0 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at:
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */
package io.netty.channel;

import io.netty.buffer.ByteBufAllocator;
import io.netty.util.Attribute;
import io.netty.util.AttributeKey;
import io.netty.util.Recycler;
import io.netty.util.ReferenceCountUtil;
import io.netty.util.ResourceLeakHint;
import io.netty.util.concurrent.AbstractEventExecutor;
import io.netty.util.concurrent.EventExecutor;
import io.netty.util.concurrent.OrderedEventExecutor;
import io.netty.util.concurrent.PromiseNotifier;
import io.netty.util.internal.ObjectPool.Handle;
import io.netty.util.internal.ObjectUtil;
import io.netty.util.internal.PromiseNotificationUtil;
import io.netty.util.internal.StringUtil;
import io.netty.util.internal.SystemPropertyUtil;
import io.netty.util.internal.logging.InternalLogger;
import io.netty.util.internal.logging.InternalLoggerFactory;

import java.net.SocketAddress;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;

import static io.netty.channel.ChannelHandlerMask.MASK_BIND;
import static io.netty.channel.ChannelHandlerMask.MASK_CHANNEL_ACTIVE;
import static io.netty.channel.ChannelHandlerMask.MASK_CHANNEL_INACTIVE;
import static io.netty.channel.ChannelHandlerMask.MASK_CHANNEL_READ;
import static io.netty.channel.ChannelHandlerMask.MASK_CHANNEL_READ_COMPLETE;
import static io.netty.channel.ChannelHandlerMask.MASK_CHANNEL_REGISTERED;
import static io.netty.channel.ChannelHandlerMask.MASK_CHANNEL_UNREGISTERED;
import static io.netty.channel.ChannelHandlerMask.MASK_CHANNEL_WRITABILITY_CHANGED;
import static io.netty.channel.ChannelHandlerMask.MASK_CLOSE;
import static io.netty.channel.ChannelHandlerMask.MASK_CONNECT;
import static io.netty.channel.ChannelHandlerMask.MASK_DEREGISTER;
import static io.netty.channel.ChannelHandlerMask.MASK_DISCONNECT;
import static io.netty.channel.ChannelHandlerMask.MASK_EXCEPTION_CAUGHT;
import static io.netty.channel.ChannelHandlerMask.MASK_FLUSH;
import static io.netty.channel.ChannelHandlerMask.MASK_ONLY_INBOUND;
import static io.netty.channel.ChannelHandlerMask.MASK_ONLY_OUTBOUND;
import static io.netty.channel.ChannelHandlerMask.MASK_READ;
import static io.netty.channel.ChannelHandlerMask.MASK_USER_EVENT_TRIGGERED;
import static io.netty.channel.ChannelHandlerMask.MASK_WRITE;
import static io.netty.channel.ChannelHandlerMask.mask;

abstract class AbstractChannelHandlerContext implements ChannelHandlerContext, ResourceLeakHint {

    private static final InternalLogger logger = InternalLoggerFactory.getInstance(AbstractChannelHandlerContext.class);
    volatile AbstractChannelHandlerContext next;
    volatile AbstractChannelHandlerContext prev;

    private static final AtomicIntegerFieldUpdater<AbstractChannelHandlerContext> HANDLER_STATE_UPDATER =
            AtomicIntegerFieldUpdater.newUpdater(AbstractChannelHandlerContext.class, "handlerState");

    /**
     * {@link ChannelHandler#handlerAdded(ChannelHandlerContext)} is about to be called.
     */
    private static final int ADD_PENDING = 1;
    /**
     * {@link ChannelHandler#handlerAdded(ChannelHandlerContext)} was called.
     */
    private static final int ADD_COMPLETE = 2;
    /**
     * {@link ChannelHandler#handlerRemoved(ChannelHandlerContext)} was called.
     */
    private static final int REMOVE_COMPLETE = 3;
    /**
     * Neither {@link ChannelHandler#handlerAdded(ChannelHandlerContext)}
     * nor {@link ChannelHandler#handlerRemoved(ChannelHandlerContext)} was called.
     */
    private static final int INIT = 0;

    private final DefaultChannelPipeline pipeline;
    private final String name;
    private final boolean ordered;
    private final int executionMask;

    // Will be set to null if no child executor should be used, otherwise it will be set to the
    // child executor.
    final EventExecutor childExecutor;
    // Cache the concrete value for the executor() method. This method is in the hot-path,
    // and it's a profitable optimisation to avoid as many dependent-loads as possible.
    // It does not need to be volatile, because it's always the same value for a given context,
    // within the lifetime of its registration with an event loop, and deregistering will clear it.
    EventExecutor contextExecutor;
    private ChannelFuture succeededFuture;

    // Lazily instantiated tasks used to trigger events to a handler with different executor.
    // There is no need to make this volatile as at worse it will just create a few more instances then needed.
    private Tasks invokeTasks;

    private volatile int handlerState = INIT;

    AbstractChannelHandlerContext(DefaultChannelPipeline pipeline, EventExecutor executor,
                                  String name, Class<? extends ChannelHandler> handlerClass) {
        this.name = ObjectUtil.checkNotNull(name, "name");
        this.pipeline = pipeline;
        childExecutor = executor;
        executionMask = mask(handlerClass);
        // Its ordered if its driven by the EventLoop or the given Executor is an instanceof OrderedEventExecutor.
        ordered = executor == null || executor instanceof OrderedEventExecutor;
    }

    @Override
    public Channel channel() {
        return pipeline.channel();
    }

    @Override
    public ChannelPipeline pipeline() {
        return pipeline;
    }

    @Override
    public ByteBufAllocator alloc() {
        return channel().config().getAllocator();
    }

    @Override
    public EventExecutor executor() {
        EventExecutor ex = contextExecutor;
        if (ex == null) {
            contextExecutor = ex = childExecutor != null ? childExecutor : channel().eventLoop();
        }
        return ex;
    }

    @Override
    public String name() {
        return name;
    }

    @Override
    public ChannelHandlerContext fireChannelRegistered() {
        AbstractChannelHandlerContext next = findContextInbound(MASK_CHANNEL_REGISTERED);
        if (next.executor().inEventLoop()) {
            if (next.invokeHandler()) {
                try {
                    // DON'T CHANGE
                    // Duplex handlers implements both out/in interfaces causing a scalability issue
                    // see https://bugs.openjdk.org/browse/JDK-8180450
                    final ChannelHandler handler = next.handler();
                    final DefaultChannelPipeline.HeadContext headContext = pipeline.head;
                    if (handler == headContext) {
                        headContext.channelRegistered(next);
                    } else if (handler instanceof ChannelInboundHandlerAdapter) {
                        ((ChannelInboundHandlerAdapter) handler).channelRegistered(next);
                    } else {
                        ((ChannelInboundHandler) handler).channelRegistered(next);
                    }
                } catch (Throwable t) {
                    next.invokeExceptionCaught(t);
                }
            } else {
                next.fireChannelRegistered();
            }
        } else {
            next.executor().execute(this::fireChannelRegistered);
        }
        return this;
    }

    @Override
    public ChannelHandlerContext fireChannelUnregistered() {
        final AbstractChannelHandlerContext next = findContextInbound(MASK_CHANNEL_UNREGISTERED);
        if (next.executor().inEventLoop()) {
            if (next.invokeHandler()) {
                try {
                    // DON'T CHANGE
                    // Duplex handlers implements both out/in interfaces causing a scalability issue
                    // see https://bugs.openjdk.org/browse/JDK-8180450
                    final ChannelHandler handler = next.handler();
                    final DefaultChannelPipeline.HeadContext headContext = pipeline.head;
                    if (handler == headContext) {
                        headContext.channelUnregistered(next);
                    } else if (handler instanceof ChannelInboundHandlerAdapter) {
                        ((ChannelInboundHandlerAdapter) handler).channelUnregistered(next);
                    } else {
                        ((ChannelInboundHandler) handler).channelUnregistered(next);
                    }
                } catch (Throwable t) {
                    next.invokeExceptionCaught(t);
                }
            } else {
                next.fireChannelUnregistered();
            }
        } else {
            next.executor().execute(this::fireChannelUnregistered);
        }
        return this;
    }

    @Override
    public ChannelHandlerContext fireChannelActive() {
        AbstractChannelHandlerContext next = findContextInbound(MASK_CHANNEL_ACTIVE);
        if (next.executor().inEventLoop()) {
            if (next.invokeHandler()) {
                try {
                    // DON'T CHANGE
                    // Duplex handlers implements both out/in interfaces causing a scalability issue
                    // see https://bugs.openjdk.org/browse/JDK-8180450
                    final ChannelHandler handler = next.handler();
                    final DefaultChannelPipeline.HeadContext headContext = pipeline.head;
                    if (handler == headContext) {
                        headContext.channelActive(next);
                    } else if (handler instanceof ChannelInboundHandlerAdapter) {
                        ((ChannelInboundHandlerAdapter) handler).channelActive(next);
                    } else {
                        ((ChannelInboundHandler) handler).channelActive(next);
                    }
                } catch (Throwable t) {
                    next.invokeExceptionCaught(t);
                }
            } else {
                next.fireChannelActive();
            }
        } else {
            next.executor().execute(this::fireChannelActive);
        }
        return this;
    }

    @Override
    public ChannelHandlerContext fireChannelInactive() {
        AbstractChannelHandlerContext next = findContextInbound(MASK_CHANNEL_INACTIVE);
        if (next.executor().inEventLoop()) {
            if (next.invokeHandler()) {
                try {
                    // DON'T CHANGE
                    // Duplex handlers implements both out/in interfaces causing a scalability issue
                    // see https://bugs.openjdk.org/browse/JDK-8180450
                    final ChannelHandler handler = next.handler();
                    final DefaultChannelPipeline.HeadContext headContext = pipeline.head;
                    if (handler == headContext) {
                        headContext.channelInactive(next);
                    } else if (handler instanceof ChannelInboundHandlerAdapter) {
                        ((ChannelInboundHandlerAdapter) handler).channelInactive(next);
                    } else {
                        ((ChannelInboundHandler) handler).channelInactive(next);
                    }
                } catch (Throwable t) {
                    next.invokeExceptionCaught(t);
                }
            } else {
                next.fireChannelInactive();
            }
        } else {
            next.executor().execute(this::fireChannelInactive);
        }
        return this;
    }

    @Override
    public ChannelHandlerContext fireExceptionCaught(final Throwable cause) {
        AbstractChannelHandlerContext next = findContextInbound(MASK_EXCEPTION_CAUGHT);
        ObjectUtil.checkNotNull(cause, "cause");
        if (next.executor().inEventLoop()) {
            next.invokeExceptionCaught(cause);
        } else {
            try {
                next.executor().execute(() -> next.invokeExceptionCaught(cause));
            } catch (Throwable t) {
                if (logger.isWarnEnabled()) {
                    logger.warn("Failed to submit an exceptionCaught() event.", t);
                    logger.warn("The exceptionCaught() event that was failed to submit was:", cause);
                }
            }
        }
        return this;
    }

    @SuppressWarnings("deprecation")
    private void invokeExceptionCaught(final Throwable cause) {
        if (invokeHandler()) {
            try {
                handler().exceptionCaught(this, cause);
            } catch (Throwable error) {
                if (logger.isDebugEnabled()) {
                    logger.debug(
                        "An exception " +
                        "was thrown by a user handler's exceptionCaught() " +
                        "method while handling the following exception:", cause);
                } else if (logger.isWarnEnabled()) {
                    logger.warn(
                        "An exception '{}' [enable DEBUG level for full stacktrace] " +
                        "was thrown by a user handler's exceptionCaught() " +
                        "method while handling the following exception:", error, cause);
                }
            }
        } else {
            fireExceptionCaught(cause);
        }
    }

    @Override
    public ChannelHandlerContext fireUserEventTriggered(final Object event) {
        ObjectUtil.checkNotNull(event, "event");
        AbstractChannelHandlerContext next = findContextInbound(MASK_USER_EVENT_TRIGGERED);
        if (next.executor().inEventLoop()) {
            if (next.invokeHandler()) {
                try {
                    // DON'T CHANGE
                    // Duplex handlers implements both out/in interfaces causing a scalability issue
                    // see https://bugs.openjdk.org/browse/JDK-8180450
                    final ChannelHandler handler = next.handler();
                    final DefaultChannelPipeline.HeadContext headContext = pipeline.head;
                    if (handler == headContext) {
                        headContext.userEventTriggered(next, event);
                    } else if (handler instanceof ChannelInboundHandlerAdapter) {
                        ((ChannelInboundHandlerAdapter) handler).userEventTriggered(next, event);
                    } else {
                        ((ChannelInboundHandler) handler).userEventTriggered(next, event);
                    }
                } catch (Throwable t) {
                    next.invokeExceptionCaught(t);
                }
            } else {
                next.fireUserEventTriggered(event);
            }
        } else {
            next.executor().execute(() -> fireUserEventTriggered(event));
        }
        return this;
    }

    @Override
    public ChannelHandlerContext fireChannelRead(final Object msg) {
        AbstractChannelHandlerContext next = findContextInbound(MASK_CHANNEL_READ);
        if (next.executor().inEventLoop()) {
            final Object m = pipeline.touch(msg, next);
            if (next.invokeHandler()) {
                try {
                    // DON'T CHANGE
                    // Duplex handlers implements both out/in interfaces causing a scalability issue
                    // see https://bugs.openjdk.org/browse/JDK-8180450
                    final ChannelHandler handler = next.handler();
                    final DefaultChannelPipeline.HeadContext headContext = pipeline.head;
                    if (handler == headContext) {
                        headContext.channelRead(next, m);
                    } else if (handler instanceof ChannelDuplexHandler) {
                        ((ChannelDuplexHandler) handler).channelRead(next, m);
                    } else {
                        ((ChannelInboundHandler) handler).channelRead(next, m);
                    }
                } catch (Throwable t) {
                    next.invokeExceptionCaught(t);
                }
            } else {
                next.fireChannelRead(m);
            }
        } else {
            next.executor().execute(() -> fireChannelRead(msg));
        }
        return this;
    }

    @Override
    public ChannelHandlerContext fireChannelReadComplete() {
        AbstractChannelHandlerContext next = findContextInbound(MASK_CHANNEL_READ_COMPLETE);
        if (next.executor().inEventLoop()) {
            if (next.invokeHandler()) {
                try {
                    // DON'T CHANGE
                    // Duplex handlers implements both out/in interfaces causing a scalability issue
                    // see https://bugs.openjdk.org/browse/JDK-8180450
                    final ChannelHandler handler = next.handler();
                    final DefaultChannelPipeline.HeadContext headContext = pipeline.head;
                    if (handler == headContext) {
                        headContext.channelReadComplete(next);
                    } else if (handler instanceof ChannelDuplexHandler) {
                        ((ChannelDuplexHandler) handler).channelReadComplete(next);
                    } else {
                        ((ChannelInboundHandler) handler).channelReadComplete(next);
                    }
                } catch (Throwable t) {
                    next.invokeExceptionCaught(t);
                }
            } else {
                next.fireChannelReadComplete();
            }
        } else {
            next.executor().execute(getInvokeTasks().fireChannelReadCompleteTask);
        }
        return this;
    }

    @Override
    public ChannelHandlerContext fireChannelWritabilityChanged() {
        AbstractChannelHandlerContext next = findContextInbound(MASK_CHANNEL_WRITABILITY_CHANGED);
        if (next.executor().inEventLoop()) {
            if (next.invokeHandler()) {
                try {
                    // DON'T CHANGE
                    // Duplex handlers implements both out/in interfaces causing a scalability issue
                    // see https://bugs.openjdk.org/browse/JDK-8180450
                    final ChannelHandler handler = next.handler();
                    final DefaultChannelPipeline.HeadContext headContext = pipeline.head;
                    if (handler == headContext) {
                        headContext.channelWritabilityChanged(next);
                    } else if (handler instanceof ChannelInboundHandlerAdapter) {
                        ((ChannelInboundHandlerAdapter) handler).channelWritabilityChanged(next);
                    } else {
                        ((ChannelInboundHandler) handler).channelWritabilityChanged(next);
                    }
                } catch (Throwable t) {
                    next.invokeExceptionCaught(t);
                }
            } else {
                next.fireChannelWritabilityChanged();
            }
        } else {
            next.executor().execute(getInvokeTasks().fireChannelWritabilityChangedTask);
        }
        return this;
    }

    @Override
    public ChannelFuture bind(SocketAddress localAddress) {
        return bind(localAddress, newPromise());
    }

    @Override
    public ChannelFuture connect(SocketAddress remoteAddress) {
        return connect(remoteAddress, newPromise());
    }

    @Override
    public ChannelFuture connect(SocketAddress remoteAddress, SocketAddress localAddress) {
        return connect(remoteAddress, localAddress, newPromise());
    }

    @Override
    public ChannelFuture disconnect() {
        return disconnect(newPromise());
    }

    @Override
    public ChannelFuture close() {
        return close(newPromise());
    }

    @Override
    public ChannelFuture deregister() {
        return deregister(newPromise());
    }

    /**
     * If possible check if the given {@link ChannelPromise} is using the same {@link EventExecutor} as this
     * {@link ChannelHandlerContext} and if not return a new {@link ChannelPromise} that runs on the same
     * {@link EventExecutor} as this {@link ChannelHandlerContext}. The result of the new {@link ChannelPromise} is
     * cascaded to the old {@link ChannelPromise}.
     *
     * This is done to ensure that {@link ChannelFutureListener}s that are added to the {@link ChannelPromise} by an
     * {@link ChannelOutboundHandler} are executed in the same thread as the handler itself. By doing so we can
     * ensure that there are not issues even if fields etc that are stored in the handler are modified by the listener.
     */
    private ChannelPromise ensurePromiseUseCorrectExecutor(ChannelPromise promise) {
        if (promise instanceof DefaultChannelPromise && !((DefaultChannelPromise) promise).executor().inEventLoop()) {
            ChannelPromise newPromise = newPromise();
            PromiseNotifier.cascade(newPromise, promise);
            return newPromise;
        }
        return promise;
    }

    @Override
    public ChannelFuture bind(final SocketAddress localAddress, ChannelPromise promise) {
        ObjectUtil.checkNotNull(localAddress, "localAddress");
        if (isNotValidPromise(promise, false)) {
            // cancelled
            return promise;
        }

        final AbstractChannelHandlerContext next = findContextOutbound(MASK_BIND);
        EventExecutor executor = next.executor();
        if (executor.inEventLoop()) {
            if (next.invokeHandler()) {
                promise = ensurePromiseUseCorrectExecutor(promise);
                try {
                    // DON'T CHANGE
                    // Duplex handlers implements both out/in interfaces causing a scalability issue
                    // see https://bugs.openjdk.org/browse/JDK-8180450
                    final ChannelHandler handler = next.handler();
                    final DefaultChannelPipeline.HeadContext headContext = pipeline.head;
                    if (handler == headContext) {
                        headContext.bind(next, localAddress, promise);
                    } else if (handler instanceof ChannelDuplexHandler) {
                        ((ChannelDuplexHandler) handler).bind(next, localAddress, promise);
                    } else if (handler instanceof ChannelOutboundHandlerAdapter) {
                        ((ChannelOutboundHandlerAdapter) handler).bind(next, localAddress, promise);
                    } else {
                        ((ChannelOutboundHandler) handler).bind(next, localAddress, promise);
                    }
                } catch (Throwable t) {
                    notifyOutboundHandlerException(t, promise);
                }
            } else {
                next.bind(localAddress, promise);
            }
        } else {
            final ChannelPromise p = promise;
            safeExecute(executor, () -> bind(localAddress, p), promise, null, false);
        }
        return promise;
    }

    @Override
    public ChannelFuture connect(SocketAddress remoteAddress, ChannelPromise promise) {
        return connect(remoteAddress, null, promise);
    }

    @Override
    public ChannelFuture connect(
            final SocketAddress remoteAddress, final SocketAddress localAddress, ChannelPromise promise) {
        ObjectUtil.checkNotNull(remoteAddress, "remoteAddress");

        if (isNotValidPromise(promise, false)) {
            // cancelled
            return promise;
        }

        final AbstractChannelHandlerContext next = findContextOutbound(MASK_CONNECT);
        EventExecutor executor = next.executor();
        if (executor.inEventLoop()) {
            if (next.invokeHandler()) {
                promise = ensurePromiseUseCorrectExecutor(promise);
                try {
                    // DON'T CHANGE
                    // Duplex handlers implements both out/in interfaces causing a scalability issue
                    // see https://bugs.openjdk.org/browse/JDK-8180450
                    final ChannelHandler handler = next.handler();
                    final DefaultChannelPipeline.HeadContext headContext = pipeline.head;
                    if (handler == headContext) {
                        headContext.connect(next, remoteAddress, localAddress, promise);
                    } else if (handler instanceof ChannelDuplexHandler) {
                        ((ChannelDuplexHandler) handler).connect(next, remoteAddress, localAddress, promise);
                    } else if (handler instanceof ChannelOutboundHandlerAdapter) {
                        ((ChannelOutboundHandlerAdapter) handler).connect(next, remoteAddress, localAddress, promise);
                    } else {
                        ((ChannelOutboundHandler) handler).connect(next, remoteAddress, localAddress, promise);
                    }
                } catch (Throwable t) {
                    notifyOutboundHandlerException(t, promise);
                }
            } else {
                next.connect(remoteAddress, localAddress, promise);
            }
        } else {
            final ChannelPromise p = promise;
            safeExecute(executor, () -> connect(remoteAddress, localAddress, p), promise, null, false);
        }
        return promise;
    }

    @Override
    public ChannelFuture disconnect(ChannelPromise promise) {
        if (!channel().metadata().hasDisconnect()) {
            // Translate disconnect to close if the channel has no notion of disconnect-reconnect.
            // So far, UDP/IP is the only transport that has such behavior.
            return close(promise);
        }
        if (isNotValidPromise(promise, false)) {
            // cancelled
            return promise;
        }

        final AbstractChannelHandlerContext next = findContextOutbound(MASK_DISCONNECT);
        EventExecutor executor = next.executor();
        if (executor.inEventLoop()) {
            if (next.invokeHandler()) {
                promise = ensurePromiseUseCorrectExecutor(promise);
                try {
                    // DON'T CHANGE
                    // Duplex handlers implements both out/in interfaces causing a scalability issue
                    // see https://bugs.openjdk.org/browse/JDK-8180450
                    final ChannelHandler handler = next.handler();
                    final DefaultChannelPipeline.HeadContext headContext = pipeline.head;
                    if (handler == headContext) {
                        headContext.disconnect(next, promise);
                    } else if (handler instanceof ChannelDuplexHandler) {
                        ((ChannelDuplexHandler) handler).disconnect(next, promise);
                    } else if (handler instanceof ChannelOutboundHandlerAdapter) {
                        ((ChannelOutboundHandlerAdapter) handler).disconnect(next, promise);
                    } else {
                        ((ChannelOutboundHandler) handler).disconnect(next, promise);
                    }
                } catch (Throwable t) {
                    notifyOutboundHandlerException(t, promise);
                }
            } else {
                next.disconnect(promise);
            }
        } else {
            final ChannelPromise p = promise;
            safeExecute(executor, () -> disconnect(p), promise, null, false);
        }
        return promise;
    }

    @Override
    public ChannelFuture close(ChannelPromise promise) {
        if (isNotValidPromise(promise, false)) {
            // cancelled
            return promise;
        }

        final AbstractChannelHandlerContext next = findContextOutbound(MASK_CLOSE);
        EventExecutor executor = next.executor();
        if (executor.inEventLoop()) {
            if (next.invokeHandler()) {
                promise = ensurePromiseUseCorrectExecutor(promise);
                try {
                    // DON'T CHANGE
                    // Duplex handlers implements both out/in interfaces causing a scalability issue
                    // see https://bugs.openjdk.org/browse/JDK-8180450
                    final ChannelHandler handler = next.handler();
                    final DefaultChannelPipeline.HeadContext headContext = pipeline.head;
                    if (handler == headContext) {
                        headContext.close(next, promise);
                    } else if (handler instanceof ChannelDuplexHandler) {
                        ((ChannelDuplexHandler) handler).close(next, promise);
                    } else if (handler instanceof ChannelOutboundHandlerAdapter) {
                        ((ChannelOutboundHandlerAdapter) handler).close(next, promise);
                    } else {
                        ((ChannelOutboundHandler) handler).close(next, promise);
                    }
                } catch (Throwable t) {
                    notifyOutboundHandlerException(t, promise);
                }
            } else {
                next.close(promise);
            }
        } else {
            final ChannelPromise p = promise;
            safeExecute(executor, () -> close(p), promise, null, false);
        }

        return promise;
    }

    @Override
    public ChannelFuture deregister(ChannelPromise promise) {
        if (isNotValidPromise(promise, false)) {
            // cancelled
            return promise;
        }

        final AbstractChannelHandlerContext next = findContextOutbound(MASK_DEREGISTER);
        EventExecutor executor = next.executor();
        if (executor.inEventLoop()) {
            if (next.invokeHandler()) {
                promise = ensurePromiseUseCorrectExecutor(promise);
                try {
                    // DON'T CHANGE
                    // Duplex handlers implements both out/in interfaces causing a scalability issue
                    // see https://bugs.openjdk.org/browse/JDK-8180450
                    final ChannelHandler handler = next.handler();
                    final DefaultChannelPipeline.HeadContext headContext = pipeline.head;
                    if (handler == headContext) {
                        headContext.deregister(next, promise);
                    } else if (handler instanceof ChannelDuplexHandler) {
                        ((ChannelDuplexHandler) handler).deregister(next, promise);
                    } else if (handler instanceof ChannelOutboundHandlerAdapter) {
                        ((ChannelOutboundHandlerAdapter) handler).deregister(next, promise);
                    } else {
                        ((ChannelOutboundHandler) handler).deregister(next, promise);
                    }
                } catch (Throwable t) {
                    notifyOutboundHandlerException(t, promise);
                }
            } else {
                deregister(promise);
            }
        } else {
            final ChannelPromise p = promise;
            safeExecute(executor, () -> deregister(p), promise, null, false);
        }

        return promise;
    }

    @Override
    public ChannelHandlerContext read() {
        final AbstractChannelHandlerContext next = findContextOutbound(MASK_READ);
        if (next.executor().inEventLoop()) {
            if (next.invokeHandler()) {
                try {
                    // DON'T CHANGE
                    // Duplex handlers implements both out/in interfaces causing a scalability issue
                    // see https://bugs.openjdk.org/browse/JDK-8180450
                    final ChannelHandler handler = next.handler();
                    final DefaultChannelPipeline.HeadContext headContext = pipeline.head;
                    if (handler == headContext) {
                        headContext.read(next);
                    } else if (handler instanceof ChannelDuplexHandler) {
                        ((ChannelDuplexHandler) handler).read(next);
                    } else if (handler instanceof ChannelOutboundHandlerAdapter) {
                        ((ChannelOutboundHandlerAdapter) handler).read(next);
                    } else {
                        ((ChannelOutboundHandler) handler).read(next);
                    }
                } catch (Throwable t) {
                    next.invokeExceptionCaught(t);
                }
            } else {
                next.read();
            }
        } else {
            next.executor().execute(getInvokeTasks().readTask);
        }
        return this;
    }

    @Override
    public ChannelFuture write(Object msg) {
        ChannelPromise promise = newPromise();
        write(msg, false, promise);
        return promise;
    }

    @Override
    public ChannelFuture write(final Object msg, final ChannelPromise promise) {
        write(msg, false, promise);
        return promise;
    }

    @Override
    public ChannelHandlerContext flush() {
        final AbstractChannelHandlerContext next = findContextOutbound(MASK_FLUSH);
        EventExecutor executor = next.executor();
        if (executor.inEventLoop()) {
            if (next.invokeHandler()) {
                try {
                    // DON'T CHANGE
                    // Duplex handlers implements both out/in interfaces causing a scalability issue
                    // see https://bugs.openjdk.org/browse/JDK-8180450
                    final ChannelHandler handler = next.handler();
                    final DefaultChannelPipeline.HeadContext headContext = pipeline.head;
                    if (handler == headContext) {
                        headContext.flush(next);
                    } else if (handler instanceof ChannelDuplexHandler) {
                        ((ChannelDuplexHandler) handler).flush(next);
                    } else if (handler instanceof ChannelOutboundHandlerAdapter) {
                        ((ChannelOutboundHandlerAdapter) handler).flush(next);
                    } else {
                        ((ChannelOutboundHandler) handler).flush(next);
                    }
                } catch (Throwable t) {
                    next.invokeExceptionCaught(t);
                }
            } else {
                next.flush();
            }
        } else {
            safeExecute(executor, getInvokeTasks().flushTask, channel().voidPromise(), null, false);
        }
        return this;
    }

    @Override
    public ChannelFuture writeAndFlush(Object msg, ChannelPromise promise) {
        write(msg, true, promise);
        return promise;
    }

    void write(Object msg, boolean flush, ChannelPromise promise) {
        if (validateWrite(msg, promise)) {
            final AbstractChannelHandlerContext next = findContextOutbound(flush ?
                    MASK_WRITE | MASK_FLUSH : MASK_WRITE);
            final Object m = pipeline.touch(msg, next);
            EventExecutor executor = next.executor();
            if (executor.inEventLoop()) {
                if (next.invokeHandler()) {
                    promise = ensurePromiseUseCorrectExecutor(promise);
                    try {
                        // DON'T CHANGE
                        // Duplex handlers implements both out/in interfaces causing a scalability issue
                        // see https://bugs.openjdk.org/browse/JDK-8180450
                        final ChannelHandler handler = next.handler();
                        final DefaultChannelPipeline.HeadContext headContext = pipeline.head;
                        if (handler == headContext) {
                            headContext.write(next, msg, promise);
                        } else if (handler instanceof ChannelDuplexHandler) {
                            ((ChannelDuplexHandler) handler).write(next, msg, promise);
                        } else if (handler instanceof ChannelOutboundHandlerAdapter) {
                            ((ChannelOutboundHandlerAdapter) handler).write(next, msg, promise);
                        } else {
                            ((ChannelOutboundHandler) handler).write(next, msg, promise);
                        }
                    } catch (Throwable t) {
                        notifyOutboundHandlerException(t, promise);
                    }
                    if (flush) {
                        try {
                            // DON'T CHANGE
                            // Duplex handlers implements both out/in interfaces causing a scalability issue
                            // see https://bugs.openjdk.org/browse/JDK-8180450
                            final ChannelHandler handler = next.handler();
                            final DefaultChannelPipeline.HeadContext headContext = pipeline.head;
                            if (handler == headContext) {
                                headContext.flush(next);
                            } else if (handler instanceof ChannelDuplexHandler) {
                                ((ChannelDuplexHandler) handler).flush(next);
                            } else if (handler instanceof ChannelOutboundHandlerAdapter) {
                                ((ChannelOutboundHandlerAdapter) handler).flush(next);
                            } else {
                                ((ChannelOutboundHandler) handler).flush(next);
                            }
                        } catch (Throwable t) {
                            next.invokeExceptionCaught(t);
                        }
                    }
                } else {
                    next.write(msg, flush, promise);
                }
            } else {
                final WriteTask task = WriteTask.newInstance(this, m, promise, flush);
                if (!safeExecute(executor, task, promise, m, !flush)) {
                    // We failed to submit the WriteTask. We need to cancel it so we decrement the pending bytes
                    // and put it back in the Recycler for re-use later.
                    //
                    // See https://github.com/netty/netty/issues/8343.
                    task.cancel();
                }
            }
        }
    }

    private boolean validateWrite(Object msg, ChannelPromise promise) {
        ObjectUtil.checkNotNull(msg, "msg");
        try {
            if (isNotValidPromise(promise, true)) {
                ReferenceCountUtil.release(msg);
                return false; // cancelled
            }
        } catch (RuntimeException e) {
            ReferenceCountUtil.release(msg);
            throw e;
        }
        return true;
    }

    @Override
    public ChannelFuture writeAndFlush(Object msg) {
        return writeAndFlush(msg, newPromise());
    }

    private static void notifyOutboundHandlerException(Throwable cause, ChannelPromise promise) {
        // Only log if the given promise is not of type VoidChannelPromise as tryFailure(...) is expected to return
        // false.
        PromiseNotificationUtil.tryFailure(promise, cause, promise instanceof VoidChannelPromise ? null : logger);
    }

    @Override
    public ChannelPromise newPromise() {
        return new DefaultChannelPromise(channel(), executor());
    }

    @Override
    public ChannelProgressivePromise newProgressivePromise() {
        return new DefaultChannelProgressivePromise(channel(), executor());
    }

    @Override
    public ChannelFuture newSucceededFuture() {
        ChannelFuture succeededFuture = this.succeededFuture;
        if (succeededFuture == null) {
            this.succeededFuture = succeededFuture = new SucceededChannelFuture(channel(), executor());
        }
        return succeededFuture;
    }

    @Override
    public ChannelFuture newFailedFuture(Throwable cause) {
        return new FailedChannelFuture(channel(), executor(), cause);
    }

    private boolean isNotValidPromise(ChannelPromise promise, boolean allowVoidPromise) {
        ObjectUtil.checkNotNull(promise, "promise");

        if (promise.isDone()) {
            // Check if the promise was cancelled and if so signal that the processing of the operation
            // should not be performed.
            //
            // See https://github.com/netty/netty/issues/2349
            if (promise.isCancelled()) {
                return true;
            }
            throw new IllegalArgumentException("promise already done: " + promise);
        }

        if (promise.channel() != channel()) {
            throw new IllegalArgumentException(String.format(
                    "promise.channel does not match: %s (expected: %s)", promise.channel(), channel()));
        }

        if (promise.getClass() == DefaultChannelPromise.class) {
            return false;
        }

        if (!allowVoidPromise && promise instanceof VoidChannelPromise) {
            throw new IllegalArgumentException(
                    StringUtil.simpleClassName(VoidChannelPromise.class) + " not allowed for this operation");
        }

        if (promise instanceof AbstractChannel.CloseFuture) {
            throw new IllegalArgumentException(
                    StringUtil.simpleClassName(AbstractChannel.CloseFuture.class) + " not allowed in a pipeline");
        }
        return false;
    }

    private AbstractChannelHandlerContext findContextInbound(int mask) {
        AbstractChannelHandlerContext ctx = this;
        EventExecutor currentExecutor = executor();
        do {
            ctx = ctx.next;
        } while (skipContext(ctx, currentExecutor, mask, MASK_ONLY_INBOUND));
        return ctx;
    }

    private AbstractChannelHandlerContext findContextOutbound(int mask) {
        AbstractChannelHandlerContext ctx = this;
        EventExecutor currentExecutor = executor();
        do {
            ctx = ctx.prev;
        } while (skipContext(ctx, currentExecutor, mask, MASK_ONLY_OUTBOUND));
        return ctx;
    }

    private static boolean skipContext(
            AbstractChannelHandlerContext ctx, EventExecutor currentExecutor, int mask, int onlyMask) {
        // Ensure we correctly handle MASK_EXCEPTION_CAUGHT which is not included in the MASK_EXCEPTION_CAUGHT
        return (ctx.executionMask & (onlyMask | mask)) == 0 ||
                // We can only skip if the EventExecutor is the same as otherwise we need to ensure we offload
                // everything to preserve ordering.
                //
                // See https://github.com/netty/netty/issues/10067
                (ctx.executor() == currentExecutor && (ctx.executionMask & mask) == 0);
    }

    @Override
    public ChannelPromise voidPromise() {
        return channel().voidPromise();
    }

    final void setRemoved() {
        handlerState = REMOVE_COMPLETE;
    }

    final boolean setAddComplete() {
        for (;;) {
            int oldState = handlerState;
            if (oldState == REMOVE_COMPLETE) {
                return false;
            }
            // Ensure we never update when the handlerState is REMOVE_COMPLETE already.
            // oldState is usually ADD_PENDING but can also be REMOVE_COMPLETE when an EventExecutor is used that is not
            // exposing ordering guarantees.
            if (HANDLER_STATE_UPDATER.compareAndSet(this, oldState, ADD_COMPLETE)) {
                return true;
            }
        }
    }

    final void setAddPending() {
        boolean updated = HANDLER_STATE_UPDATER.compareAndSet(this, INIT, ADD_PENDING);
        assert updated; // This should always be true as it MUST be called before setAddComplete() or setRemoved().
    }

    final void callHandlerAdded() throws Exception {
        // We must call setAddComplete before calling handlerAdded. Otherwise if the handlerAdded method generates
        // any pipeline events ctx.handler() will miss them because the state will not allow it.
        if (setAddComplete()) {
            handler().handlerAdded(this);
        }
    }

    final void callHandlerRemoved() throws Exception {
        try {
            // Only call handlerRemoved(...) if we called handlerAdded(...) before.
            if (handlerState == ADD_COMPLETE) {
                handler().handlerRemoved(this);
            }
        } finally {
            // Mark the handler as removed in any case.
            setRemoved();
        }
    }

    /**
     * Makes best possible effort to detect if {@link ChannelHandler#handlerAdded(ChannelHandlerContext)} was called
     * yet. If not return {@code false} and if called or could not detect return {@code true}.
     *
     * If this method returns {@code false} we will not invoke the {@link ChannelHandler} but just forward the event.
     * This is needed as {@link DefaultChannelPipeline} may already put the {@link ChannelHandler} in the linked-list
     * but not called {@link ChannelHandler#handlerAdded(ChannelHandlerContext)}.
     */
    boolean invokeHandler() {
        // Store in local variable to reduce volatile reads.
        int handlerState = this.handlerState;
        return handlerState == ADD_COMPLETE || (!ordered && handlerState == ADD_PENDING);
    }

    @Override
    public boolean isRemoved() {
        return handlerState == REMOVE_COMPLETE;
    }

    @Override
    public <T> Attribute<T> attr(AttributeKey<T> key) {
        return channel().attr(key);
    }

    @Override
    public <T> boolean hasAttr(AttributeKey<T> key) {
        return channel().hasAttr(key);
    }

    private static boolean safeExecute(EventExecutor executor, Runnable runnable,
            ChannelPromise promise, Object msg, boolean lazy) {
        try {
            if (lazy && executor instanceof AbstractEventExecutor) {
                ((AbstractEventExecutor) executor).lazyExecute(runnable);
            } else {
                executor.execute(runnable);
            }
            return true;
        } catch (Throwable cause) {
            try {
                if (msg != null) {
                    ReferenceCountUtil.release(msg);
                }
            } finally {
                promise.setFailure(cause);
            }
            return false;
        }
    }

    @Override
    public String toHintString() {
        return '\'' + name + "' will handle the message from this point.";
    }

    @Override
    public String toString() {
        return StringUtil.simpleClassName(ChannelHandlerContext.class) + '(' + name + ", " + channel() + ')';
    }

    Tasks getInvokeTasks() {
        Tasks tasks = invokeTasks;
        if (tasks == null) {
            invokeTasks = tasks = new Tasks(this);
        }
        return tasks;
    }

    static final class WriteTask implements Runnable {
        private static final Recycler<WriteTask> RECYCLER = new Recycler<WriteTask>() {
            @Override
            protected WriteTask newObject(Handle<WriteTask> handle) {
                return new WriteTask(handle);
            }
        };

        static WriteTask newInstance(AbstractChannelHandlerContext ctx,
                Object msg, ChannelPromise promise, boolean flush) {
            WriteTask task = RECYCLER.get();
            init(task, ctx, msg, promise, flush);
            return task;
        }

        private static final boolean ESTIMATE_TASK_SIZE_ON_SUBMIT =
                SystemPropertyUtil.getBoolean("io.netty.transport.estimateSizeOnSubmit", true);

        // Assuming compressed oops, 12 bytes obj header, 4 ref fields and one int field
        private static final int WRITE_TASK_OVERHEAD =
                SystemPropertyUtil.getInt("io.netty.transport.writeTaskSizeOverhead", 32);

        private final Handle<WriteTask> handle;
        private AbstractChannelHandlerContext ctx;
        private Object msg;
        private ChannelPromise promise;
        private int size; // sign bit controls flush

        private WriteTask(Handle<WriteTask> handle) {
            this.handle = handle;
        }

        static void init(WriteTask task, AbstractChannelHandlerContext ctx,
                                   Object msg, ChannelPromise promise, boolean flush) {
            task.ctx = ctx;
            task.msg = msg;
            task.promise = promise;

            if (ESTIMATE_TASK_SIZE_ON_SUBMIT) {
                task.size = ctx.pipeline.estimatorHandle().size(msg) + WRITE_TASK_OVERHEAD;
                ctx.pipeline.incrementPendingOutboundBytes(task.size);
            } else {
                task.size = 0;
            }
            if (flush) {
                task.size |= Integer.MIN_VALUE;
            }
        }

        @Override
        public void run() {
            try {
                decrementPendingOutboundBytes();
                ctx.write(msg, size < 0, promise);
            } finally {
                recycle();
            }
        }

        void cancel() {
            try {
                decrementPendingOutboundBytes();
            } finally {
                recycle();
            }
        }

        private void decrementPendingOutboundBytes() {
            if (ESTIMATE_TASK_SIZE_ON_SUBMIT) {
                ctx.pipeline.decrementPendingOutboundBytes(size & Integer.MAX_VALUE);
            }
        }

        private void recycle() {
            // Set to null so the GC can collect them directly
            ctx = null;
            msg = null;
            promise = null;
            handle.recycle(this);
        }
    }

    static final class Tasks {
        final Runnable fireChannelReadCompleteTask;
        private final Runnable readTask;
        private final Runnable fireChannelWritabilityChangedTask;
        private final Runnable flushTask;

        Tasks(AbstractChannelHandlerContext ctx) {
            fireChannelReadCompleteTask = ctx::fireChannelReadComplete;
            readTask = ctx::read;
            fireChannelWritabilityChangedTask = ctx::fireChannelWritabilityChanged;
            flushTask = ctx::flush;
        }
    }
}
