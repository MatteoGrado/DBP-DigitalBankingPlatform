/*
 * Copyright 2013-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.cloud.gateway.server.mvc.config;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import org.jspecify.annotations.Nullable;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.core.style.ToStringCreator;
import org.springframework.http.MediaType;

@ConfigurationProperties(GatewayMvcProperties.PREFIX)
public class GatewayMvcProperties {

	/**
	 * Properties prefix.
	 */
	public static final String PREFIX = "spring.cloud.gateway.server.webmvc";

	/**
	 * List of Routes.
	 */
	@NotNull
	@Valid
	private List<RouteProperties> routes = new ArrayList<>();

	/**
	 * Map of Routes.
	 */
	@NotNull
	@Valid
	private LinkedHashMap<String, RouteProperties> routesMap = new LinkedHashMap<>();

	/**
	 * Mime-types that are streaming.
	 */
	private List<MediaType> streamingMediaTypes = Arrays.asList(MediaType.TEXT_EVENT_STREAM,
			new MediaType("application", "stream+json"), new MediaType("application", "grpc"),
			new MediaType("application", "grpc+protobuf"), new MediaType("application", "grpc+json"));

	/**
	 * Buffer size for streaming media mime-types.
	 */
	private int streamingBufferSize = 16384;

	/**
	 * Regular expression defining proxies that are trusted when they appear in a
	 * Forwarded of X-Forwarded header.
	 */
	private @Nullable String trustedProxies;

	/**
	 * Whether to add the "by" parameter to the Forwarded header.
	 */
	private boolean forwardedByEnabled = false;

	/**
	 * In the case where Spring Retry is on the classpath but you still want to use Spring
	 * Framework retry as your retry filter, set this property to true.
	 */
	private boolean useFrameworkRetryFilter = false;

	public List<RouteProperties> getRoutes() {
		return routes;
	}

	public void setRoutes(List<RouteProperties> routes) {
		this.routes = routes;
	}

	public LinkedHashMap<String, RouteProperties> getRoutesMap() {
		return routesMap;
	}

	public void setRoutesMap(LinkedHashMap<String, RouteProperties> routesMap) {
		this.routesMap = routesMap;
	}

	public List<MediaType> getStreamingMediaTypes() {
		return streamingMediaTypes;
	}

	public void setStreamingMediaTypes(List<MediaType> streamingMediaTypes) {
		this.streamingMediaTypes = streamingMediaTypes;
	}

	public boolean isUseFrameworkRetryFilter() {
		return useFrameworkRetryFilter;
	}

	public void setUseFrameworkRetryFilter(boolean useFrameworkRetryFilter) {
		this.useFrameworkRetryFilter = useFrameworkRetryFilter;
	}

	public int getStreamingBufferSize() {
		return streamingBufferSize;
	}

	public void setStreamingBufferSize(int streamingBufferSize) {
		this.streamingBufferSize = streamingBufferSize;
	}

	public @Nullable String getTrustedProxies() {
		return trustedProxies;
	}

	public void setTrustedProxies(String trustedProxies) {
		this.trustedProxies = trustedProxies;
	}

	public boolean isForwardedByEnabled() {
		return forwardedByEnabled;
	}

	public void setForwardedByEnabled(boolean forwardedByEnabled) {
		this.forwardedByEnabled = forwardedByEnabled;
	}

	@Override
	public String toString() {
		return new ToStringCreator(this).append("routes", routes)
			.append("routesMap", routesMap)
			.append("streamingMediaTypes", streamingMediaTypes)
			.append("streamingBufferSize", streamingBufferSize)
			.append("trustedProxies", trustedProxies)
			.append("forwardedByEnabled", forwardedByEnabled)
			.toString();
	}

}
