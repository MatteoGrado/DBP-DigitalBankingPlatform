/*
 * Copyright 2013-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.cloud.gateway.server.mvc.handler;

import java.io.IOException;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.client.ClientHttpResponse;

class ClientHttpResponseAdapter implements ProxyExchange.Response {

	private final ClientHttpResponse response;

	ClientHttpResponseAdapter(ClientHttpResponse response) {
		this.response = response;
	}

	@Override
	public HttpStatusCode getStatusCode() {
		try {
			return response.getStatusCode();
		}
		catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	@Override
	public HttpHeaders getHeaders() {
		return response.getHeaders();
	}

}
