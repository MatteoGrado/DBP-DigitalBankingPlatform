/*
 * Copyright 2012-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.cloud.gateway.server.mvc.common;

import java.util.Map;

import org.springframework.boot.EnvironmentPostProcessor;
import org.springframework.boot.SpringApplication;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MapPropertySource;
import org.springframework.util.StringUtils;

public class MultipartEnvironmentPostProcessor implements EnvironmentPostProcessor {

	/* for testing */ static final String MULTIPART_ENABLED_PROPERTY = "spring.servlet.multipart.enabled";

	/* for testing */ static final String MULTIPART_PROPERTY_SOURCE_NAME = "gatewayServerWebmvcMultipartPropertySource";

	@Override
	public void postProcessEnvironment(ConfigurableEnvironment environment, SpringApplication application) {
		String multipartEnabled = environment.getProperty(MULTIPART_ENABLED_PROPERTY);
		if (!StringUtils.hasText(multipartEnabled)) {
			// no user set property, set it to false.
			MapPropertySource propertySource = new MapPropertySource(MULTIPART_PROPERTY_SOURCE_NAME,
					Map.of(MULTIPART_ENABLED_PROPERTY, Boolean.FALSE));
			environment.getPropertySources().addFirst(propertySource);
		}
	}

}
