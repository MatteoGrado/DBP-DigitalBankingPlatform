/*
 * Copyright 2012-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.boot.actuate.endpoint.web.annotation;

import org.springframework.boot.actuate.endpoint.ExposableEndpoint;
import org.springframework.boot.actuate.endpoint.Operation;
import org.springframework.boot.actuate.endpoint.web.PathMappedEndpoint;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Information describing an endpoint that can be exposed over Spring MVC or Spring
 * WebFlux. Mappings should be discovered directly from {@link #getController()} and
 * {@link #getOperations()} should always return an empty collection.
 *
 * @author Phillip Webb
 * @since 2.0.0
 * @deprecated since 3.3.3 in favor of {@code @Endpoint} and {@code @WebEndpoint} support
 */
@Deprecated(since = "3.3.3", forRemoval = true)
public interface ExposableControllerEndpoint extends ExposableEndpoint<Operation>, PathMappedEndpoint {

	/**
	 * Return the source controller that contains {@link RequestMapping @RequestMapping}
	 * methods.
	 * @return the source controller
	 */
	Object getController();

}
