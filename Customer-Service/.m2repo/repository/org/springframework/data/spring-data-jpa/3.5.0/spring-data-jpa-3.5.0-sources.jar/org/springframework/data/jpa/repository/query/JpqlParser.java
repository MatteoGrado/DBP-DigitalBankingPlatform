// Generated from org/springframework/data/jpa/repository/query/Jpql.g4 by ANTLR 4.13.0
package org.springframework.data.jpa.repository.query;

/**
 * JPQL per https://jakarta.ee/specifications/persistence/3.1/jakarta-persistence-spec-3.1.html#bnf
 *
 * This is JPA BNF for JPQL. There are gaps and inconsistencies in the BNF itself, explained by other fragments of the spec.
 *
 * @see https://github.com/jakartaee/persistence/blob/master/spec/src/main/asciidoc/ch04-query-language.adoc#bnf
 * @author Greg Turnquist
 * @author Christoph Strobl
 * @since 3.1
 */

import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue"})
class JpqlParser extends Parser {
	// Customization: Suppress version check
	// static { RuntimeMetaData.checkVersion("4.13.0", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, T__3=4, T__4=5, T__5=6, T__6=7, T__7=8, T__8=9, 
		T__9=10, T__10=11, T__11=12, T__12=13, T__13=14, WS=15, ABS=16, ALL=17, 
		AND=18, ANY=19, AS=20, ASC=21, AVG=22, BETWEEN=23, BOTH=24, BY=25, CASE=26, 
		CAST=27, CEILING=28, COALESCE=29, CONCAT=30, COUNT=31, CURRENT_DATE=32, 
		CURRENT_TIME=33, CURRENT_TIMESTAMP=34, DATE=35, DATETIME=36, DELETE=37, 
		DESC=38, DISTINCT=39, DOUBLE=40, END=41, ELSE=42, EMPTY=43, ENTRY=44, 
		ESCAPE=45, EXISTS=46, EXP=47, EXTRACT=48, FALSE=49, FETCH=50, FIRST=51, 
		FLOOR=52, FLOAT=53, FROM=54, FUNCTION=55, GROUP=56, HAVING=57, IN=58, 
		INDEX=59, INNER=60, INTERSECT=61, IS=62, INTEGER=63, JOIN=64, KEY=65, 
		LAST=66, LEADING=67, LEFT=68, LENGTH=69, LIKE=70, LN=71, LOCAL=72, LOCATE=73, 
		LONG=74, LOWER=75, MAX=76, MEMBER=77, MIN=78, MOD=79, NEW=80, NOT=81, 
		NULL=82, NULLIF=83, NULLS=84, OBJECT=85, OF=86, ON=87, OR=88, ORDER=89, 
		OUTER=90, POWER=91, REGEXP=92, ROUND=93, SELECT=94, SET=95, SIGN=96, SIZE=97, 
		SOME=98, SQRT=99, SUBSTRING=100, STRING=101, SUM=102, THEN=103, TIME=104, 
		TRAILING=105, TREAT=106, TRIM=107, TRUE=108, TYPE=109, UPDATE=110, UPPER=111, 
		VALUE=112, WHEN=113, WHERE=114, EQUAL=115, NOT_EQUAL=116, CHARACTER=117, 
		IDENTIFICATION_VARIABLE=118, STRINGLITERAL=119, JAVASTRINGLITERAL=120, 
		FLOATLITERAL=121, INTLITERAL=122, LONGLITERAL=123;
	public static final int
		RULE_start = 0, RULE_ql_statement = 1, RULE_select_statement = 2, RULE_update_statement = 3, 
		RULE_delete_statement = 4, RULE_from_clause = 5, RULE_identificationVariableDeclarationOrCollectionMemberDeclaration = 6, 
		RULE_identification_variable_declaration = 7, RULE_range_variable_declaration = 8, 
		RULE_join = 9, RULE_fetch_join = 10, RULE_join_spec = 11, RULE_join_condition = 12, 
		RULE_join_association_path_expression = 13, RULE_join_collection_valued_path_expression = 14, 
		RULE_join_single_valued_path_expression = 15, RULE_collection_member_declaration = 16, 
		RULE_qualified_identification_variable = 17, RULE_map_field_identification_variable = 18, 
		RULE_single_valued_path_expression = 19, RULE_general_identification_variable = 20, 
		RULE_general_subpath = 21, RULE_simple_subpath = 22, RULE_treated_subpath = 23, 
		RULE_state_field_path_expression = 24, RULE_state_valued_path_expression = 25, 
		RULE_single_valued_object_path_expression = 26, RULE_collection_valued_path_expression = 27, 
		RULE_update_clause = 28, RULE_update_item = 29, RULE_new_value = 30, RULE_delete_clause = 31, 
		RULE_select_clause = 32, RULE_select_item = 33, RULE_select_expression = 34, 
		RULE_constructor_expression = 35, RULE_constructor_item = 36, RULE_aggregate_expression = 37, 
		RULE_where_clause = 38, RULE_groupby_clause = 39, RULE_groupby_item = 40, 
		RULE_having_clause = 41, RULE_orderby_clause = 42, RULE_orderby_item = 43, 
		RULE_nullsPrecedence = 44, RULE_subquery = 45, RULE_subquery_from_clause = 46, 
		RULE_subselect_identification_variable_declaration = 47, RULE_derived_path_expression = 48, 
		RULE_general_derived_path = 49, RULE_simple_derived_path = 50, RULE_treated_derived_path = 51, 
		RULE_derived_collection_member_declaration = 52, RULE_simple_select_clause = 53, 
		RULE_simple_select_expression = 54, RULE_scalar_expression = 55, RULE_conditional_expression = 56, 
		RULE_conditional_term = 57, RULE_conditional_factor = 58, RULE_conditional_primary = 59, 
		RULE_simple_cond_expression = 60, RULE_between_expression = 61, RULE_in_expression = 62, 
		RULE_in_item = 63, RULE_like_expression = 64, RULE_null_comparison_expression = 65, 
		RULE_empty_collection_comparison_expression = 66, RULE_collection_member_expression = 67, 
		RULE_entity_or_value_expression = 68, RULE_simple_entity_or_value_expression = 69, 
		RULE_exists_expression = 70, RULE_all_or_any_expression = 71, RULE_comparison_expression = 72, 
		RULE_comparison_operator = 73, RULE_arithmetic_expression = 74, RULE_arithmetic_term = 75, 
		RULE_arithmetic_factor = 76, RULE_arithmetic_primary = 77, RULE_string_expression = 78, 
		RULE_datetime_expression = 79, RULE_boolean_expression = 80, RULE_enum_expression = 81, 
		RULE_entity_expression = 82, RULE_simple_entity_expression = 83, RULE_entity_type_expression = 84, 
		RULE_type_discriminator = 85, RULE_functions_returning_numerics = 86, 
		RULE_functions_returning_datetime = 87, RULE_functions_returning_strings = 88, 
		RULE_trim_specification = 89, RULE_arithmetic_cast_function = 90, RULE_type_cast_function = 91, 
		RULE_string_cast_function = 92, RULE_function_invocation = 93, RULE_extract_datetime_field = 94, 
		RULE_datetime_field = 95, RULE_extract_datetime_part = 96, RULE_datetime_part = 97, 
		RULE_function_arg = 98, RULE_case_expression = 99, RULE_general_case_expression = 100, 
		RULE_when_clause = 101, RULE_simple_case_expression = 102, RULE_case_operand = 103, 
		RULE_simple_when_clause = 104, RULE_coalesce_expression = 105, RULE_nullif_expression = 106, 
		RULE_trim_character = 107, RULE_identification_variable = 108, RULE_constructor_name = 109, 
		RULE_literal = 110, RULE_input_parameter = 111, RULE_pattern_value = 112, 
		RULE_date_time_timestamp_literal = 113, RULE_entity_type_literal = 114, 
		RULE_escape_character = 115, RULE_numeric_literal = 116, RULE_boolean_literal = 117, 
		RULE_enum_literal = 118, RULE_string_literal = 119, RULE_single_valued_embeddable_object_field = 120, 
		RULE_subtype = 121, RULE_collection_valued_field = 122, RULE_single_valued_object_field = 123, 
		RULE_state_field = 124, RULE_collection_value_field = 125, RULE_entity_name = 126, 
		RULE_result_variable = 127, RULE_superquery_identification_variable = 128, 
		RULE_collection_valued_input_parameter = 129, RULE_single_valued_input_parameter = 130, 
		RULE_function_name = 131, RULE_character_valued_input_parameter = 132, 
		RULE_reserved_word = 133;
	private static String[] makeRuleNames() {
		return new String[] {
			"start", "ql_statement", "select_statement", "update_statement", "delete_statement", 
			"from_clause", "identificationVariableDeclarationOrCollectionMemberDeclaration", 
			"identification_variable_declaration", "range_variable_declaration", 
			"join", "fetch_join", "join_spec", "join_condition", "join_association_path_expression", 
			"join_collection_valued_path_expression", "join_single_valued_path_expression", 
			"collection_member_declaration", "qualified_identification_variable", 
			"map_field_identification_variable", "single_valued_path_expression", 
			"general_identification_variable", "general_subpath", "simple_subpath", 
			"treated_subpath", "state_field_path_expression", "state_valued_path_expression", 
			"single_valued_object_path_expression", "collection_valued_path_expression", 
			"update_clause", "update_item", "new_value", "delete_clause", "select_clause", 
			"select_item", "select_expression", "constructor_expression", "constructor_item", 
			"aggregate_expression", "where_clause", "groupby_clause", "groupby_item", 
			"having_clause", "orderby_clause", "orderby_item", "nullsPrecedence", 
			"subquery", "subquery_from_clause", "subselect_identification_variable_declaration", 
			"derived_path_expression", "general_derived_path", "simple_derived_path", 
			"treated_derived_path", "derived_collection_member_declaration", "simple_select_clause", 
			"simple_select_expression", "scalar_expression", "conditional_expression", 
			"conditional_term", "conditional_factor", "conditional_primary", "simple_cond_expression", 
			"between_expression", "in_expression", "in_item", "like_expression", 
			"null_comparison_expression", "empty_collection_comparison_expression", 
			"collection_member_expression", "entity_or_value_expression", "simple_entity_or_value_expression", 
			"exists_expression", "all_or_any_expression", "comparison_expression", 
			"comparison_operator", "arithmetic_expression", "arithmetic_term", "arithmetic_factor", 
			"arithmetic_primary", "string_expression", "datetime_expression", "boolean_expression", 
			"enum_expression", "entity_expression", "simple_entity_expression", "entity_type_expression", 
			"type_discriminator", "functions_returning_numerics", "functions_returning_datetime", 
			"functions_returning_strings", "trim_specification", "arithmetic_cast_function", 
			"type_cast_function", "string_cast_function", "function_invocation", 
			"extract_datetime_field", "datetime_field", "extract_datetime_part", 
			"datetime_part", "function_arg", "case_expression", "general_case_expression", 
			"when_clause", "simple_case_expression", "case_operand", "simple_when_clause", 
			"coalesce_expression", "nullif_expression", "trim_character", "identification_variable", 
			"constructor_name", "literal", "input_parameter", "pattern_value", "date_time_timestamp_literal", 
			"entity_type_literal", "escape_character", "numeric_literal", "boolean_literal", 
			"enum_literal", "string_literal", "single_valued_embeddable_object_field", 
			"subtype", "collection_valued_field", "single_valued_object_field", "state_field", 
			"collection_value_field", "entity_name", "result_variable", "superquery_identification_variable", 
			"collection_valued_input_parameter", "single_valued_input_parameter", 
			"function_name", "character_valued_input_parameter", "reserved_word"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "','", "'('", "')'", "'.'", "'>'", "'>='", "'<'", "'<='", "'+'", 
			"'-'", "'*'", "'/'", "'?'", "':'", null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, "'='"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, "WS", "ABS", "ALL", "AND", "ANY", "AS", "ASC", "AVG", 
			"BETWEEN", "BOTH", "BY", "CASE", "CAST", "CEILING", "COALESCE", "CONCAT", 
			"COUNT", "CURRENT_DATE", "CURRENT_TIME", "CURRENT_TIMESTAMP", "DATE", 
			"DATETIME", "DELETE", "DESC", "DISTINCT", "DOUBLE", "END", "ELSE", "EMPTY", 
			"ENTRY", "ESCAPE", "EXISTS", "EXP", "EXTRACT", "FALSE", "FETCH", "FIRST", 
			"FLOOR", "FLOAT", "FROM", "FUNCTION", "GROUP", "HAVING", "IN", "INDEX", 
			"INNER", "INTERSECT", "IS", "INTEGER", "JOIN", "KEY", "LAST", "LEADING", 
			"LEFT", "LENGTH", "LIKE", "LN", "LOCAL", "LOCATE", "LONG", "LOWER", "MAX", 
			"MEMBER", "MIN", "MOD", "NEW", "NOT", "NULL", "NULLIF", "NULLS", "OBJECT", 
			"OF", "ON", "OR", "ORDER", "OUTER", "POWER", "REGEXP", "ROUND", "SELECT", 
			"SET", "SIGN", "SIZE", "SOME", "SQRT", "SUBSTRING", "STRING", "SUM", 
			"THEN", "TIME", "TRAILING", "TREAT", "TRIM", "TRUE", "TYPE", "UPDATE", 
			"UPPER", "VALUE", "WHEN", "WHERE", "EQUAL", "NOT_EQUAL", "CHARACTER", 
			"IDENTIFICATION_VARIABLE", "STRINGLITERAL", "JAVASTRINGLITERAL", "FLOATLITERAL", 
			"INTLITERAL", "LONGLITERAL"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "Jpql.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public JpqlParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@SuppressWarnings("CheckReturnValue")
	public static class StartContext extends ParserRuleContext {
		public Ql_statementContext ql_statement() {
			return getRuleContext(Ql_statementContext.class,0);
		}
		public TerminalNode EOF() { return getToken(JpqlParser.EOF, 0); }
		public StartContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_start; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterStart(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitStart(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitStart(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StartContext start() throws RecognitionException {
		StartContext _localctx = new StartContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_start);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(268);
			ql_statement();
			setState(269);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Ql_statementContext extends ParserRuleContext {
		public Select_statementContext select_statement() {
			return getRuleContext(Select_statementContext.class,0);
		}
		public Update_statementContext update_statement() {
			return getRuleContext(Update_statementContext.class,0);
		}
		public Delete_statementContext delete_statement() {
			return getRuleContext(Delete_statementContext.class,0);
		}
		public Ql_statementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ql_statement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterQl_statement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitQl_statement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitQl_statement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Ql_statementContext ql_statement() throws RecognitionException {
		Ql_statementContext _localctx = new Ql_statementContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_ql_statement);
		try {
			setState(274);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case SELECT:
				enterOuterAlt(_localctx, 1);
				{
				setState(271);
				select_statement();
				}
				break;
			case UPDATE:
				enterOuterAlt(_localctx, 2);
				{
				setState(272);
				update_statement();
				}
				break;
			case DELETE:
				enterOuterAlt(_localctx, 3);
				{
				setState(273);
				delete_statement();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Select_statementContext extends ParserRuleContext {
		public Select_clauseContext select_clause() {
			return getRuleContext(Select_clauseContext.class,0);
		}
		public From_clauseContext from_clause() {
			return getRuleContext(From_clauseContext.class,0);
		}
		public Where_clauseContext where_clause() {
			return getRuleContext(Where_clauseContext.class,0);
		}
		public Groupby_clauseContext groupby_clause() {
			return getRuleContext(Groupby_clauseContext.class,0);
		}
		public Having_clauseContext having_clause() {
			return getRuleContext(Having_clauseContext.class,0);
		}
		public Orderby_clauseContext orderby_clause() {
			return getRuleContext(Orderby_clauseContext.class,0);
		}
		public Select_statementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_select_statement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSelect_statement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSelect_statement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSelect_statement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Select_statementContext select_statement() throws RecognitionException {
		Select_statementContext _localctx = new Select_statementContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_select_statement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(276);
			select_clause();
			setState(277);
			from_clause();
			setState(279);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==WHERE) {
				{
				setState(278);
				where_clause();
				}
			}

			setState(282);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==GROUP) {
				{
				setState(281);
				groupby_clause();
				}
			}

			setState(285);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==HAVING) {
				{
				setState(284);
				having_clause();
				}
			}

			setState(288);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ORDER) {
				{
				setState(287);
				orderby_clause();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Update_statementContext extends ParserRuleContext {
		public Update_clauseContext update_clause() {
			return getRuleContext(Update_clauseContext.class,0);
		}
		public Where_clauseContext where_clause() {
			return getRuleContext(Where_clauseContext.class,0);
		}
		public Update_statementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_update_statement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterUpdate_statement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitUpdate_statement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitUpdate_statement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Update_statementContext update_statement() throws RecognitionException {
		Update_statementContext _localctx = new Update_statementContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_update_statement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(290);
			update_clause();
			setState(292);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==WHERE) {
				{
				setState(291);
				where_clause();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Delete_statementContext extends ParserRuleContext {
		public Delete_clauseContext delete_clause() {
			return getRuleContext(Delete_clauseContext.class,0);
		}
		public Where_clauseContext where_clause() {
			return getRuleContext(Where_clauseContext.class,0);
		}
		public Delete_statementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_delete_statement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterDelete_statement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitDelete_statement(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitDelete_statement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Delete_statementContext delete_statement() throws RecognitionException {
		Delete_statementContext _localctx = new Delete_statementContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_delete_statement);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(294);
			delete_clause();
			setState(296);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==WHERE) {
				{
				setState(295);
				where_clause();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class From_clauseContext extends ParserRuleContext {
		public TerminalNode FROM() { return getToken(JpqlParser.FROM, 0); }
		public Identification_variable_declarationContext identification_variable_declaration() {
			return getRuleContext(Identification_variable_declarationContext.class,0);
		}
		public List<IdentificationVariableDeclarationOrCollectionMemberDeclarationContext> identificationVariableDeclarationOrCollectionMemberDeclaration() {
			return getRuleContexts(IdentificationVariableDeclarationOrCollectionMemberDeclarationContext.class);
		}
		public IdentificationVariableDeclarationOrCollectionMemberDeclarationContext identificationVariableDeclarationOrCollectionMemberDeclaration(int i) {
			return getRuleContext(IdentificationVariableDeclarationOrCollectionMemberDeclarationContext.class,i);
		}
		public From_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_from_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterFrom_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitFrom_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitFrom_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final From_clauseContext from_clause() throws RecognitionException {
		From_clauseContext _localctx = new From_clauseContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_from_clause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(298);
			match(FROM);
			setState(299);
			identification_variable_declaration();
			setState(304);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(300);
				match(T__0);
				setState(301);
				identificationVariableDeclarationOrCollectionMemberDeclaration();
				}
				}
				setState(306);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class IdentificationVariableDeclarationOrCollectionMemberDeclarationContext extends ParserRuleContext {
		public Identification_variable_declarationContext identification_variable_declaration() {
			return getRuleContext(Identification_variable_declarationContext.class,0);
		}
		public Collection_member_declarationContext collection_member_declaration() {
			return getRuleContext(Collection_member_declarationContext.class,0);
		}
		public IdentificationVariableDeclarationOrCollectionMemberDeclarationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_identificationVariableDeclarationOrCollectionMemberDeclaration; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterIdentificationVariableDeclarationOrCollectionMemberDeclaration(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitIdentificationVariableDeclarationOrCollectionMemberDeclaration(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitIdentificationVariableDeclarationOrCollectionMemberDeclaration(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IdentificationVariableDeclarationOrCollectionMemberDeclarationContext identificationVariableDeclarationOrCollectionMemberDeclaration() throws RecognitionException {
		IdentificationVariableDeclarationOrCollectionMemberDeclarationContext _localctx = new IdentificationVariableDeclarationOrCollectionMemberDeclarationContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_identificationVariableDeclarationOrCollectionMemberDeclaration);
		try {
			setState(309);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,8,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(307);
				identification_variable_declaration();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(308);
				collection_member_declaration();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Identification_variable_declarationContext extends ParserRuleContext {
		public Range_variable_declarationContext range_variable_declaration() {
			return getRuleContext(Range_variable_declarationContext.class,0);
		}
		public List<JoinContext> join() {
			return getRuleContexts(JoinContext.class);
		}
		public JoinContext join(int i) {
			return getRuleContext(JoinContext.class,i);
		}
		public List<Fetch_joinContext> fetch_join() {
			return getRuleContexts(Fetch_joinContext.class);
		}
		public Fetch_joinContext fetch_join(int i) {
			return getRuleContext(Fetch_joinContext.class,i);
		}
		public Identification_variable_declarationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_identification_variable_declaration; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterIdentification_variable_declaration(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitIdentification_variable_declaration(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitIdentification_variable_declaration(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Identification_variable_declarationContext identification_variable_declaration() throws RecognitionException {
		Identification_variable_declarationContext _localctx = new Identification_variable_declarationContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_identification_variable_declaration);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(311);
			range_variable_declaration();
			setState(316);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (((((_la - 60)) & ~0x3f) == 0 && ((1L << (_la - 60)) & 273L) != 0)) {
				{
				setState(314);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,9,_ctx) ) {
				case 1:
					{
					setState(312);
					join();
					}
					break;
				case 2:
					{
					setState(313);
					fetch_join();
					}
					break;
				}
				}
				setState(318);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Range_variable_declarationContext extends ParserRuleContext {
		public Entity_nameContext entity_name() {
			return getRuleContext(Entity_nameContext.class,0);
		}
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public Range_variable_declarationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_range_variable_declaration; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterRange_variable_declaration(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitRange_variable_declaration(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitRange_variable_declaration(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Range_variable_declarationContext range_variable_declaration() throws RecognitionException {
		Range_variable_declarationContext _localctx = new Range_variable_declarationContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_range_variable_declaration);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(319);
			entity_name();
			setState(321);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==AS) {
				{
				setState(320);
				match(AS);
				}
			}

			setState(323);
			identification_variable();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class JoinContext extends ParserRuleContext {
		public Join_specContext join_spec() {
			return getRuleContext(Join_specContext.class,0);
		}
		public Join_association_path_expressionContext join_association_path_expression() {
			return getRuleContext(Join_association_path_expressionContext.class,0);
		}
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public Join_conditionContext join_condition() {
			return getRuleContext(Join_conditionContext.class,0);
		}
		public JoinContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_join; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterJoin(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitJoin(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitJoin(this);
			else return visitor.visitChildren(this);
		}
	}

	public final JoinContext join() throws RecognitionException {
		JoinContext _localctx = new JoinContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_join);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(325);
			join_spec();
			setState(326);
			join_association_path_expression();
			setState(328);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==AS) {
				{
				setState(327);
				match(AS);
				}
			}

			setState(330);
			identification_variable();
			setState(332);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ON) {
				{
				setState(331);
				join_condition();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Fetch_joinContext extends ParserRuleContext {
		public Join_specContext join_spec() {
			return getRuleContext(Join_specContext.class,0);
		}
		public TerminalNode FETCH() { return getToken(JpqlParser.FETCH, 0); }
		public Join_association_path_expressionContext join_association_path_expression() {
			return getRuleContext(Join_association_path_expressionContext.class,0);
		}
		public Fetch_joinContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_fetch_join; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterFetch_join(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitFetch_join(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitFetch_join(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Fetch_joinContext fetch_join() throws RecognitionException {
		Fetch_joinContext _localctx = new Fetch_joinContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_fetch_join);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(334);
			join_spec();
			setState(335);
			match(FETCH);
			setState(336);
			join_association_path_expression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Join_specContext extends ParserRuleContext {
		public TerminalNode JOIN() { return getToken(JpqlParser.JOIN, 0); }
		public TerminalNode INNER() { return getToken(JpqlParser.INNER, 0); }
		public TerminalNode LEFT() { return getToken(JpqlParser.LEFT, 0); }
		public TerminalNode OUTER() { return getToken(JpqlParser.OUTER, 0); }
		public Join_specContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_join_spec; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterJoin_spec(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitJoin_spec(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitJoin_spec(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Join_specContext join_spec() throws RecognitionException {
		Join_specContext _localctx = new Join_specContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_join_spec);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(343);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case LEFT:
				{
				{
				setState(338);
				match(LEFT);
				setState(340);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==OUTER) {
					{
					setState(339);
					match(OUTER);
					}
				}

				}
				}
				break;
			case INNER:
				{
				setState(342);
				match(INNER);
				}
				break;
			case JOIN:
				break;
			default:
				break;
			}
			setState(345);
			match(JOIN);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Join_conditionContext extends ParserRuleContext {
		public TerminalNode ON() { return getToken(JpqlParser.ON, 0); }
		public Conditional_expressionContext conditional_expression() {
			return getRuleContext(Conditional_expressionContext.class,0);
		}
		public Join_conditionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_join_condition; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterJoin_condition(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitJoin_condition(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitJoin_condition(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Join_conditionContext join_condition() throws RecognitionException {
		Join_conditionContext _localctx = new Join_conditionContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_join_condition);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(347);
			match(ON);
			setState(348);
			conditional_expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Join_association_path_expressionContext extends ParserRuleContext {
		public Join_collection_valued_path_expressionContext join_collection_valued_path_expression() {
			return getRuleContext(Join_collection_valued_path_expressionContext.class,0);
		}
		public Join_single_valued_path_expressionContext join_single_valued_path_expression() {
			return getRuleContext(Join_single_valued_path_expressionContext.class,0);
		}
		public TerminalNode TREAT() { return getToken(JpqlParser.TREAT, 0); }
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public SubtypeContext subtype() {
			return getRuleContext(SubtypeContext.class,0);
		}
		public Join_association_path_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_join_association_path_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterJoin_association_path_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitJoin_association_path_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitJoin_association_path_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Join_association_path_expressionContext join_association_path_expression() throws RecognitionException {
		Join_association_path_expressionContext _localctx = new Join_association_path_expressionContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_join_association_path_expression);
		try {
			setState(366);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,16,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(350);
				join_collection_valued_path_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(351);
				join_single_valued_path_expression();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(352);
				match(TREAT);
				setState(353);
				match(T__1);
				setState(354);
				join_collection_valued_path_expression();
				setState(355);
				match(AS);
				setState(356);
				subtype();
				setState(357);
				match(T__2);
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(359);
				match(TREAT);
				setState(360);
				match(T__1);
				setState(361);
				join_single_valued_path_expression();
				setState(362);
				match(AS);
				setState(363);
				subtype();
				setState(364);
				match(T__2);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Join_collection_valued_path_expressionContext extends ParserRuleContext {
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Collection_valued_fieldContext collection_valued_field() {
			return getRuleContext(Collection_valued_fieldContext.class,0);
		}
		public List<Single_valued_embeddable_object_fieldContext> single_valued_embeddable_object_field() {
			return getRuleContexts(Single_valued_embeddable_object_fieldContext.class);
		}
		public Single_valued_embeddable_object_fieldContext single_valued_embeddable_object_field(int i) {
			return getRuleContext(Single_valued_embeddable_object_fieldContext.class,i);
		}
		public Join_collection_valued_path_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_join_collection_valued_path_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterJoin_collection_valued_path_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitJoin_collection_valued_path_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitJoin_collection_valued_path_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Join_collection_valued_path_expressionContext join_collection_valued_path_expression() throws RecognitionException {
		Join_collection_valued_path_expressionContext _localctx = new Join_collection_valued_path_expressionContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_join_collection_valued_path_expression);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(368);
			identification_variable();
			setState(369);
			match(T__3);
			setState(375);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,17,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(370);
					single_valued_embeddable_object_field();
					setState(371);
					match(T__3);
					}
					} 
				}
				setState(377);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,17,_ctx);
			}
			setState(378);
			collection_valued_field();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Join_single_valued_path_expressionContext extends ParserRuleContext {
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Single_valued_object_fieldContext single_valued_object_field() {
			return getRuleContext(Single_valued_object_fieldContext.class,0);
		}
		public List<Single_valued_embeddable_object_fieldContext> single_valued_embeddable_object_field() {
			return getRuleContexts(Single_valued_embeddable_object_fieldContext.class);
		}
		public Single_valued_embeddable_object_fieldContext single_valued_embeddable_object_field(int i) {
			return getRuleContext(Single_valued_embeddable_object_fieldContext.class,i);
		}
		public Join_single_valued_path_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_join_single_valued_path_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterJoin_single_valued_path_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitJoin_single_valued_path_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitJoin_single_valued_path_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Join_single_valued_path_expressionContext join_single_valued_path_expression() throws RecognitionException {
		Join_single_valued_path_expressionContext _localctx = new Join_single_valued_path_expressionContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_join_single_valued_path_expression);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(380);
			identification_variable();
			setState(381);
			match(T__3);
			setState(387);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,18,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(382);
					single_valued_embeddable_object_field();
					setState(383);
					match(T__3);
					}
					} 
				}
				setState(389);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,18,_ctx);
			}
			setState(390);
			single_valued_object_field();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Collection_member_declarationContext extends ParserRuleContext {
		public TerminalNode IN() { return getToken(JpqlParser.IN, 0); }
		public Collection_valued_path_expressionContext collection_valued_path_expression() {
			return getRuleContext(Collection_valued_path_expressionContext.class,0);
		}
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public Collection_member_declarationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_collection_member_declaration; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterCollection_member_declaration(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitCollection_member_declaration(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitCollection_member_declaration(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Collection_member_declarationContext collection_member_declaration() throws RecognitionException {
		Collection_member_declarationContext _localctx = new Collection_member_declarationContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_collection_member_declaration);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(392);
			match(IN);
			setState(393);
			match(T__1);
			setState(394);
			collection_valued_path_expression();
			setState(395);
			match(T__2);
			setState(397);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==AS) {
				{
				setState(396);
				match(AS);
				}
			}

			setState(399);
			identification_variable();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Qualified_identification_variableContext extends ParserRuleContext {
		public Map_field_identification_variableContext map_field_identification_variable() {
			return getRuleContext(Map_field_identification_variableContext.class,0);
		}
		public TerminalNode ENTRY() { return getToken(JpqlParser.ENTRY, 0); }
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Qualified_identification_variableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_qualified_identification_variable; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterQualified_identification_variable(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitQualified_identification_variable(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitQualified_identification_variable(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Qualified_identification_variableContext qualified_identification_variable() throws RecognitionException {
		Qualified_identification_variableContext _localctx = new Qualified_identification_variableContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_qualified_identification_variable);
		try {
			setState(407);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case KEY:
			case VALUE:
				enterOuterAlt(_localctx, 1);
				{
				setState(401);
				map_field_identification_variable();
				}
				break;
			case ENTRY:
				enterOuterAlt(_localctx, 2);
				{
				setState(402);
				match(ENTRY);
				setState(403);
				match(T__1);
				setState(404);
				identification_variable();
				setState(405);
				match(T__2);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Map_field_identification_variableContext extends ParserRuleContext {
		public TerminalNode KEY() { return getToken(JpqlParser.KEY, 0); }
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public TerminalNode VALUE() { return getToken(JpqlParser.VALUE, 0); }
		public Map_field_identification_variableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_map_field_identification_variable; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterMap_field_identification_variable(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitMap_field_identification_variable(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitMap_field_identification_variable(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Map_field_identification_variableContext map_field_identification_variable() throws RecognitionException {
		Map_field_identification_variableContext _localctx = new Map_field_identification_variableContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_map_field_identification_variable);
		try {
			setState(419);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case KEY:
				enterOuterAlt(_localctx, 1);
				{
				setState(409);
				match(KEY);
				setState(410);
				match(T__1);
				setState(411);
				identification_variable();
				setState(412);
				match(T__2);
				}
				break;
			case VALUE:
				enterOuterAlt(_localctx, 2);
				{
				setState(414);
				match(VALUE);
				setState(415);
				match(T__1);
				setState(416);
				identification_variable();
				setState(417);
				match(T__2);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Single_valued_path_expressionContext extends ParserRuleContext {
		public Qualified_identification_variableContext qualified_identification_variable() {
			return getRuleContext(Qualified_identification_variableContext.class,0);
		}
		public TerminalNode TREAT() { return getToken(JpqlParser.TREAT, 0); }
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public SubtypeContext subtype() {
			return getRuleContext(SubtypeContext.class,0);
		}
		public State_field_path_expressionContext state_field_path_expression() {
			return getRuleContext(State_field_path_expressionContext.class,0);
		}
		public Single_valued_object_path_expressionContext single_valued_object_path_expression() {
			return getRuleContext(Single_valued_object_path_expressionContext.class,0);
		}
		public Single_valued_path_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_single_valued_path_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSingle_valued_path_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSingle_valued_path_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSingle_valued_path_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Single_valued_path_expressionContext single_valued_path_expression() throws RecognitionException {
		Single_valued_path_expressionContext _localctx = new Single_valued_path_expressionContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_single_valued_path_expression);
		try {
			setState(431);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,22,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(421);
				qualified_identification_variable();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(422);
				match(TREAT);
				setState(423);
				match(T__1);
				setState(424);
				qualified_identification_variable();
				setState(425);
				match(AS);
				setState(426);
				subtype();
				setState(427);
				match(T__2);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(429);
				state_field_path_expression();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(430);
				single_valued_object_path_expression();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class General_identification_variableContext extends ParserRuleContext {
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Map_field_identification_variableContext map_field_identification_variable() {
			return getRuleContext(Map_field_identification_variableContext.class,0);
		}
		public General_identification_variableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_general_identification_variable; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterGeneral_identification_variable(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitGeneral_identification_variable(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitGeneral_identification_variable(this);
			else return visitor.visitChildren(this);
		}
	}

	public final General_identification_variableContext general_identification_variable() throws RecognitionException {
		General_identification_variableContext _localctx = new General_identification_variableContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_general_identification_variable);
		try {
			setState(435);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,23,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(433);
				identification_variable();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(434);
				map_field_identification_variable();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class General_subpathContext extends ParserRuleContext {
		public Simple_subpathContext simple_subpath() {
			return getRuleContext(Simple_subpathContext.class,0);
		}
		public Treated_subpathContext treated_subpath() {
			return getRuleContext(Treated_subpathContext.class,0);
		}
		public List<Single_valued_object_fieldContext> single_valued_object_field() {
			return getRuleContexts(Single_valued_object_fieldContext.class);
		}
		public Single_valued_object_fieldContext single_valued_object_field(int i) {
			return getRuleContext(Single_valued_object_fieldContext.class,i);
		}
		public General_subpathContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_general_subpath; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterGeneral_subpath(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitGeneral_subpath(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitGeneral_subpath(this);
			else return visitor.visitChildren(this);
		}
	}

	public final General_subpathContext general_subpath() throws RecognitionException {
		General_subpathContext _localctx = new General_subpathContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_general_subpath);
		try {
			int _alt;
			setState(446);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case COUNT:
			case DATE:
			case FLOOR:
			case FROM:
			case INNER:
			case KEY:
			case LEFT:
			case NEW:
			case ORDER:
			case OUTER:
			case POWER:
			case SIGN:
			case TIME:
			case TYPE:
			case VALUE:
			case IDENTIFICATION_VARIABLE:
				enterOuterAlt(_localctx, 1);
				{
				setState(437);
				simple_subpath();
				}
				break;
			case TREAT:
				enterOuterAlt(_localctx, 2);
				{
				setState(438);
				treated_subpath();
				setState(443);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,24,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(439);
						match(T__3);
						setState(440);
						single_valued_object_field();
						}
						} 
					}
					setState(445);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,24,_ctx);
				}
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Simple_subpathContext extends ParserRuleContext {
		public General_identification_variableContext general_identification_variable() {
			return getRuleContext(General_identification_variableContext.class,0);
		}
		public List<Single_valued_object_fieldContext> single_valued_object_field() {
			return getRuleContexts(Single_valued_object_fieldContext.class);
		}
		public Single_valued_object_fieldContext single_valued_object_field(int i) {
			return getRuleContext(Single_valued_object_fieldContext.class,i);
		}
		public Simple_subpathContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simple_subpath; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSimple_subpath(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSimple_subpath(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSimple_subpath(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Simple_subpathContext simple_subpath() throws RecognitionException {
		Simple_subpathContext _localctx = new Simple_subpathContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_simple_subpath);
		try {
			int _alt;
			setState(457);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,27,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(448);
				general_identification_variable();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(449);
				general_identification_variable();
				setState(454);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,26,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(450);
						match(T__3);
						setState(451);
						single_valued_object_field();
						}
						} 
					}
					setState(456);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,26,_ctx);
				}
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Treated_subpathContext extends ParserRuleContext {
		public TerminalNode TREAT() { return getToken(JpqlParser.TREAT, 0); }
		public General_subpathContext general_subpath() {
			return getRuleContext(General_subpathContext.class,0);
		}
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public SubtypeContext subtype() {
			return getRuleContext(SubtypeContext.class,0);
		}
		public Treated_subpathContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_treated_subpath; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterTreated_subpath(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitTreated_subpath(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitTreated_subpath(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Treated_subpathContext treated_subpath() throws RecognitionException {
		Treated_subpathContext _localctx = new Treated_subpathContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_treated_subpath);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(459);
			match(TREAT);
			setState(460);
			match(T__1);
			setState(461);
			general_subpath();
			setState(462);
			match(AS);
			setState(463);
			subtype();
			setState(464);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class State_field_path_expressionContext extends ParserRuleContext {
		public General_subpathContext general_subpath() {
			return getRuleContext(General_subpathContext.class,0);
		}
		public State_fieldContext state_field() {
			return getRuleContext(State_fieldContext.class,0);
		}
		public State_field_path_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_state_field_path_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterState_field_path_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitState_field_path_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitState_field_path_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final State_field_path_expressionContext state_field_path_expression() throws RecognitionException {
		State_field_path_expressionContext _localctx = new State_field_path_expressionContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_state_field_path_expression);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(466);
			general_subpath();
			setState(467);
			match(T__3);
			setState(468);
			state_field();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class State_valued_path_expressionContext extends ParserRuleContext {
		public State_field_path_expressionContext state_field_path_expression() {
			return getRuleContext(State_field_path_expressionContext.class,0);
		}
		public General_identification_variableContext general_identification_variable() {
			return getRuleContext(General_identification_variableContext.class,0);
		}
		public State_valued_path_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_state_valued_path_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterState_valued_path_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitState_valued_path_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitState_valued_path_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final State_valued_path_expressionContext state_valued_path_expression() throws RecognitionException {
		State_valued_path_expressionContext _localctx = new State_valued_path_expressionContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_state_valued_path_expression);
		try {
			setState(472);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,28,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(470);
				state_field_path_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(471);
				general_identification_variable();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Single_valued_object_path_expressionContext extends ParserRuleContext {
		public General_subpathContext general_subpath() {
			return getRuleContext(General_subpathContext.class,0);
		}
		public Single_valued_object_fieldContext single_valued_object_field() {
			return getRuleContext(Single_valued_object_fieldContext.class,0);
		}
		public Single_valued_object_path_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_single_valued_object_path_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSingle_valued_object_path_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSingle_valued_object_path_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSingle_valued_object_path_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Single_valued_object_path_expressionContext single_valued_object_path_expression() throws RecognitionException {
		Single_valued_object_path_expressionContext _localctx = new Single_valued_object_path_expressionContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_single_valued_object_path_expression);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(474);
			general_subpath();
			setState(475);
			match(T__3);
			setState(476);
			single_valued_object_field();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Collection_valued_path_expressionContext extends ParserRuleContext {
		public General_subpathContext general_subpath() {
			return getRuleContext(General_subpathContext.class,0);
		}
		public Collection_value_fieldContext collection_value_field() {
			return getRuleContext(Collection_value_fieldContext.class,0);
		}
		public Collection_valued_path_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_collection_valued_path_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterCollection_valued_path_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitCollection_valued_path_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitCollection_valued_path_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Collection_valued_path_expressionContext collection_valued_path_expression() throws RecognitionException {
		Collection_valued_path_expressionContext _localctx = new Collection_valued_path_expressionContext(_ctx, getState());
		enterRule(_localctx, 54, RULE_collection_valued_path_expression);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(478);
			general_subpath();
			setState(479);
			match(T__3);
			setState(480);
			collection_value_field();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Update_clauseContext extends ParserRuleContext {
		public TerminalNode UPDATE() { return getToken(JpqlParser.UPDATE, 0); }
		public Entity_nameContext entity_name() {
			return getRuleContext(Entity_nameContext.class,0);
		}
		public TerminalNode SET() { return getToken(JpqlParser.SET, 0); }
		public List<Update_itemContext> update_item() {
			return getRuleContexts(Update_itemContext.class);
		}
		public Update_itemContext update_item(int i) {
			return getRuleContext(Update_itemContext.class,i);
		}
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public Update_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_update_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterUpdate_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitUpdate_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitUpdate_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Update_clauseContext update_clause() throws RecognitionException {
		Update_clauseContext _localctx = new Update_clauseContext(_ctx, getState());
		enterRule(_localctx, 56, RULE_update_clause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(482);
			match(UPDATE);
			setState(483);
			entity_name();
			setState(488);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & 1175439539251970048L) != 0) || ((((_la - 65)) & ~0x3f) == 0 && ((1L << (_la - 65)) & 9166080949911561L) != 0)) {
				{
				setState(485);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==AS) {
					{
					setState(484);
					match(AS);
					}
				}

				setState(487);
				identification_variable();
				}
			}

			setState(490);
			match(SET);
			setState(491);
			update_item();
			setState(496);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(492);
				match(T__0);
				setState(493);
				update_item();
				}
				}
				setState(498);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Update_itemContext extends ParserRuleContext {
		public TerminalNode EQUAL() { return getToken(JpqlParser.EQUAL, 0); }
		public New_valueContext new_value() {
			return getRuleContext(New_valueContext.class,0);
		}
		public State_fieldContext state_field() {
			return getRuleContext(State_fieldContext.class,0);
		}
		public Single_valued_object_fieldContext single_valued_object_field() {
			return getRuleContext(Single_valued_object_fieldContext.class,0);
		}
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public List<Single_valued_embeddable_object_fieldContext> single_valued_embeddable_object_field() {
			return getRuleContexts(Single_valued_embeddable_object_fieldContext.class);
		}
		public Single_valued_embeddable_object_fieldContext single_valued_embeddable_object_field(int i) {
			return getRuleContext(Single_valued_embeddable_object_fieldContext.class,i);
		}
		public Update_itemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_update_item; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterUpdate_item(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitUpdate_item(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitUpdate_item(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Update_itemContext update_item() throws RecognitionException {
		Update_itemContext _localctx = new Update_itemContext(_ctx, getState());
		enterRule(_localctx, 58, RULE_update_item);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(502);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,32,_ctx) ) {
			case 1:
				{
				setState(499);
				identification_variable();
				setState(500);
				match(T__3);
				}
				break;
			}
			setState(509);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,33,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(504);
					single_valued_embeddable_object_field();
					setState(505);
					match(T__3);
					}
					} 
				}
				setState(511);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,33,_ctx);
			}
			setState(514);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,34,_ctx) ) {
			case 1:
				{
				setState(512);
				state_field();
				}
				break;
			case 2:
				{
				setState(513);
				single_valued_object_field();
				}
				break;
			}
			setState(516);
			match(EQUAL);
			setState(517);
			new_value();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class New_valueContext extends ParserRuleContext {
		public Scalar_expressionContext scalar_expression() {
			return getRuleContext(Scalar_expressionContext.class,0);
		}
		public Simple_entity_expressionContext simple_entity_expression() {
			return getRuleContext(Simple_entity_expressionContext.class,0);
		}
		public TerminalNode NULL() { return getToken(JpqlParser.NULL, 0); }
		public New_valueContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_new_value; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterNew_value(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitNew_value(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitNew_value(this);
			else return visitor.visitChildren(this);
		}
	}

	public final New_valueContext new_value() throws RecognitionException {
		New_valueContext _localctx = new New_valueContext(_ctx, getState());
		enterRule(_localctx, 60, RULE_new_value);
		try {
			setState(522);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,35,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(519);
				scalar_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(520);
				simple_entity_expression();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(521);
				match(NULL);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Delete_clauseContext extends ParserRuleContext {
		public TerminalNode DELETE() { return getToken(JpqlParser.DELETE, 0); }
		public TerminalNode FROM() { return getToken(JpqlParser.FROM, 0); }
		public Entity_nameContext entity_name() {
			return getRuleContext(Entity_nameContext.class,0);
		}
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public Delete_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_delete_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterDelete_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitDelete_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitDelete_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Delete_clauseContext delete_clause() throws RecognitionException {
		Delete_clauseContext _localctx = new Delete_clauseContext(_ctx, getState());
		enterRule(_localctx, 62, RULE_delete_clause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(524);
			match(DELETE);
			setState(525);
			match(FROM);
			setState(526);
			entity_name();
			setState(531);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & 1175439539251970048L) != 0) || ((((_la - 65)) & ~0x3f) == 0 && ((1L << (_la - 65)) & 9166080949911561L) != 0)) {
				{
				setState(528);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==AS) {
					{
					setState(527);
					match(AS);
					}
				}

				setState(530);
				identification_variable();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Select_clauseContext extends ParserRuleContext {
		public TerminalNode SELECT() { return getToken(JpqlParser.SELECT, 0); }
		public List<Select_itemContext> select_item() {
			return getRuleContexts(Select_itemContext.class);
		}
		public Select_itemContext select_item(int i) {
			return getRuleContext(Select_itemContext.class,i);
		}
		public TerminalNode DISTINCT() { return getToken(JpqlParser.DISTINCT, 0); }
		public Select_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_select_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSelect_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSelect_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSelect_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Select_clauseContext select_clause() throws RecognitionException {
		Select_clauseContext _localctx = new Select_clauseContext(_ctx, getState());
		enterRule(_localctx, 64, RULE_select_clause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(533);
			match(SELECT);
			setState(535);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==DISTINCT) {
				{
				setState(534);
				match(DISTINCT);
				}
			}

			setState(537);
			select_item();
			setState(542);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(538);
				match(T__0);
				setState(539);
				select_item();
				}
				}
				setState(544);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Select_itemContext extends ParserRuleContext {
		public Select_expressionContext select_expression() {
			return getRuleContext(Select_expressionContext.class,0);
		}
		public Result_variableContext result_variable() {
			return getRuleContext(Result_variableContext.class,0);
		}
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public Select_itemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_select_item; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSelect_item(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSelect_item(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSelect_item(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Select_itemContext select_item() throws RecognitionException {
		Select_itemContext _localctx = new Select_itemContext(_ctx, getState());
		enterRule(_localctx, 66, RULE_select_item);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(545);
			select_expression();
			setState(550);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,41,_ctx) ) {
			case 1:
				{
				setState(547);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==AS) {
					{
					setState(546);
					match(AS);
					}
				}

				setState(549);
				result_variable();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Select_expressionContext extends ParserRuleContext {
		public Single_valued_path_expressionContext single_valued_path_expression() {
			return getRuleContext(Single_valued_path_expressionContext.class,0);
		}
		public Scalar_expressionContext scalar_expression() {
			return getRuleContext(Scalar_expressionContext.class,0);
		}
		public Aggregate_expressionContext aggregate_expression() {
			return getRuleContext(Aggregate_expressionContext.class,0);
		}
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public TerminalNode OBJECT() { return getToken(JpqlParser.OBJECT, 0); }
		public Constructor_expressionContext constructor_expression() {
			return getRuleContext(Constructor_expressionContext.class,0);
		}
		public Select_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_select_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSelect_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSelect_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSelect_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Select_expressionContext select_expression() throws RecognitionException {
		Select_expressionContext _localctx = new Select_expressionContext(_ctx, getState());
		enterRule(_localctx, 68, RULE_select_expression);
		try {
			setState(562);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,42,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(552);
				single_valued_path_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(553);
				scalar_expression();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(554);
				aggregate_expression();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(555);
				identification_variable();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(556);
				match(OBJECT);
				setState(557);
				match(T__1);
				setState(558);
				identification_variable();
				setState(559);
				match(T__2);
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(561);
				constructor_expression();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Constructor_expressionContext extends ParserRuleContext {
		public TerminalNode NEW() { return getToken(JpqlParser.NEW, 0); }
		public Constructor_nameContext constructor_name() {
			return getRuleContext(Constructor_nameContext.class,0);
		}
		public List<Constructor_itemContext> constructor_item() {
			return getRuleContexts(Constructor_itemContext.class);
		}
		public Constructor_itemContext constructor_item(int i) {
			return getRuleContext(Constructor_itemContext.class,i);
		}
		public Constructor_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_constructor_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterConstructor_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitConstructor_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitConstructor_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Constructor_expressionContext constructor_expression() throws RecognitionException {
		Constructor_expressionContext _localctx = new Constructor_expressionContext(_ctx, getState());
		enterRule(_localctx, 70, RULE_constructor_expression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(564);
			match(NEW);
			setState(565);
			constructor_name();
			setState(566);
			match(T__1);
			setState(567);
			constructor_item();
			setState(572);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(568);
				match(T__0);
				setState(569);
				constructor_item();
				}
				}
				setState(574);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(575);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Constructor_itemContext extends ParserRuleContext {
		public Single_valued_path_expressionContext single_valued_path_expression() {
			return getRuleContext(Single_valued_path_expressionContext.class,0);
		}
		public Scalar_expressionContext scalar_expression() {
			return getRuleContext(Scalar_expressionContext.class,0);
		}
		public Aggregate_expressionContext aggregate_expression() {
			return getRuleContext(Aggregate_expressionContext.class,0);
		}
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public LiteralContext literal() {
			return getRuleContext(LiteralContext.class,0);
		}
		public Constructor_itemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_constructor_item; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterConstructor_item(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitConstructor_item(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitConstructor_item(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Constructor_itemContext constructor_item() throws RecognitionException {
		Constructor_itemContext _localctx = new Constructor_itemContext(_ctx, getState());
		enterRule(_localctx, 72, RULE_constructor_item);
		try {
			setState(582);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,44,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(577);
				single_valued_path_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(578);
				scalar_expression();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(579);
				aggregate_expression();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(580);
				identification_variable();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(581);
				literal();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Aggregate_expressionContext extends ParserRuleContext {
		public State_valued_path_expressionContext state_valued_path_expression() {
			return getRuleContext(State_valued_path_expressionContext.class,0);
		}
		public TerminalNode AVG() { return getToken(JpqlParser.AVG, 0); }
		public TerminalNode MAX() { return getToken(JpqlParser.MAX, 0); }
		public TerminalNode MIN() { return getToken(JpqlParser.MIN, 0); }
		public TerminalNode SUM() { return getToken(JpqlParser.SUM, 0); }
		public TerminalNode DISTINCT() { return getToken(JpqlParser.DISTINCT, 0); }
		public TerminalNode COUNT() { return getToken(JpqlParser.COUNT, 0); }
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Single_valued_object_path_expressionContext single_valued_object_path_expression() {
			return getRuleContext(Single_valued_object_path_expressionContext.class,0);
		}
		public Function_invocationContext function_invocation() {
			return getRuleContext(Function_invocationContext.class,0);
		}
		public Aggregate_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_aggregate_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterAggregate_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitAggregate_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitAggregate_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Aggregate_expressionContext aggregate_expression() throws RecognitionException {
		Aggregate_expressionContext _localctx = new Aggregate_expressionContext(_ctx, getState());
		enterRule(_localctx, 74, RULE_aggregate_expression);
		int _la;
		try {
			setState(605);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case AVG:
			case MAX:
			case MIN:
			case SUM:
				enterOuterAlt(_localctx, 1);
				{
				setState(584);
				_la = _input.LA(1);
				if ( !(_la==AVG || ((((_la - 76)) & ~0x3f) == 0 && ((1L << (_la - 76)) & 67108869L) != 0)) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(585);
				match(T__1);
				setState(587);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==DISTINCT) {
					{
					setState(586);
					match(DISTINCT);
					}
				}

				setState(589);
				state_valued_path_expression();
				setState(590);
				match(T__2);
				}
				break;
			case COUNT:
				enterOuterAlt(_localctx, 2);
				{
				setState(592);
				match(COUNT);
				setState(593);
				match(T__1);
				setState(595);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==DISTINCT) {
					{
					setState(594);
					match(DISTINCT);
					}
				}

				setState(600);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,47,_ctx) ) {
				case 1:
					{
					setState(597);
					identification_variable();
					}
					break;
				case 2:
					{
					setState(598);
					state_valued_path_expression();
					}
					break;
				case 3:
					{
					setState(599);
					single_valued_object_path_expression();
					}
					break;
				}
				setState(602);
				match(T__2);
				}
				break;
			case FUNCTION:
				enterOuterAlt(_localctx, 3);
				{
				setState(604);
				function_invocation();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Where_clauseContext extends ParserRuleContext {
		public TerminalNode WHERE() { return getToken(JpqlParser.WHERE, 0); }
		public Conditional_expressionContext conditional_expression() {
			return getRuleContext(Conditional_expressionContext.class,0);
		}
		public Where_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_where_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterWhere_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitWhere_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitWhere_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Where_clauseContext where_clause() throws RecognitionException {
		Where_clauseContext _localctx = new Where_clauseContext(_ctx, getState());
		enterRule(_localctx, 76, RULE_where_clause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(607);
			match(WHERE);
			setState(608);
			conditional_expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Groupby_clauseContext extends ParserRuleContext {
		public TerminalNode GROUP() { return getToken(JpqlParser.GROUP, 0); }
		public TerminalNode BY() { return getToken(JpqlParser.BY, 0); }
		public List<Groupby_itemContext> groupby_item() {
			return getRuleContexts(Groupby_itemContext.class);
		}
		public Groupby_itemContext groupby_item(int i) {
			return getRuleContext(Groupby_itemContext.class,i);
		}
		public Groupby_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_groupby_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterGroupby_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitGroupby_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitGroupby_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Groupby_clauseContext groupby_clause() throws RecognitionException {
		Groupby_clauseContext _localctx = new Groupby_clauseContext(_ctx, getState());
		enterRule(_localctx, 78, RULE_groupby_clause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(610);
			match(GROUP);
			setState(611);
			match(BY);
			setState(612);
			groupby_item();
			setState(617);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(613);
				match(T__0);
				setState(614);
				groupby_item();
				}
				}
				setState(619);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Groupby_itemContext extends ParserRuleContext {
		public Single_valued_path_expressionContext single_valued_path_expression() {
			return getRuleContext(Single_valued_path_expressionContext.class,0);
		}
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Groupby_itemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_groupby_item; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterGroupby_item(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitGroupby_item(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitGroupby_item(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Groupby_itemContext groupby_item() throws RecognitionException {
		Groupby_itemContext _localctx = new Groupby_itemContext(_ctx, getState());
		enterRule(_localctx, 80, RULE_groupby_item);
		try {
			setState(622);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,50,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(620);
				single_valued_path_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(621);
				identification_variable();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Having_clauseContext extends ParserRuleContext {
		public TerminalNode HAVING() { return getToken(JpqlParser.HAVING, 0); }
		public Conditional_expressionContext conditional_expression() {
			return getRuleContext(Conditional_expressionContext.class,0);
		}
		public Having_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_having_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterHaving_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitHaving_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitHaving_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Having_clauseContext having_clause() throws RecognitionException {
		Having_clauseContext _localctx = new Having_clauseContext(_ctx, getState());
		enterRule(_localctx, 82, RULE_having_clause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(624);
			match(HAVING);
			setState(625);
			conditional_expression(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Orderby_clauseContext extends ParserRuleContext {
		public TerminalNode ORDER() { return getToken(JpqlParser.ORDER, 0); }
		public TerminalNode BY() { return getToken(JpqlParser.BY, 0); }
		public List<Orderby_itemContext> orderby_item() {
			return getRuleContexts(Orderby_itemContext.class);
		}
		public Orderby_itemContext orderby_item(int i) {
			return getRuleContext(Orderby_itemContext.class,i);
		}
		public Orderby_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_orderby_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterOrderby_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitOrderby_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitOrderby_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Orderby_clauseContext orderby_clause() throws RecognitionException {
		Orderby_clauseContext _localctx = new Orderby_clauseContext(_ctx, getState());
		enterRule(_localctx, 84, RULE_orderby_clause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(627);
			match(ORDER);
			setState(628);
			match(BY);
			setState(629);
			orderby_item();
			setState(634);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(630);
				match(T__0);
				setState(631);
				orderby_item();
				}
				}
				setState(636);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Orderby_itemContext extends ParserRuleContext {
		public State_field_path_expressionContext state_field_path_expression() {
			return getRuleContext(State_field_path_expressionContext.class,0);
		}
		public General_identification_variableContext general_identification_variable() {
			return getRuleContext(General_identification_variableContext.class,0);
		}
		public Result_variableContext result_variable() {
			return getRuleContext(Result_variableContext.class,0);
		}
		public NullsPrecedenceContext nullsPrecedence() {
			return getRuleContext(NullsPrecedenceContext.class,0);
		}
		public TerminalNode ASC() { return getToken(JpqlParser.ASC, 0); }
		public TerminalNode DESC() { return getToken(JpqlParser.DESC, 0); }
		public Orderby_itemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_orderby_item; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterOrderby_item(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitOrderby_item(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitOrderby_item(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Orderby_itemContext orderby_item() throws RecognitionException {
		Orderby_itemContext _localctx = new Orderby_itemContext(_ctx, getState());
		enterRule(_localctx, 86, RULE_orderby_item);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(640);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,52,_ctx) ) {
			case 1:
				{
				setState(637);
				state_field_path_expression();
				}
				break;
			case 2:
				{
				setState(638);
				general_identification_variable();
				}
				break;
			case 3:
				{
				setState(639);
				result_variable();
				}
				break;
			}
			setState(643);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ASC || _la==DESC) {
				{
				setState(642);
				_la = _input.LA(1);
				if ( !(_la==ASC || _la==DESC) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
			}

			setState(646);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NULLS) {
				{
				setState(645);
				nullsPrecedence();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class NullsPrecedenceContext extends ParserRuleContext {
		public TerminalNode NULLS() { return getToken(JpqlParser.NULLS, 0); }
		public TerminalNode FIRST() { return getToken(JpqlParser.FIRST, 0); }
		public TerminalNode LAST() { return getToken(JpqlParser.LAST, 0); }
		public NullsPrecedenceContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_nullsPrecedence; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterNullsPrecedence(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitNullsPrecedence(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitNullsPrecedence(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NullsPrecedenceContext nullsPrecedence() throws RecognitionException {
		NullsPrecedenceContext _localctx = new NullsPrecedenceContext(_ctx, getState());
		enterRule(_localctx, 88, RULE_nullsPrecedence);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(648);
			match(NULLS);
			setState(649);
			_la = _input.LA(1);
			if ( !(_la==FIRST || _la==LAST) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SubqueryContext extends ParserRuleContext {
		public Simple_select_clauseContext simple_select_clause() {
			return getRuleContext(Simple_select_clauseContext.class,0);
		}
		public Subquery_from_clauseContext subquery_from_clause() {
			return getRuleContext(Subquery_from_clauseContext.class,0);
		}
		public Where_clauseContext where_clause() {
			return getRuleContext(Where_clauseContext.class,0);
		}
		public Groupby_clauseContext groupby_clause() {
			return getRuleContext(Groupby_clauseContext.class,0);
		}
		public Having_clauseContext having_clause() {
			return getRuleContext(Having_clauseContext.class,0);
		}
		public SubqueryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_subquery; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSubquery(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSubquery(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSubquery(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SubqueryContext subquery() throws RecognitionException {
		SubqueryContext _localctx = new SubqueryContext(_ctx, getState());
		enterRule(_localctx, 90, RULE_subquery);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(651);
			simple_select_clause();
			setState(652);
			subquery_from_clause();
			setState(654);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==WHERE) {
				{
				setState(653);
				where_clause();
				}
			}

			setState(657);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==GROUP) {
				{
				setState(656);
				groupby_clause();
				}
			}

			setState(660);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==HAVING) {
				{
				setState(659);
				having_clause();
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Subquery_from_clauseContext extends ParserRuleContext {
		public TerminalNode FROM() { return getToken(JpqlParser.FROM, 0); }
		public List<Subselect_identification_variable_declarationContext> subselect_identification_variable_declaration() {
			return getRuleContexts(Subselect_identification_variable_declarationContext.class);
		}
		public Subselect_identification_variable_declarationContext subselect_identification_variable_declaration(int i) {
			return getRuleContext(Subselect_identification_variable_declarationContext.class,i);
		}
		public List<Collection_member_declarationContext> collection_member_declaration() {
			return getRuleContexts(Collection_member_declarationContext.class);
		}
		public Collection_member_declarationContext collection_member_declaration(int i) {
			return getRuleContext(Collection_member_declarationContext.class,i);
		}
		public Subquery_from_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_subquery_from_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSubquery_from_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSubquery_from_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSubquery_from_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Subquery_from_clauseContext subquery_from_clause() throws RecognitionException {
		Subquery_from_clauseContext _localctx = new Subquery_from_clauseContext(_ctx, getState());
		enterRule(_localctx, 92, RULE_subquery_from_clause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(662);
			match(FROM);
			setState(663);
			subselect_identification_variable_declaration();
			setState(671);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(664);
				match(T__0);
				setState(667);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,58,_ctx) ) {
				case 1:
					{
					setState(665);
					subselect_identification_variable_declaration();
					}
					break;
				case 2:
					{
					setState(666);
					collection_member_declaration();
					}
					break;
				}
				}
				}
				setState(673);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Subselect_identification_variable_declarationContext extends ParserRuleContext {
		public Identification_variable_declarationContext identification_variable_declaration() {
			return getRuleContext(Identification_variable_declarationContext.class,0);
		}
		public Derived_path_expressionContext derived_path_expression() {
			return getRuleContext(Derived_path_expressionContext.class,0);
		}
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public List<JoinContext> join() {
			return getRuleContexts(JoinContext.class);
		}
		public JoinContext join(int i) {
			return getRuleContext(JoinContext.class,i);
		}
		public Derived_collection_member_declarationContext derived_collection_member_declaration() {
			return getRuleContext(Derived_collection_member_declarationContext.class,0);
		}
		public Subselect_identification_variable_declarationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_subselect_identification_variable_declaration; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSubselect_identification_variable_declaration(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSubselect_identification_variable_declaration(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSubselect_identification_variable_declaration(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Subselect_identification_variable_declarationContext subselect_identification_variable_declaration() throws RecognitionException {
		Subselect_identification_variable_declarationContext _localctx = new Subselect_identification_variable_declarationContext(_ctx, getState());
		enterRule(_localctx, 94, RULE_subselect_identification_variable_declaration);
		int _la;
		try {
			setState(687);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,62,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(674);
				identification_variable_declaration();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(675);
				derived_path_expression();
				setState(677);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==AS) {
					{
					setState(676);
					match(AS);
					}
				}

				setState(679);
				identification_variable();
				setState(683);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (((((_la - 60)) & ~0x3f) == 0 && ((1L << (_la - 60)) & 273L) != 0)) {
					{
					{
					setState(680);
					join();
					}
					}
					setState(685);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(686);
				derived_collection_member_declaration();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Derived_path_expressionContext extends ParserRuleContext {
		public General_derived_pathContext general_derived_path() {
			return getRuleContext(General_derived_pathContext.class,0);
		}
		public Single_valued_object_fieldContext single_valued_object_field() {
			return getRuleContext(Single_valued_object_fieldContext.class,0);
		}
		public Collection_valued_fieldContext collection_valued_field() {
			return getRuleContext(Collection_valued_fieldContext.class,0);
		}
		public Derived_path_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_derived_path_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterDerived_path_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitDerived_path_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitDerived_path_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Derived_path_expressionContext derived_path_expression() throws RecognitionException {
		Derived_path_expressionContext _localctx = new Derived_path_expressionContext(_ctx, getState());
		enterRule(_localctx, 96, RULE_derived_path_expression);
		try {
			setState(697);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,63,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(689);
				general_derived_path();
				setState(690);
				match(T__3);
				setState(691);
				single_valued_object_field();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(693);
				general_derived_path();
				setState(694);
				match(T__3);
				setState(695);
				collection_valued_field();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class General_derived_pathContext extends ParserRuleContext {
		public Simple_derived_pathContext simple_derived_path() {
			return getRuleContext(Simple_derived_pathContext.class,0);
		}
		public Treated_derived_pathContext treated_derived_path() {
			return getRuleContext(Treated_derived_pathContext.class,0);
		}
		public List<Single_valued_object_fieldContext> single_valued_object_field() {
			return getRuleContexts(Single_valued_object_fieldContext.class);
		}
		public Single_valued_object_fieldContext single_valued_object_field(int i) {
			return getRuleContext(Single_valued_object_fieldContext.class,i);
		}
		public General_derived_pathContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_general_derived_path; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterGeneral_derived_path(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitGeneral_derived_path(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitGeneral_derived_path(this);
			else return visitor.visitChildren(this);
		}
	}

	public final General_derived_pathContext general_derived_path() throws RecognitionException {
		General_derived_pathContext _localctx = new General_derived_pathContext(_ctx, getState());
		enterRule(_localctx, 98, RULE_general_derived_path);
		try {
			int _alt;
			setState(708);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case COUNT:
			case DATE:
			case FLOOR:
			case FROM:
			case INNER:
			case KEY:
			case LEFT:
			case NEW:
			case ORDER:
			case OUTER:
			case POWER:
			case SIGN:
			case TIME:
			case TYPE:
			case VALUE:
			case IDENTIFICATION_VARIABLE:
				enterOuterAlt(_localctx, 1);
				{
				setState(699);
				simple_derived_path();
				}
				break;
			case TREAT:
				enterOuterAlt(_localctx, 2);
				{
				setState(700);
				treated_derived_path();
				setState(705);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,64,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(701);
						match(T__3);
						setState(702);
						single_valued_object_field();
						}
						} 
					}
					setState(707);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,64,_ctx);
				}
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Simple_derived_pathContext extends ParserRuleContext {
		public Superquery_identification_variableContext superquery_identification_variable() {
			return getRuleContext(Superquery_identification_variableContext.class,0);
		}
		public List<Single_valued_object_fieldContext> single_valued_object_field() {
			return getRuleContexts(Single_valued_object_fieldContext.class);
		}
		public Single_valued_object_fieldContext single_valued_object_field(int i) {
			return getRuleContext(Single_valued_object_fieldContext.class,i);
		}
		public Simple_derived_pathContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simple_derived_path; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSimple_derived_path(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSimple_derived_path(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSimple_derived_path(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Simple_derived_pathContext simple_derived_path() throws RecognitionException {
		Simple_derived_pathContext _localctx = new Simple_derived_pathContext(_ctx, getState());
		enterRule(_localctx, 100, RULE_simple_derived_path);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(710);
			superquery_identification_variable();
			setState(715);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,66,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(711);
					match(T__3);
					setState(712);
					single_valued_object_field();
					}
					} 
				}
				setState(717);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,66,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Treated_derived_pathContext extends ParserRuleContext {
		public TerminalNode TREAT() { return getToken(JpqlParser.TREAT, 0); }
		public General_derived_pathContext general_derived_path() {
			return getRuleContext(General_derived_pathContext.class,0);
		}
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public SubtypeContext subtype() {
			return getRuleContext(SubtypeContext.class,0);
		}
		public Treated_derived_pathContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_treated_derived_path; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterTreated_derived_path(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitTreated_derived_path(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitTreated_derived_path(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Treated_derived_pathContext treated_derived_path() throws RecognitionException {
		Treated_derived_pathContext _localctx = new Treated_derived_pathContext(_ctx, getState());
		enterRule(_localctx, 102, RULE_treated_derived_path);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(718);
			match(TREAT);
			setState(719);
			match(T__1);
			setState(720);
			general_derived_path();
			setState(721);
			match(AS);
			setState(722);
			subtype();
			setState(723);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Derived_collection_member_declarationContext extends ParserRuleContext {
		public TerminalNode IN() { return getToken(JpqlParser.IN, 0); }
		public Superquery_identification_variableContext superquery_identification_variable() {
			return getRuleContext(Superquery_identification_variableContext.class,0);
		}
		public Collection_valued_fieldContext collection_valued_field() {
			return getRuleContext(Collection_valued_fieldContext.class,0);
		}
		public List<Single_valued_object_fieldContext> single_valued_object_field() {
			return getRuleContexts(Single_valued_object_fieldContext.class);
		}
		public Single_valued_object_fieldContext single_valued_object_field(int i) {
			return getRuleContext(Single_valued_object_fieldContext.class,i);
		}
		public Derived_collection_member_declarationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_derived_collection_member_declaration; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterDerived_collection_member_declaration(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitDerived_collection_member_declaration(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitDerived_collection_member_declaration(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Derived_collection_member_declarationContext derived_collection_member_declaration() throws RecognitionException {
		Derived_collection_member_declarationContext _localctx = new Derived_collection_member_declarationContext(_ctx, getState());
		enterRule(_localctx, 104, RULE_derived_collection_member_declaration);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(725);
			match(IN);
			setState(726);
			superquery_identification_variable();
			setState(727);
			match(T__3);
			setState(733);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,67,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(728);
					single_valued_object_field();
					setState(729);
					match(T__3);
					}
					} 
				}
				setState(735);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,67,_ctx);
			}
			setState(736);
			collection_valued_field();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Simple_select_clauseContext extends ParserRuleContext {
		public TerminalNode SELECT() { return getToken(JpqlParser.SELECT, 0); }
		public Simple_select_expressionContext simple_select_expression() {
			return getRuleContext(Simple_select_expressionContext.class,0);
		}
		public TerminalNode DISTINCT() { return getToken(JpqlParser.DISTINCT, 0); }
		public Simple_select_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simple_select_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSimple_select_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSimple_select_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSimple_select_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Simple_select_clauseContext simple_select_clause() throws RecognitionException {
		Simple_select_clauseContext _localctx = new Simple_select_clauseContext(_ctx, getState());
		enterRule(_localctx, 106, RULE_simple_select_clause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(738);
			match(SELECT);
			setState(740);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==DISTINCT) {
				{
				setState(739);
				match(DISTINCT);
				}
			}

			setState(742);
			simple_select_expression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Simple_select_expressionContext extends ParserRuleContext {
		public Single_valued_path_expressionContext single_valued_path_expression() {
			return getRuleContext(Single_valued_path_expressionContext.class,0);
		}
		public Scalar_expressionContext scalar_expression() {
			return getRuleContext(Scalar_expressionContext.class,0);
		}
		public Aggregate_expressionContext aggregate_expression() {
			return getRuleContext(Aggregate_expressionContext.class,0);
		}
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Simple_select_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simple_select_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSimple_select_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSimple_select_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSimple_select_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Simple_select_expressionContext simple_select_expression() throws RecognitionException {
		Simple_select_expressionContext _localctx = new Simple_select_expressionContext(_ctx, getState());
		enterRule(_localctx, 108, RULE_simple_select_expression);
		try {
			setState(748);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,69,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(744);
				single_valued_path_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(745);
				scalar_expression();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(746);
				aggregate_expression();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(747);
				identification_variable();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Scalar_expressionContext extends ParserRuleContext {
		public Arithmetic_expressionContext arithmetic_expression() {
			return getRuleContext(Arithmetic_expressionContext.class,0);
		}
		public String_expressionContext string_expression() {
			return getRuleContext(String_expressionContext.class,0);
		}
		public Enum_expressionContext enum_expression() {
			return getRuleContext(Enum_expressionContext.class,0);
		}
		public Datetime_expressionContext datetime_expression() {
			return getRuleContext(Datetime_expressionContext.class,0);
		}
		public Boolean_expressionContext boolean_expression() {
			return getRuleContext(Boolean_expressionContext.class,0);
		}
		public Case_expressionContext case_expression() {
			return getRuleContext(Case_expressionContext.class,0);
		}
		public Entity_type_expressionContext entity_type_expression() {
			return getRuleContext(Entity_type_expressionContext.class,0);
		}
		public Scalar_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_scalar_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterScalar_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitScalar_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitScalar_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Scalar_expressionContext scalar_expression() throws RecognitionException {
		Scalar_expressionContext _localctx = new Scalar_expressionContext(_ctx, getState());
		enterRule(_localctx, 110, RULE_scalar_expression);
		try {
			setState(757);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,70,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(750);
				arithmetic_expression(0);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(751);
				string_expression();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(752);
				enum_expression();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(753);
				datetime_expression();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(754);
				boolean_expression();
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(755);
				case_expression();
				}
				break;
			case 7:
				enterOuterAlt(_localctx, 7);
				{
				setState(756);
				entity_type_expression();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Conditional_expressionContext extends ParserRuleContext {
		public Conditional_termContext conditional_term() {
			return getRuleContext(Conditional_termContext.class,0);
		}
		public Conditional_expressionContext conditional_expression() {
			return getRuleContext(Conditional_expressionContext.class,0);
		}
		public TerminalNode OR() { return getToken(JpqlParser.OR, 0); }
		public Conditional_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_conditional_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterConditional_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitConditional_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitConditional_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Conditional_expressionContext conditional_expression() throws RecognitionException {
		return conditional_expression(0);
	}

	private Conditional_expressionContext conditional_expression(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		Conditional_expressionContext _localctx = new Conditional_expressionContext(_ctx, _parentState);
		Conditional_expressionContext _prevctx = _localctx;
		int _startState = 112;
		enterRecursionRule(_localctx, 112, RULE_conditional_expression, _p);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			{
			setState(760);
			conditional_term(0);
			}
			_ctx.stop = _input.LT(-1);
			setState(767);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,71,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					{
					_localctx = new Conditional_expressionContext(_parentctx, _parentState);
					pushNewRecursionContext(_localctx, _startState, RULE_conditional_expression);
					setState(762);
					if (!(precpred(_ctx, 1))) throw new FailedPredicateException(this, "precpred(_ctx, 1)");
					setState(763);
					match(OR);
					setState(764);
					conditional_term(0);
					}
					} 
				}
				setState(769);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,71,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Conditional_termContext extends ParserRuleContext {
		public Conditional_factorContext conditional_factor() {
			return getRuleContext(Conditional_factorContext.class,0);
		}
		public Conditional_termContext conditional_term() {
			return getRuleContext(Conditional_termContext.class,0);
		}
		public TerminalNode AND() { return getToken(JpqlParser.AND, 0); }
		public Conditional_termContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_conditional_term; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterConditional_term(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitConditional_term(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitConditional_term(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Conditional_termContext conditional_term() throws RecognitionException {
		return conditional_term(0);
	}

	private Conditional_termContext conditional_term(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		Conditional_termContext _localctx = new Conditional_termContext(_ctx, _parentState);
		Conditional_termContext _prevctx = _localctx;
		int _startState = 114;
		enterRecursionRule(_localctx, 114, RULE_conditional_term, _p);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			{
			setState(771);
			conditional_factor();
			}
			_ctx.stop = _input.LT(-1);
			setState(778);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,72,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					{
					_localctx = new Conditional_termContext(_parentctx, _parentState);
					pushNewRecursionContext(_localctx, _startState, RULE_conditional_term);
					setState(773);
					if (!(precpred(_ctx, 1))) throw new FailedPredicateException(this, "precpred(_ctx, 1)");
					setState(774);
					match(AND);
					setState(775);
					conditional_factor();
					}
					} 
				}
				setState(780);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,72,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Conditional_factorContext extends ParserRuleContext {
		public Conditional_primaryContext conditional_primary() {
			return getRuleContext(Conditional_primaryContext.class,0);
		}
		public TerminalNode NOT() { return getToken(JpqlParser.NOT, 0); }
		public Conditional_factorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_conditional_factor; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterConditional_factor(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitConditional_factor(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitConditional_factor(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Conditional_factorContext conditional_factor() throws RecognitionException {
		Conditional_factorContext _localctx = new Conditional_factorContext(_ctx, getState());
		enterRule(_localctx, 116, RULE_conditional_factor);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(782);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,73,_ctx) ) {
			case 1:
				{
				setState(781);
				match(NOT);
				}
				break;
			}
			setState(784);
			conditional_primary();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Conditional_primaryContext extends ParserRuleContext {
		public Simple_cond_expressionContext simple_cond_expression() {
			return getRuleContext(Simple_cond_expressionContext.class,0);
		}
		public Conditional_expressionContext conditional_expression() {
			return getRuleContext(Conditional_expressionContext.class,0);
		}
		public Conditional_primaryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_conditional_primary; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterConditional_primary(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitConditional_primary(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitConditional_primary(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Conditional_primaryContext conditional_primary() throws RecognitionException {
		Conditional_primaryContext _localctx = new Conditional_primaryContext(_ctx, getState());
		enterRule(_localctx, 118, RULE_conditional_primary);
		try {
			setState(791);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,74,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(786);
				simple_cond_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(787);
				match(T__1);
				setState(788);
				conditional_expression(0);
				setState(789);
				match(T__2);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Simple_cond_expressionContext extends ParserRuleContext {
		public Comparison_expressionContext comparison_expression() {
			return getRuleContext(Comparison_expressionContext.class,0);
		}
		public Between_expressionContext between_expression() {
			return getRuleContext(Between_expressionContext.class,0);
		}
		public In_expressionContext in_expression() {
			return getRuleContext(In_expressionContext.class,0);
		}
		public Like_expressionContext like_expression() {
			return getRuleContext(Like_expressionContext.class,0);
		}
		public Null_comparison_expressionContext null_comparison_expression() {
			return getRuleContext(Null_comparison_expressionContext.class,0);
		}
		public Empty_collection_comparison_expressionContext empty_collection_comparison_expression() {
			return getRuleContext(Empty_collection_comparison_expressionContext.class,0);
		}
		public Collection_member_expressionContext collection_member_expression() {
			return getRuleContext(Collection_member_expressionContext.class,0);
		}
		public Exists_expressionContext exists_expression() {
			return getRuleContext(Exists_expressionContext.class,0);
		}
		public Simple_cond_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simple_cond_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSimple_cond_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSimple_cond_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSimple_cond_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Simple_cond_expressionContext simple_cond_expression() throws RecognitionException {
		Simple_cond_expressionContext _localctx = new Simple_cond_expressionContext(_ctx, getState());
		enterRule(_localctx, 120, RULE_simple_cond_expression);
		try {
			setState(801);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,75,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(793);
				comparison_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(794);
				between_expression();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(795);
				in_expression();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(796);
				like_expression();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(797);
				null_comparison_expression();
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(798);
				empty_collection_comparison_expression();
				}
				break;
			case 7:
				enterOuterAlt(_localctx, 7);
				{
				setState(799);
				collection_member_expression();
				}
				break;
			case 8:
				enterOuterAlt(_localctx, 8);
				{
				setState(800);
				exists_expression();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Between_expressionContext extends ParserRuleContext {
		public List<Arithmetic_expressionContext> arithmetic_expression() {
			return getRuleContexts(Arithmetic_expressionContext.class);
		}
		public Arithmetic_expressionContext arithmetic_expression(int i) {
			return getRuleContext(Arithmetic_expressionContext.class,i);
		}
		public TerminalNode BETWEEN() { return getToken(JpqlParser.BETWEEN, 0); }
		public TerminalNode AND() { return getToken(JpqlParser.AND, 0); }
		public TerminalNode NOT() { return getToken(JpqlParser.NOT, 0); }
		public List<String_expressionContext> string_expression() {
			return getRuleContexts(String_expressionContext.class);
		}
		public String_expressionContext string_expression(int i) {
			return getRuleContext(String_expressionContext.class,i);
		}
		public List<Datetime_expressionContext> datetime_expression() {
			return getRuleContexts(Datetime_expressionContext.class);
		}
		public Datetime_expressionContext datetime_expression(int i) {
			return getRuleContext(Datetime_expressionContext.class,i);
		}
		public Between_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_between_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterBetween_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitBetween_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitBetween_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Between_expressionContext between_expression() throws RecognitionException {
		Between_expressionContext _localctx = new Between_expressionContext(_ctx, getState());
		enterRule(_localctx, 122, RULE_between_expression);
		int _la;
		try {
			setState(830);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,79,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(803);
				arithmetic_expression(0);
				setState(805);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==NOT) {
					{
					setState(804);
					match(NOT);
					}
				}

				setState(807);
				match(BETWEEN);
				setState(808);
				arithmetic_expression(0);
				setState(809);
				match(AND);
				setState(810);
				arithmetic_expression(0);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(812);
				string_expression();
				setState(814);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==NOT) {
					{
					setState(813);
					match(NOT);
					}
				}

				setState(816);
				match(BETWEEN);
				setState(817);
				string_expression();
				setState(818);
				match(AND);
				setState(819);
				string_expression();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(821);
				datetime_expression();
				setState(823);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==NOT) {
					{
					setState(822);
					match(NOT);
					}
				}

				setState(825);
				match(BETWEEN);
				setState(826);
				datetime_expression();
				setState(827);
				match(AND);
				setState(828);
				datetime_expression();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class In_expressionContext extends ParserRuleContext {
		public TerminalNode IN() { return getToken(JpqlParser.IN, 0); }
		public String_expressionContext string_expression() {
			return getRuleContext(String_expressionContext.class,0);
		}
		public Type_discriminatorContext type_discriminator() {
			return getRuleContext(Type_discriminatorContext.class,0);
		}
		public Collection_valued_input_parameterContext collection_valued_input_parameter() {
			return getRuleContext(Collection_valued_input_parameterContext.class,0);
		}
		public TerminalNode NOT() { return getToken(JpqlParser.NOT, 0); }
		public List<In_itemContext> in_item() {
			return getRuleContexts(In_itemContext.class);
		}
		public In_itemContext in_item(int i) {
			return getRuleContext(In_itemContext.class,i);
		}
		public SubqueryContext subquery() {
			return getRuleContext(SubqueryContext.class,0);
		}
		public In_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_in_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterIn_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitIn_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitIn_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final In_expressionContext in_expression() throws RecognitionException {
		In_expressionContext _localctx = new In_expressionContext(_ctx, getState());
		enterRule(_localctx, 124, RULE_in_expression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(834);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,80,_ctx) ) {
			case 1:
				{
				setState(832);
				string_expression();
				}
				break;
			case 2:
				{
				setState(833);
				type_discriminator();
				}
				break;
			}
			setState(837);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NOT) {
				{
				setState(836);
				match(NOT);
				}
			}

			setState(839);
			match(IN);
			setState(856);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,83,_ctx) ) {
			case 1:
				{
				{
				setState(840);
				match(T__1);
				setState(841);
				in_item();
				setState(846);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__0) {
					{
					{
					setState(842);
					match(T__0);
					setState(843);
					in_item();
					}
					}
					setState(848);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(849);
				match(T__2);
				}
				}
				break;
			case 2:
				{
				{
				setState(851);
				match(T__1);
				setState(852);
				subquery();
				setState(853);
				match(T__2);
				}
				}
				break;
			case 3:
				{
				setState(855);
				collection_valued_input_parameter();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class In_itemContext extends ParserRuleContext {
		public LiteralContext literal() {
			return getRuleContext(LiteralContext.class,0);
		}
		public String_expressionContext string_expression() {
			return getRuleContext(String_expressionContext.class,0);
		}
		public Boolean_literalContext boolean_literal() {
			return getRuleContext(Boolean_literalContext.class,0);
		}
		public Numeric_literalContext numeric_literal() {
			return getRuleContext(Numeric_literalContext.class,0);
		}
		public Date_time_timestamp_literalContext date_time_timestamp_literal() {
			return getRuleContext(Date_time_timestamp_literalContext.class,0);
		}
		public Single_valued_input_parameterContext single_valued_input_parameter() {
			return getRuleContext(Single_valued_input_parameterContext.class,0);
		}
		public Conditional_expressionContext conditional_expression() {
			return getRuleContext(Conditional_expressionContext.class,0);
		}
		public In_itemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_in_item; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterIn_item(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitIn_item(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitIn_item(this);
			else return visitor.visitChildren(this);
		}
	}

	public final In_itemContext in_item() throws RecognitionException {
		In_itemContext _localctx = new In_itemContext(_ctx, getState());
		enterRule(_localctx, 126, RULE_in_item);
		try {
			setState(865);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,84,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(858);
				literal();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(859);
				string_expression();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(860);
				boolean_literal();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(861);
				numeric_literal();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(862);
				date_time_timestamp_literal();
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(863);
				single_valued_input_parameter();
				}
				break;
			case 7:
				enterOuterAlt(_localctx, 7);
				{
				setState(864);
				conditional_expression(0);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Like_expressionContext extends ParserRuleContext {
		public String_expressionContext string_expression() {
			return getRuleContext(String_expressionContext.class,0);
		}
		public TerminalNode LIKE() { return getToken(JpqlParser.LIKE, 0); }
		public Pattern_valueContext pattern_value() {
			return getRuleContext(Pattern_valueContext.class,0);
		}
		public TerminalNode NOT() { return getToken(JpqlParser.NOT, 0); }
		public TerminalNode ESCAPE() { return getToken(JpqlParser.ESCAPE, 0); }
		public Escape_characterContext escape_character() {
			return getRuleContext(Escape_characterContext.class,0);
		}
		public Like_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_like_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterLike_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitLike_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitLike_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Like_expressionContext like_expression() throws RecognitionException {
		Like_expressionContext _localctx = new Like_expressionContext(_ctx, getState());
		enterRule(_localctx, 128, RULE_like_expression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(867);
			string_expression();
			setState(869);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NOT) {
				{
				setState(868);
				match(NOT);
				}
			}

			setState(871);
			match(LIKE);
			setState(872);
			pattern_value();
			setState(875);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,86,_ctx) ) {
			case 1:
				{
				setState(873);
				match(ESCAPE);
				setState(874);
				escape_character();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Null_comparison_expressionContext extends ParserRuleContext {
		public TerminalNode IS() { return getToken(JpqlParser.IS, 0); }
		public TerminalNode NULL() { return getToken(JpqlParser.NULL, 0); }
		public Single_valued_path_expressionContext single_valued_path_expression() {
			return getRuleContext(Single_valued_path_expressionContext.class,0);
		}
		public Input_parameterContext input_parameter() {
			return getRuleContext(Input_parameterContext.class,0);
		}
		public TerminalNode NOT() { return getToken(JpqlParser.NOT, 0); }
		public Null_comparison_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_null_comparison_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterNull_comparison_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitNull_comparison_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitNull_comparison_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Null_comparison_expressionContext null_comparison_expression() throws RecognitionException {
		Null_comparison_expressionContext _localctx = new Null_comparison_expressionContext(_ctx, getState());
		enterRule(_localctx, 130, RULE_null_comparison_expression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(879);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case COUNT:
			case DATE:
			case ENTRY:
			case FLOOR:
			case FROM:
			case INNER:
			case KEY:
			case LEFT:
			case NEW:
			case ORDER:
			case OUTER:
			case POWER:
			case SIGN:
			case TIME:
			case TREAT:
			case TYPE:
			case VALUE:
			case IDENTIFICATION_VARIABLE:
				{
				setState(877);
				single_valued_path_expression();
				}
				break;
			case T__12:
			case T__13:
				{
				setState(878);
				input_parameter();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(881);
			match(IS);
			setState(883);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NOT) {
				{
				setState(882);
				match(NOT);
				}
			}

			setState(885);
			match(NULL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Empty_collection_comparison_expressionContext extends ParserRuleContext {
		public Collection_valued_path_expressionContext collection_valued_path_expression() {
			return getRuleContext(Collection_valued_path_expressionContext.class,0);
		}
		public TerminalNode IS() { return getToken(JpqlParser.IS, 0); }
		public TerminalNode EMPTY() { return getToken(JpqlParser.EMPTY, 0); }
		public TerminalNode NOT() { return getToken(JpqlParser.NOT, 0); }
		public Empty_collection_comparison_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_empty_collection_comparison_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterEmpty_collection_comparison_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitEmpty_collection_comparison_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitEmpty_collection_comparison_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Empty_collection_comparison_expressionContext empty_collection_comparison_expression() throws RecognitionException {
		Empty_collection_comparison_expressionContext _localctx = new Empty_collection_comparison_expressionContext(_ctx, getState());
		enterRule(_localctx, 132, RULE_empty_collection_comparison_expression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(887);
			collection_valued_path_expression();
			setState(888);
			match(IS);
			setState(890);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NOT) {
				{
				setState(889);
				match(NOT);
				}
			}

			setState(892);
			match(EMPTY);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Collection_member_expressionContext extends ParserRuleContext {
		public Entity_or_value_expressionContext entity_or_value_expression() {
			return getRuleContext(Entity_or_value_expressionContext.class,0);
		}
		public TerminalNode MEMBER() { return getToken(JpqlParser.MEMBER, 0); }
		public Collection_valued_path_expressionContext collection_valued_path_expression() {
			return getRuleContext(Collection_valued_path_expressionContext.class,0);
		}
		public TerminalNode NOT() { return getToken(JpqlParser.NOT, 0); }
		public TerminalNode OF() { return getToken(JpqlParser.OF, 0); }
		public Collection_member_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_collection_member_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterCollection_member_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitCollection_member_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitCollection_member_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Collection_member_expressionContext collection_member_expression() throws RecognitionException {
		Collection_member_expressionContext _localctx = new Collection_member_expressionContext(_ctx, getState());
		enterRule(_localctx, 134, RULE_collection_member_expression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(894);
			entity_or_value_expression();
			setState(896);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NOT) {
				{
				setState(895);
				match(NOT);
				}
			}

			setState(898);
			match(MEMBER);
			setState(900);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==OF) {
				{
				setState(899);
				match(OF);
				}
			}

			setState(902);
			collection_valued_path_expression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Entity_or_value_expressionContext extends ParserRuleContext {
		public Single_valued_object_path_expressionContext single_valued_object_path_expression() {
			return getRuleContext(Single_valued_object_path_expressionContext.class,0);
		}
		public State_field_path_expressionContext state_field_path_expression() {
			return getRuleContext(State_field_path_expressionContext.class,0);
		}
		public Simple_entity_or_value_expressionContext simple_entity_or_value_expression() {
			return getRuleContext(Simple_entity_or_value_expressionContext.class,0);
		}
		public Entity_or_value_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_entity_or_value_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterEntity_or_value_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitEntity_or_value_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitEntity_or_value_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Entity_or_value_expressionContext entity_or_value_expression() throws RecognitionException {
		Entity_or_value_expressionContext _localctx = new Entity_or_value_expressionContext(_ctx, getState());
		enterRule(_localctx, 136, RULE_entity_or_value_expression);
		try {
			setState(907);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,92,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(904);
				single_valued_object_path_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(905);
				state_field_path_expression();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(906);
				simple_entity_or_value_expression();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Simple_entity_or_value_expressionContext extends ParserRuleContext {
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Input_parameterContext input_parameter() {
			return getRuleContext(Input_parameterContext.class,0);
		}
		public LiteralContext literal() {
			return getRuleContext(LiteralContext.class,0);
		}
		public Simple_entity_or_value_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simple_entity_or_value_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSimple_entity_or_value_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSimple_entity_or_value_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSimple_entity_or_value_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Simple_entity_or_value_expressionContext simple_entity_or_value_expression() throws RecognitionException {
		Simple_entity_or_value_expressionContext _localctx = new Simple_entity_or_value_expressionContext(_ctx, getState());
		enterRule(_localctx, 138, RULE_simple_entity_or_value_expression);
		try {
			setState(912);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,93,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(909);
				identification_variable();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(910);
				input_parameter();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(911);
				literal();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Exists_expressionContext extends ParserRuleContext {
		public TerminalNode EXISTS() { return getToken(JpqlParser.EXISTS, 0); }
		public SubqueryContext subquery() {
			return getRuleContext(SubqueryContext.class,0);
		}
		public TerminalNode NOT() { return getToken(JpqlParser.NOT, 0); }
		public Exists_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_exists_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterExists_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitExists_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitExists_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Exists_expressionContext exists_expression() throws RecognitionException {
		Exists_expressionContext _localctx = new Exists_expressionContext(_ctx, getState());
		enterRule(_localctx, 140, RULE_exists_expression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(915);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NOT) {
				{
				setState(914);
				match(NOT);
				}
			}

			setState(917);
			match(EXISTS);
			setState(918);
			match(T__1);
			setState(919);
			subquery();
			setState(920);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class All_or_any_expressionContext extends ParserRuleContext {
		public SubqueryContext subquery() {
			return getRuleContext(SubqueryContext.class,0);
		}
		public TerminalNode ALL() { return getToken(JpqlParser.ALL, 0); }
		public TerminalNode ANY() { return getToken(JpqlParser.ANY, 0); }
		public TerminalNode SOME() { return getToken(JpqlParser.SOME, 0); }
		public All_or_any_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_all_or_any_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterAll_or_any_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitAll_or_any_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitAll_or_any_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final All_or_any_expressionContext all_or_any_expression() throws RecognitionException {
		All_or_any_expressionContext _localctx = new All_or_any_expressionContext(_ctx, getState());
		enterRule(_localctx, 142, RULE_all_or_any_expression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(922);
			_la = _input.LA(1);
			if ( !(_la==ALL || _la==ANY || _la==SOME) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(923);
			match(T__1);
			setState(924);
			subquery();
			setState(925);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Comparison_expressionContext extends ParserRuleContext {
		public Comparison_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_comparison_expression; }
	 
		public Comparison_expressionContext() { }
		public void copyFrom(Comparison_expressionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class BooleanComparisonContext extends Comparison_expressionContext {
		public Token op;
		public List<Boolean_expressionContext> boolean_expression() {
			return getRuleContexts(Boolean_expressionContext.class);
		}
		public Boolean_expressionContext boolean_expression(int i) {
			return getRuleContext(Boolean_expressionContext.class,i);
		}
		public TerminalNode EQUAL() { return getToken(JpqlParser.EQUAL, 0); }
		public TerminalNode NOT_EQUAL() { return getToken(JpqlParser.NOT_EQUAL, 0); }
		public All_or_any_expressionContext all_or_any_expression() {
			return getRuleContext(All_or_any_expressionContext.class,0);
		}
		public BooleanComparisonContext(Comparison_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterBooleanComparison(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitBooleanComparison(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitBooleanComparison(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class DirectBooleanCheckContext extends Comparison_expressionContext {
		public Boolean_expressionContext boolean_expression() {
			return getRuleContext(Boolean_expressionContext.class,0);
		}
		public DirectBooleanCheckContext(Comparison_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterDirectBooleanCheck(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitDirectBooleanCheck(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitDirectBooleanCheck(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class StringComparisonContext extends Comparison_expressionContext {
		public List<String_expressionContext> string_expression() {
			return getRuleContexts(String_expressionContext.class);
		}
		public String_expressionContext string_expression(int i) {
			return getRuleContext(String_expressionContext.class,i);
		}
		public Comparison_operatorContext comparison_operator() {
			return getRuleContext(Comparison_operatorContext.class,0);
		}
		public All_or_any_expressionContext all_or_any_expression() {
			return getRuleContext(All_or_any_expressionContext.class,0);
		}
		public StringComparisonContext(Comparison_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterStringComparison(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitStringComparison(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitStringComparison(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class EntityComparisonContext extends Comparison_expressionContext {
		public Token op;
		public List<Entity_expressionContext> entity_expression() {
			return getRuleContexts(Entity_expressionContext.class);
		}
		public Entity_expressionContext entity_expression(int i) {
			return getRuleContext(Entity_expressionContext.class,i);
		}
		public TerminalNode EQUAL() { return getToken(JpqlParser.EQUAL, 0); }
		public TerminalNode NOT_EQUAL() { return getToken(JpqlParser.NOT_EQUAL, 0); }
		public All_or_any_expressionContext all_or_any_expression() {
			return getRuleContext(All_or_any_expressionContext.class,0);
		}
		public EntityComparisonContext(Comparison_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterEntityComparison(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitEntityComparison(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitEntityComparison(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class DatetimeComparisonContext extends Comparison_expressionContext {
		public List<Datetime_expressionContext> datetime_expression() {
			return getRuleContexts(Datetime_expressionContext.class);
		}
		public Datetime_expressionContext datetime_expression(int i) {
			return getRuleContext(Datetime_expressionContext.class,i);
		}
		public Comparison_operatorContext comparison_operator() {
			return getRuleContext(Comparison_operatorContext.class,0);
		}
		public All_or_any_expressionContext all_or_any_expression() {
			return getRuleContext(All_or_any_expressionContext.class,0);
		}
		public DatetimeComparisonContext(Comparison_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterDatetimeComparison(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitDatetimeComparison(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitDatetimeComparison(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class EntityTypeComparisonContext extends Comparison_expressionContext {
		public Token op;
		public List<Entity_type_expressionContext> entity_type_expression() {
			return getRuleContexts(Entity_type_expressionContext.class);
		}
		public Entity_type_expressionContext entity_type_expression(int i) {
			return getRuleContext(Entity_type_expressionContext.class,i);
		}
		public TerminalNode EQUAL() { return getToken(JpqlParser.EQUAL, 0); }
		public TerminalNode NOT_EQUAL() { return getToken(JpqlParser.NOT_EQUAL, 0); }
		public EntityTypeComparisonContext(Comparison_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterEntityTypeComparison(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitEntityTypeComparison(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitEntityTypeComparison(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class RegexpComparisonContext extends Comparison_expressionContext {
		public String_expressionContext string_expression() {
			return getRuleContext(String_expressionContext.class,0);
		}
		public TerminalNode REGEXP() { return getToken(JpqlParser.REGEXP, 0); }
		public String_literalContext string_literal() {
			return getRuleContext(String_literalContext.class,0);
		}
		public RegexpComparisonContext(Comparison_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterRegexpComparison(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitRegexpComparison(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitRegexpComparison(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class EnumComparisonContext extends Comparison_expressionContext {
		public Token op;
		public List<Enum_expressionContext> enum_expression() {
			return getRuleContexts(Enum_expressionContext.class);
		}
		public Enum_expressionContext enum_expression(int i) {
			return getRuleContext(Enum_expressionContext.class,i);
		}
		public TerminalNode EQUAL() { return getToken(JpqlParser.EQUAL, 0); }
		public TerminalNode NOT_EQUAL() { return getToken(JpqlParser.NOT_EQUAL, 0); }
		public All_or_any_expressionContext all_or_any_expression() {
			return getRuleContext(All_or_any_expressionContext.class,0);
		}
		public EnumComparisonContext(Comparison_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterEnumComparison(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitEnumComparison(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitEnumComparison(this);
			else return visitor.visitChildren(this);
		}
	}
	@SuppressWarnings("CheckReturnValue")
	public static class ArithmeticComparisonContext extends Comparison_expressionContext {
		public List<Arithmetic_expressionContext> arithmetic_expression() {
			return getRuleContexts(Arithmetic_expressionContext.class);
		}
		public Arithmetic_expressionContext arithmetic_expression(int i) {
			return getRuleContext(Arithmetic_expressionContext.class,i);
		}
		public Comparison_operatorContext comparison_operator() {
			return getRuleContext(Comparison_operatorContext.class,0);
		}
		public All_or_any_expressionContext all_or_any_expression() {
			return getRuleContext(All_or_any_expressionContext.class,0);
		}
		public ArithmeticComparisonContext(Comparison_expressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterArithmeticComparison(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitArithmeticComparison(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitArithmeticComparison(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Comparison_expressionContext comparison_expression() throws RecognitionException {
		Comparison_expressionContext _localctx = new Comparison_expressionContext(_ctx, getState());
		enterRule(_localctx, 144, RULE_comparison_expression);
		int _la;
		try {
			setState(972);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,101,_ctx) ) {
			case 1:
				_localctx = new StringComparisonContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(927);
				string_expression();
				setState(928);
				comparison_operator();
				setState(931);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case T__1:
				case T__12:
				case T__13:
				case AVG:
				case CASE:
				case CAST:
				case COALESCE:
				case CONCAT:
				case COUNT:
				case DATE:
				case FLOOR:
				case FROM:
				case FUNCTION:
				case INNER:
				case KEY:
				case LEFT:
				case LOWER:
				case MAX:
				case MIN:
				case NEW:
				case NULLIF:
				case ORDER:
				case OUTER:
				case POWER:
				case SIGN:
				case SUBSTRING:
				case SUM:
				case TIME:
				case TREAT:
				case TRIM:
				case TYPE:
				case UPPER:
				case VALUE:
				case CHARACTER:
				case IDENTIFICATION_VARIABLE:
				case STRINGLITERAL:
					{
					setState(929);
					string_expression();
					}
					break;
				case ALL:
				case ANY:
				case SOME:
					{
					setState(930);
					all_or_any_expression();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				break;
			case 2:
				_localctx = new BooleanComparisonContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(933);
				boolean_expression();
				setState(934);
				((BooleanComparisonContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==EQUAL || _la==NOT_EQUAL) ) {
					((BooleanComparisonContext)_localctx).op = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(937);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case T__1:
				case T__12:
				case T__13:
				case CASE:
				case COALESCE:
				case COUNT:
				case DATE:
				case FALSE:
				case FLOOR:
				case FROM:
				case FUNCTION:
				case INNER:
				case KEY:
				case LEFT:
				case NEW:
				case NULLIF:
				case ORDER:
				case OUTER:
				case POWER:
				case SIGN:
				case TIME:
				case TREAT:
				case TRUE:
				case TYPE:
				case VALUE:
				case IDENTIFICATION_VARIABLE:
					{
					setState(935);
					boolean_expression();
					}
					break;
				case ALL:
				case ANY:
				case SOME:
					{
					setState(936);
					all_or_any_expression();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				break;
			case 3:
				_localctx = new DirectBooleanCheckContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(939);
				boolean_expression();
				}
				break;
			case 4:
				_localctx = new EnumComparisonContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(940);
				enum_expression();
				setState(941);
				((EnumComparisonContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==EQUAL || _la==NOT_EQUAL) ) {
					((EnumComparisonContext)_localctx).op = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(944);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case T__1:
				case T__12:
				case T__13:
				case CASE:
				case COALESCE:
				case COUNT:
				case DATE:
				case FLOOR:
				case FROM:
				case INNER:
				case KEY:
				case LEFT:
				case NEW:
				case NULLIF:
				case ORDER:
				case OUTER:
				case POWER:
				case SIGN:
				case TIME:
				case TREAT:
				case TYPE:
				case VALUE:
				case IDENTIFICATION_VARIABLE:
					{
					setState(942);
					enum_expression();
					}
					break;
				case ALL:
				case ANY:
				case SOME:
					{
					setState(943);
					all_or_any_expression();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				break;
			case 5:
				_localctx = new DatetimeComparisonContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(946);
				datetime_expression();
				setState(947);
				comparison_operator();
				setState(950);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case T__1:
				case T__12:
				case T__13:
				case AVG:
				case CASE:
				case COALESCE:
				case COUNT:
				case CURRENT_DATE:
				case CURRENT_TIME:
				case CURRENT_TIMESTAMP:
				case DATE:
				case EXTRACT:
				case FLOOR:
				case FROM:
				case FUNCTION:
				case INNER:
				case KEY:
				case LEFT:
				case LOCAL:
				case MAX:
				case MIN:
				case NEW:
				case NULLIF:
				case ORDER:
				case OUTER:
				case POWER:
				case SIGN:
				case SUM:
				case TIME:
				case TREAT:
				case TYPE:
				case VALUE:
				case IDENTIFICATION_VARIABLE:
				case STRINGLITERAL:
					{
					setState(948);
					datetime_expression();
					}
					break;
				case ALL:
				case ANY:
				case SOME:
					{
					setState(949);
					all_or_any_expression();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				break;
			case 6:
				_localctx = new EntityComparisonContext(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(952);
				entity_expression();
				setState(953);
				((EntityComparisonContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==EQUAL || _la==NOT_EQUAL) ) {
					((EntityComparisonContext)_localctx).op = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(956);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case T__12:
				case T__13:
				case COUNT:
				case DATE:
				case FLOOR:
				case FROM:
				case INNER:
				case KEY:
				case LEFT:
				case NEW:
				case ORDER:
				case OUTER:
				case POWER:
				case SIGN:
				case TIME:
				case TREAT:
				case TYPE:
				case VALUE:
				case IDENTIFICATION_VARIABLE:
					{
					setState(954);
					entity_expression();
					}
					break;
				case ALL:
				case ANY:
				case SOME:
					{
					setState(955);
					all_or_any_expression();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				break;
			case 7:
				_localctx = new ArithmeticComparisonContext(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(958);
				arithmetic_expression(0);
				setState(959);
				comparison_operator();
				setState(962);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case T__1:
				case T__8:
				case T__9:
				case T__12:
				case T__13:
				case ABS:
				case AVG:
				case CASE:
				case CAST:
				case CEILING:
				case COALESCE:
				case COUNT:
				case DATE:
				case EXP:
				case EXTRACT:
				case FLOOR:
				case FROM:
				case FUNCTION:
				case INDEX:
				case INNER:
				case KEY:
				case LEFT:
				case LENGTH:
				case LN:
				case LOCATE:
				case MAX:
				case MIN:
				case MOD:
				case NEW:
				case NULLIF:
				case ORDER:
				case OUTER:
				case POWER:
				case ROUND:
				case SIGN:
				case SIZE:
				case SQRT:
				case SUM:
				case TIME:
				case TREAT:
				case TYPE:
				case VALUE:
				case IDENTIFICATION_VARIABLE:
				case FLOATLITERAL:
				case INTLITERAL:
				case LONGLITERAL:
					{
					setState(960);
					arithmetic_expression(0);
					}
					break;
				case ALL:
				case ANY:
				case SOME:
					{
					setState(961);
					all_or_any_expression();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				break;
			case 8:
				_localctx = new EntityTypeComparisonContext(_localctx);
				enterOuterAlt(_localctx, 8);
				{
				setState(964);
				entity_type_expression();
				setState(965);
				((EntityTypeComparisonContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==EQUAL || _la==NOT_EQUAL) ) {
					((EntityTypeComparisonContext)_localctx).op = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(966);
				entity_type_expression();
				}
				break;
			case 9:
				_localctx = new RegexpComparisonContext(_localctx);
				enterOuterAlt(_localctx, 9);
				{
				setState(968);
				string_expression();
				setState(969);
				match(REGEXP);
				setState(970);
				string_literal();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Comparison_operatorContext extends ParserRuleContext {
		public Token op;
		public TerminalNode EQUAL() { return getToken(JpqlParser.EQUAL, 0); }
		public TerminalNode NOT_EQUAL() { return getToken(JpqlParser.NOT_EQUAL, 0); }
		public Comparison_operatorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_comparison_operator; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterComparison_operator(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitComparison_operator(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitComparison_operator(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Comparison_operatorContext comparison_operator() throws RecognitionException {
		Comparison_operatorContext _localctx = new Comparison_operatorContext(_ctx, getState());
		enterRule(_localctx, 146, RULE_comparison_operator);
		try {
			setState(980);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case EQUAL:
				enterOuterAlt(_localctx, 1);
				{
				setState(974);
				((Comparison_operatorContext)_localctx).op = match(EQUAL);
				}
				break;
			case T__4:
				enterOuterAlt(_localctx, 2);
				{
				setState(975);
				((Comparison_operatorContext)_localctx).op = match(T__4);
				}
				break;
			case T__5:
				enterOuterAlt(_localctx, 3);
				{
				setState(976);
				((Comparison_operatorContext)_localctx).op = match(T__5);
				}
				break;
			case T__6:
				enterOuterAlt(_localctx, 4);
				{
				setState(977);
				((Comparison_operatorContext)_localctx).op = match(T__6);
				}
				break;
			case T__7:
				enterOuterAlt(_localctx, 5);
				{
				setState(978);
				((Comparison_operatorContext)_localctx).op = match(T__7);
				}
				break;
			case NOT_EQUAL:
				enterOuterAlt(_localctx, 6);
				{
				setState(979);
				((Comparison_operatorContext)_localctx).op = match(NOT_EQUAL);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Arithmetic_expressionContext extends ParserRuleContext {
		public Token op;
		public Arithmetic_termContext arithmetic_term() {
			return getRuleContext(Arithmetic_termContext.class,0);
		}
		public Arithmetic_expressionContext arithmetic_expression() {
			return getRuleContext(Arithmetic_expressionContext.class,0);
		}
		public Arithmetic_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_arithmetic_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterArithmetic_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitArithmetic_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitArithmetic_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Arithmetic_expressionContext arithmetic_expression() throws RecognitionException {
		return arithmetic_expression(0);
	}

	private Arithmetic_expressionContext arithmetic_expression(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		Arithmetic_expressionContext _localctx = new Arithmetic_expressionContext(_ctx, _parentState);
		Arithmetic_expressionContext _prevctx = _localctx;
		int _startState = 148;
		enterRecursionRule(_localctx, 148, RULE_arithmetic_expression, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			{
			setState(983);
			arithmetic_term(0);
			}
			_ctx.stop = _input.LT(-1);
			setState(990);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,103,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					{
					_localctx = new Arithmetic_expressionContext(_parentctx, _parentState);
					pushNewRecursionContext(_localctx, _startState, RULE_arithmetic_expression);
					setState(985);
					if (!(precpred(_ctx, 1))) throw new FailedPredicateException(this, "precpred(_ctx, 1)");
					setState(986);
					((Arithmetic_expressionContext)_localctx).op = _input.LT(1);
					_la = _input.LA(1);
					if ( !(_la==T__8 || _la==T__9) ) {
						((Arithmetic_expressionContext)_localctx).op = (Token)_errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					setState(987);
					arithmetic_term(0);
					}
					} 
				}
				setState(992);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,103,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Arithmetic_termContext extends ParserRuleContext {
		public Token op;
		public Arithmetic_factorContext arithmetic_factor() {
			return getRuleContext(Arithmetic_factorContext.class,0);
		}
		public Arithmetic_termContext arithmetic_term() {
			return getRuleContext(Arithmetic_termContext.class,0);
		}
		public Arithmetic_termContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_arithmetic_term; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterArithmetic_term(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitArithmetic_term(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitArithmetic_term(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Arithmetic_termContext arithmetic_term() throws RecognitionException {
		return arithmetic_term(0);
	}

	private Arithmetic_termContext arithmetic_term(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		Arithmetic_termContext _localctx = new Arithmetic_termContext(_ctx, _parentState);
		Arithmetic_termContext _prevctx = _localctx;
		int _startState = 150;
		enterRecursionRule(_localctx, 150, RULE_arithmetic_term, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			{
			setState(994);
			arithmetic_factor();
			}
			_ctx.stop = _input.LT(-1);
			setState(1001);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,104,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					{
					_localctx = new Arithmetic_termContext(_parentctx, _parentState);
					pushNewRecursionContext(_localctx, _startState, RULE_arithmetic_term);
					setState(996);
					if (!(precpred(_ctx, 1))) throw new FailedPredicateException(this, "precpred(_ctx, 1)");
					setState(997);
					((Arithmetic_termContext)_localctx).op = _input.LT(1);
					_la = _input.LA(1);
					if ( !(_la==T__10 || _la==T__11) ) {
						((Arithmetic_termContext)_localctx).op = (Token)_errHandler.recoverInline(this);
					}
					else {
						if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
						_errHandler.reportMatch(this);
						consume();
					}
					setState(998);
					arithmetic_factor();
					}
					} 
				}
				setState(1003);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,104,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Arithmetic_factorContext extends ParserRuleContext {
		public Token op;
		public Arithmetic_primaryContext arithmetic_primary() {
			return getRuleContext(Arithmetic_primaryContext.class,0);
		}
		public Arithmetic_factorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_arithmetic_factor; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterArithmetic_factor(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitArithmetic_factor(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitArithmetic_factor(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Arithmetic_factorContext arithmetic_factor() throws RecognitionException {
		Arithmetic_factorContext _localctx = new Arithmetic_factorContext(_ctx, getState());
		enterRule(_localctx, 152, RULE_arithmetic_factor);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1005);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__8 || _la==T__9) {
				{
				setState(1004);
				((Arithmetic_factorContext)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==T__8 || _la==T__9) ) {
					((Arithmetic_factorContext)_localctx).op = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
			}

			setState(1007);
			arithmetic_primary();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Arithmetic_primaryContext extends ParserRuleContext {
		public State_valued_path_expressionContext state_valued_path_expression() {
			return getRuleContext(State_valued_path_expressionContext.class,0);
		}
		public Numeric_literalContext numeric_literal() {
			return getRuleContext(Numeric_literalContext.class,0);
		}
		public Arithmetic_expressionContext arithmetic_expression() {
			return getRuleContext(Arithmetic_expressionContext.class,0);
		}
		public Input_parameterContext input_parameter() {
			return getRuleContext(Input_parameterContext.class,0);
		}
		public Functions_returning_numericsContext functions_returning_numerics() {
			return getRuleContext(Functions_returning_numericsContext.class,0);
		}
		public Aggregate_expressionContext aggregate_expression() {
			return getRuleContext(Aggregate_expressionContext.class,0);
		}
		public Case_expressionContext case_expression() {
			return getRuleContext(Case_expressionContext.class,0);
		}
		public Arithmetic_cast_functionContext arithmetic_cast_function() {
			return getRuleContext(Arithmetic_cast_functionContext.class,0);
		}
		public Type_cast_functionContext type_cast_function() {
			return getRuleContext(Type_cast_functionContext.class,0);
		}
		public Function_invocationContext function_invocation() {
			return getRuleContext(Function_invocationContext.class,0);
		}
		public SubqueryContext subquery() {
			return getRuleContext(SubqueryContext.class,0);
		}
		public Arithmetic_primaryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_arithmetic_primary; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterArithmetic_primary(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitArithmetic_primary(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitArithmetic_primary(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Arithmetic_primaryContext arithmetic_primary() throws RecognitionException {
		Arithmetic_primaryContext _localctx = new Arithmetic_primaryContext(_ctx, getState());
		enterRule(_localctx, 154, RULE_arithmetic_primary);
		try {
			setState(1026);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,106,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1009);
				state_valued_path_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1010);
				numeric_literal();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1011);
				match(T__1);
				setState(1012);
				arithmetic_expression(0);
				setState(1013);
				match(T__2);
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(1015);
				input_parameter();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(1016);
				functions_returning_numerics();
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(1017);
				aggregate_expression();
				}
				break;
			case 7:
				enterOuterAlt(_localctx, 7);
				{
				setState(1018);
				case_expression();
				}
				break;
			case 8:
				enterOuterAlt(_localctx, 8);
				{
				setState(1019);
				arithmetic_cast_function();
				}
				break;
			case 9:
				enterOuterAlt(_localctx, 9);
				{
				setState(1020);
				type_cast_function();
				}
				break;
			case 10:
				enterOuterAlt(_localctx, 10);
				{
				setState(1021);
				function_invocation();
				}
				break;
			case 11:
				enterOuterAlt(_localctx, 11);
				{
				setState(1022);
				match(T__1);
				setState(1023);
				subquery();
				setState(1024);
				match(T__2);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class String_expressionContext extends ParserRuleContext {
		public State_valued_path_expressionContext state_valued_path_expression() {
			return getRuleContext(State_valued_path_expressionContext.class,0);
		}
		public String_literalContext string_literal() {
			return getRuleContext(String_literalContext.class,0);
		}
		public Input_parameterContext input_parameter() {
			return getRuleContext(Input_parameterContext.class,0);
		}
		public Functions_returning_stringsContext functions_returning_strings() {
			return getRuleContext(Functions_returning_stringsContext.class,0);
		}
		public Aggregate_expressionContext aggregate_expression() {
			return getRuleContext(Aggregate_expressionContext.class,0);
		}
		public Case_expressionContext case_expression() {
			return getRuleContext(Case_expressionContext.class,0);
		}
		public Function_invocationContext function_invocation() {
			return getRuleContext(Function_invocationContext.class,0);
		}
		public String_cast_functionContext string_cast_function() {
			return getRuleContext(String_cast_functionContext.class,0);
		}
		public Type_cast_functionContext type_cast_function() {
			return getRuleContext(Type_cast_functionContext.class,0);
		}
		public SubqueryContext subquery() {
			return getRuleContext(SubqueryContext.class,0);
		}
		public String_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_string_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterString_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitString_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitString_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final String_expressionContext string_expression() throws RecognitionException {
		String_expressionContext _localctx = new String_expressionContext(_ctx, getState());
		enterRule(_localctx, 156, RULE_string_expression);
		try {
			setState(1041);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,107,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1028);
				state_valued_path_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1029);
				string_literal();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1030);
				input_parameter();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(1031);
				functions_returning_strings();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(1032);
				aggregate_expression();
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(1033);
				case_expression();
				}
				break;
			case 7:
				enterOuterAlt(_localctx, 7);
				{
				setState(1034);
				function_invocation();
				}
				break;
			case 8:
				enterOuterAlt(_localctx, 8);
				{
				setState(1035);
				string_cast_function();
				}
				break;
			case 9:
				enterOuterAlt(_localctx, 9);
				{
				setState(1036);
				type_cast_function();
				}
				break;
			case 10:
				enterOuterAlt(_localctx, 10);
				{
				setState(1037);
				match(T__1);
				setState(1038);
				subquery();
				setState(1039);
				match(T__2);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Datetime_expressionContext extends ParserRuleContext {
		public State_valued_path_expressionContext state_valued_path_expression() {
			return getRuleContext(State_valued_path_expressionContext.class,0);
		}
		public Input_parameterContext input_parameter() {
			return getRuleContext(Input_parameterContext.class,0);
		}
		public Functions_returning_datetimeContext functions_returning_datetime() {
			return getRuleContext(Functions_returning_datetimeContext.class,0);
		}
		public Aggregate_expressionContext aggregate_expression() {
			return getRuleContext(Aggregate_expressionContext.class,0);
		}
		public Case_expressionContext case_expression() {
			return getRuleContext(Case_expressionContext.class,0);
		}
		public Function_invocationContext function_invocation() {
			return getRuleContext(Function_invocationContext.class,0);
		}
		public Date_time_timestamp_literalContext date_time_timestamp_literal() {
			return getRuleContext(Date_time_timestamp_literalContext.class,0);
		}
		public SubqueryContext subquery() {
			return getRuleContext(SubqueryContext.class,0);
		}
		public Datetime_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_datetime_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterDatetime_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitDatetime_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitDatetime_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Datetime_expressionContext datetime_expression() throws RecognitionException {
		Datetime_expressionContext _localctx = new Datetime_expressionContext(_ctx, getState());
		enterRule(_localctx, 158, RULE_datetime_expression);
		try {
			setState(1054);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,108,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1043);
				state_valued_path_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1044);
				input_parameter();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1045);
				functions_returning_datetime();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(1046);
				aggregate_expression();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(1047);
				case_expression();
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(1048);
				function_invocation();
				}
				break;
			case 7:
				enterOuterAlt(_localctx, 7);
				{
				setState(1049);
				date_time_timestamp_literal();
				}
				break;
			case 8:
				enterOuterAlt(_localctx, 8);
				{
				setState(1050);
				match(T__1);
				setState(1051);
				subquery();
				setState(1052);
				match(T__2);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Boolean_expressionContext extends ParserRuleContext {
		public State_valued_path_expressionContext state_valued_path_expression() {
			return getRuleContext(State_valued_path_expressionContext.class,0);
		}
		public Boolean_literalContext boolean_literal() {
			return getRuleContext(Boolean_literalContext.class,0);
		}
		public Input_parameterContext input_parameter() {
			return getRuleContext(Input_parameterContext.class,0);
		}
		public Case_expressionContext case_expression() {
			return getRuleContext(Case_expressionContext.class,0);
		}
		public Function_invocationContext function_invocation() {
			return getRuleContext(Function_invocationContext.class,0);
		}
		public SubqueryContext subquery() {
			return getRuleContext(SubqueryContext.class,0);
		}
		public Boolean_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_boolean_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterBoolean_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitBoolean_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitBoolean_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Boolean_expressionContext boolean_expression() throws RecognitionException {
		Boolean_expressionContext _localctx = new Boolean_expressionContext(_ctx, getState());
		enterRule(_localctx, 160, RULE_boolean_expression);
		try {
			setState(1065);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case COUNT:
			case DATE:
			case FLOOR:
			case FROM:
			case INNER:
			case KEY:
			case LEFT:
			case NEW:
			case ORDER:
			case OUTER:
			case POWER:
			case SIGN:
			case TIME:
			case TREAT:
			case TYPE:
			case VALUE:
			case IDENTIFICATION_VARIABLE:
				enterOuterAlt(_localctx, 1);
				{
				setState(1056);
				state_valued_path_expression();
				}
				break;
			case FALSE:
			case TRUE:
				enterOuterAlt(_localctx, 2);
				{
				setState(1057);
				boolean_literal();
				}
				break;
			case T__12:
			case T__13:
				enterOuterAlt(_localctx, 3);
				{
				setState(1058);
				input_parameter();
				}
				break;
			case CASE:
			case COALESCE:
			case NULLIF:
				enterOuterAlt(_localctx, 4);
				{
				setState(1059);
				case_expression();
				}
				break;
			case FUNCTION:
				enterOuterAlt(_localctx, 5);
				{
				setState(1060);
				function_invocation();
				}
				break;
			case T__1:
				enterOuterAlt(_localctx, 6);
				{
				setState(1061);
				match(T__1);
				setState(1062);
				subquery();
				setState(1063);
				match(T__2);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Enum_expressionContext extends ParserRuleContext {
		public State_valued_path_expressionContext state_valued_path_expression() {
			return getRuleContext(State_valued_path_expressionContext.class,0);
		}
		public Enum_literalContext enum_literal() {
			return getRuleContext(Enum_literalContext.class,0);
		}
		public Input_parameterContext input_parameter() {
			return getRuleContext(Input_parameterContext.class,0);
		}
		public Case_expressionContext case_expression() {
			return getRuleContext(Case_expressionContext.class,0);
		}
		public SubqueryContext subquery() {
			return getRuleContext(SubqueryContext.class,0);
		}
		public Enum_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_enum_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterEnum_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitEnum_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitEnum_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Enum_expressionContext enum_expression() throws RecognitionException {
		Enum_expressionContext _localctx = new Enum_expressionContext(_ctx, getState());
		enterRule(_localctx, 162, RULE_enum_expression);
		try {
			setState(1075);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,110,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1067);
				state_valued_path_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1068);
				enum_literal();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1069);
				input_parameter();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(1070);
				case_expression();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(1071);
				match(T__1);
				setState(1072);
				subquery();
				setState(1073);
				match(T__2);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Entity_expressionContext extends ParserRuleContext {
		public Single_valued_object_path_expressionContext single_valued_object_path_expression() {
			return getRuleContext(Single_valued_object_path_expressionContext.class,0);
		}
		public Simple_entity_expressionContext simple_entity_expression() {
			return getRuleContext(Simple_entity_expressionContext.class,0);
		}
		public Entity_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_entity_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterEntity_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitEntity_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitEntity_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Entity_expressionContext entity_expression() throws RecognitionException {
		Entity_expressionContext _localctx = new Entity_expressionContext(_ctx, getState());
		enterRule(_localctx, 164, RULE_entity_expression);
		try {
			setState(1079);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,111,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1077);
				single_valued_object_path_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1078);
				simple_entity_expression();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Simple_entity_expressionContext extends ParserRuleContext {
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Input_parameterContext input_parameter() {
			return getRuleContext(Input_parameterContext.class,0);
		}
		public Simple_entity_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simple_entity_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSimple_entity_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSimple_entity_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSimple_entity_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Simple_entity_expressionContext simple_entity_expression() throws RecognitionException {
		Simple_entity_expressionContext _localctx = new Simple_entity_expressionContext(_ctx, getState());
		enterRule(_localctx, 166, RULE_simple_entity_expression);
		try {
			setState(1083);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case COUNT:
			case DATE:
			case FLOOR:
			case FROM:
			case INNER:
			case KEY:
			case LEFT:
			case NEW:
			case ORDER:
			case OUTER:
			case POWER:
			case SIGN:
			case TIME:
			case TYPE:
			case VALUE:
			case IDENTIFICATION_VARIABLE:
				enterOuterAlt(_localctx, 1);
				{
				setState(1081);
				identification_variable();
				}
				break;
			case T__12:
			case T__13:
				enterOuterAlt(_localctx, 2);
				{
				setState(1082);
				input_parameter();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Entity_type_expressionContext extends ParserRuleContext {
		public Type_discriminatorContext type_discriminator() {
			return getRuleContext(Type_discriminatorContext.class,0);
		}
		public Entity_type_literalContext entity_type_literal() {
			return getRuleContext(Entity_type_literalContext.class,0);
		}
		public Input_parameterContext input_parameter() {
			return getRuleContext(Input_parameterContext.class,0);
		}
		public Entity_type_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_entity_type_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterEntity_type_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitEntity_type_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitEntity_type_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Entity_type_expressionContext entity_type_expression() throws RecognitionException {
		Entity_type_expressionContext _localctx = new Entity_type_expressionContext(_ctx, getState());
		enterRule(_localctx, 168, RULE_entity_type_expression);
		try {
			setState(1088);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,113,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1085);
				type_discriminator();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1086);
				entity_type_literal();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1087);
				input_parameter();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Type_discriminatorContext extends ParserRuleContext {
		public TerminalNode TYPE() { return getToken(JpqlParser.TYPE, 0); }
		public General_identification_variableContext general_identification_variable() {
			return getRuleContext(General_identification_variableContext.class,0);
		}
		public Single_valued_object_path_expressionContext single_valued_object_path_expression() {
			return getRuleContext(Single_valued_object_path_expressionContext.class,0);
		}
		public Input_parameterContext input_parameter() {
			return getRuleContext(Input_parameterContext.class,0);
		}
		public Type_discriminatorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_type_discriminator; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterType_discriminator(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitType_discriminator(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitType_discriminator(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Type_discriminatorContext type_discriminator() throws RecognitionException {
		Type_discriminatorContext _localctx = new Type_discriminatorContext(_ctx, getState());
		enterRule(_localctx, 170, RULE_type_discriminator);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1090);
			match(TYPE);
			setState(1091);
			match(T__1);
			setState(1095);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,114,_ctx) ) {
			case 1:
				{
				setState(1092);
				general_identification_variable();
				}
				break;
			case 2:
				{
				setState(1093);
				single_valued_object_path_expression();
				}
				break;
			case 3:
				{
				setState(1094);
				input_parameter();
				}
				break;
			}
			setState(1097);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Functions_returning_numericsContext extends ParserRuleContext {
		public TerminalNode LENGTH() { return getToken(JpqlParser.LENGTH, 0); }
		public List<String_expressionContext> string_expression() {
			return getRuleContexts(String_expressionContext.class);
		}
		public String_expressionContext string_expression(int i) {
			return getRuleContext(String_expressionContext.class,i);
		}
		public TerminalNode LOCATE() { return getToken(JpqlParser.LOCATE, 0); }
		public List<Arithmetic_expressionContext> arithmetic_expression() {
			return getRuleContexts(Arithmetic_expressionContext.class);
		}
		public Arithmetic_expressionContext arithmetic_expression(int i) {
			return getRuleContext(Arithmetic_expressionContext.class,i);
		}
		public TerminalNode ABS() { return getToken(JpqlParser.ABS, 0); }
		public TerminalNode CEILING() { return getToken(JpqlParser.CEILING, 0); }
		public TerminalNode EXP() { return getToken(JpqlParser.EXP, 0); }
		public TerminalNode FLOOR() { return getToken(JpqlParser.FLOOR, 0); }
		public TerminalNode LN() { return getToken(JpqlParser.LN, 0); }
		public TerminalNode SIGN() { return getToken(JpqlParser.SIGN, 0); }
		public TerminalNode SQRT() { return getToken(JpqlParser.SQRT, 0); }
		public TerminalNode MOD() { return getToken(JpqlParser.MOD, 0); }
		public TerminalNode POWER() { return getToken(JpqlParser.POWER, 0); }
		public TerminalNode ROUND() { return getToken(JpqlParser.ROUND, 0); }
		public TerminalNode SIZE() { return getToken(JpqlParser.SIZE, 0); }
		public Collection_valued_path_expressionContext collection_valued_path_expression() {
			return getRuleContext(Collection_valued_path_expressionContext.class,0);
		}
		public TerminalNode INDEX() { return getToken(JpqlParser.INDEX, 0); }
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Extract_datetime_fieldContext extract_datetime_field() {
			return getRuleContext(Extract_datetime_fieldContext.class,0);
		}
		public Functions_returning_numericsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_functions_returning_numerics; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterFunctions_returning_numerics(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitFunctions_returning_numerics(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitFunctions_returning_numerics(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Functions_returning_numericsContext functions_returning_numerics() throws RecognitionException {
		Functions_returning_numericsContext _localctx = new Functions_returning_numericsContext(_ctx, getState());
		enterRule(_localctx, 172, RULE_functions_returning_numerics);
		int _la;
		try {
			setState(1182);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case LENGTH:
				enterOuterAlt(_localctx, 1);
				{
				setState(1099);
				match(LENGTH);
				setState(1100);
				match(T__1);
				setState(1101);
				string_expression();
				setState(1102);
				match(T__2);
				}
				break;
			case LOCATE:
				enterOuterAlt(_localctx, 2);
				{
				setState(1104);
				match(LOCATE);
				setState(1105);
				match(T__1);
				setState(1106);
				string_expression();
				setState(1107);
				match(T__0);
				setState(1108);
				string_expression();
				setState(1111);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==T__0) {
					{
					setState(1109);
					match(T__0);
					setState(1110);
					arithmetic_expression(0);
					}
				}

				setState(1113);
				match(T__2);
				}
				break;
			case ABS:
				enterOuterAlt(_localctx, 3);
				{
				setState(1115);
				match(ABS);
				setState(1116);
				match(T__1);
				setState(1117);
				arithmetic_expression(0);
				setState(1118);
				match(T__2);
				}
				break;
			case CEILING:
				enterOuterAlt(_localctx, 4);
				{
				setState(1120);
				match(CEILING);
				setState(1121);
				match(T__1);
				setState(1122);
				arithmetic_expression(0);
				setState(1123);
				match(T__2);
				}
				break;
			case EXP:
				enterOuterAlt(_localctx, 5);
				{
				setState(1125);
				match(EXP);
				setState(1126);
				match(T__1);
				setState(1127);
				arithmetic_expression(0);
				setState(1128);
				match(T__2);
				}
				break;
			case FLOOR:
				enterOuterAlt(_localctx, 6);
				{
				setState(1130);
				match(FLOOR);
				setState(1131);
				match(T__1);
				setState(1132);
				arithmetic_expression(0);
				setState(1133);
				match(T__2);
				}
				break;
			case LN:
				enterOuterAlt(_localctx, 7);
				{
				setState(1135);
				match(LN);
				setState(1136);
				match(T__1);
				setState(1137);
				arithmetic_expression(0);
				setState(1138);
				match(T__2);
				}
				break;
			case SIGN:
				enterOuterAlt(_localctx, 8);
				{
				setState(1140);
				match(SIGN);
				setState(1141);
				match(T__1);
				setState(1142);
				arithmetic_expression(0);
				setState(1143);
				match(T__2);
				}
				break;
			case SQRT:
				enterOuterAlt(_localctx, 9);
				{
				setState(1145);
				match(SQRT);
				setState(1146);
				match(T__1);
				setState(1147);
				arithmetic_expression(0);
				setState(1148);
				match(T__2);
				}
				break;
			case MOD:
				enterOuterAlt(_localctx, 10);
				{
				setState(1150);
				match(MOD);
				setState(1151);
				match(T__1);
				setState(1152);
				arithmetic_expression(0);
				setState(1153);
				match(T__0);
				setState(1154);
				arithmetic_expression(0);
				setState(1155);
				match(T__2);
				}
				break;
			case POWER:
				enterOuterAlt(_localctx, 11);
				{
				setState(1157);
				match(POWER);
				setState(1158);
				match(T__1);
				setState(1159);
				arithmetic_expression(0);
				setState(1160);
				match(T__0);
				setState(1161);
				arithmetic_expression(0);
				setState(1162);
				match(T__2);
				}
				break;
			case ROUND:
				enterOuterAlt(_localctx, 12);
				{
				setState(1164);
				match(ROUND);
				setState(1165);
				match(T__1);
				setState(1166);
				arithmetic_expression(0);
				setState(1167);
				match(T__0);
				setState(1168);
				arithmetic_expression(0);
				setState(1169);
				match(T__2);
				}
				break;
			case SIZE:
				enterOuterAlt(_localctx, 13);
				{
				setState(1171);
				match(SIZE);
				setState(1172);
				match(T__1);
				setState(1173);
				collection_valued_path_expression();
				setState(1174);
				match(T__2);
				}
				break;
			case INDEX:
				enterOuterAlt(_localctx, 14);
				{
				setState(1176);
				match(INDEX);
				setState(1177);
				match(T__1);
				setState(1178);
				identification_variable();
				setState(1179);
				match(T__2);
				}
				break;
			case EXTRACT:
				enterOuterAlt(_localctx, 15);
				{
				setState(1181);
				extract_datetime_field();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Functions_returning_datetimeContext extends ParserRuleContext {
		public TerminalNode CURRENT_DATE() { return getToken(JpqlParser.CURRENT_DATE, 0); }
		public TerminalNode CURRENT_TIME() { return getToken(JpqlParser.CURRENT_TIME, 0); }
		public TerminalNode CURRENT_TIMESTAMP() { return getToken(JpqlParser.CURRENT_TIMESTAMP, 0); }
		public TerminalNode LOCAL() { return getToken(JpqlParser.LOCAL, 0); }
		public TerminalNode DATE() { return getToken(JpqlParser.DATE, 0); }
		public TerminalNode TIME() { return getToken(JpqlParser.TIME, 0); }
		public TerminalNode DATETIME() { return getToken(JpqlParser.DATETIME, 0); }
		public Extract_datetime_partContext extract_datetime_part() {
			return getRuleContext(Extract_datetime_partContext.class,0);
		}
		public Functions_returning_datetimeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_functions_returning_datetime; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterFunctions_returning_datetime(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitFunctions_returning_datetime(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitFunctions_returning_datetime(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Functions_returning_datetimeContext functions_returning_datetime() throws RecognitionException {
		Functions_returning_datetimeContext _localctx = new Functions_returning_datetimeContext(_ctx, getState());
		enterRule(_localctx, 174, RULE_functions_returning_datetime);
		try {
			setState(1194);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,117,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1184);
				match(CURRENT_DATE);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1185);
				match(CURRENT_TIME);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1186);
				match(CURRENT_TIMESTAMP);
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(1187);
				match(LOCAL);
				setState(1188);
				match(DATE);
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(1189);
				match(LOCAL);
				setState(1190);
				match(TIME);
				}
				break;
			case 6:
				enterOuterAlt(_localctx, 6);
				{
				setState(1191);
				match(LOCAL);
				setState(1192);
				match(DATETIME);
				}
				break;
			case 7:
				enterOuterAlt(_localctx, 7);
				{
				setState(1193);
				extract_datetime_part();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Functions_returning_stringsContext extends ParserRuleContext {
		public TerminalNode CONCAT() { return getToken(JpqlParser.CONCAT, 0); }
		public List<String_expressionContext> string_expression() {
			return getRuleContexts(String_expressionContext.class);
		}
		public String_expressionContext string_expression(int i) {
			return getRuleContext(String_expressionContext.class,i);
		}
		public TerminalNode SUBSTRING() { return getToken(JpqlParser.SUBSTRING, 0); }
		public List<Arithmetic_expressionContext> arithmetic_expression() {
			return getRuleContexts(Arithmetic_expressionContext.class);
		}
		public Arithmetic_expressionContext arithmetic_expression(int i) {
			return getRuleContext(Arithmetic_expressionContext.class,i);
		}
		public TerminalNode TRIM() { return getToken(JpqlParser.TRIM, 0); }
		public TerminalNode FROM() { return getToken(JpqlParser.FROM, 0); }
		public Trim_specificationContext trim_specification() {
			return getRuleContext(Trim_specificationContext.class,0);
		}
		public Trim_characterContext trim_character() {
			return getRuleContext(Trim_characterContext.class,0);
		}
		public TerminalNode LOWER() { return getToken(JpqlParser.LOWER, 0); }
		public TerminalNode UPPER() { return getToken(JpqlParser.UPPER, 0); }
		public Functions_returning_stringsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_functions_returning_strings; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterFunctions_returning_strings(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitFunctions_returning_strings(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitFunctions_returning_strings(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Functions_returning_stringsContext functions_returning_strings() throws RecognitionException {
		Functions_returning_stringsContext _localctx = new Functions_returning_stringsContext(_ctx, getState());
		enterRule(_localctx, 176, RULE_functions_returning_strings);
		int _la;
		try {
			setState(1245);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case CONCAT:
				enterOuterAlt(_localctx, 1);
				{
				setState(1196);
				match(CONCAT);
				setState(1197);
				match(T__1);
				setState(1198);
				string_expression();
				setState(1199);
				match(T__0);
				setState(1200);
				string_expression();
				setState(1205);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__0) {
					{
					{
					setState(1201);
					match(T__0);
					setState(1202);
					string_expression();
					}
					}
					setState(1207);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(1208);
				match(T__2);
				}
				break;
			case SUBSTRING:
				enterOuterAlt(_localctx, 2);
				{
				setState(1210);
				match(SUBSTRING);
				setState(1211);
				match(T__1);
				setState(1212);
				string_expression();
				setState(1213);
				match(T__0);
				setState(1214);
				arithmetic_expression(0);
				setState(1217);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==T__0) {
					{
					setState(1215);
					match(T__0);
					setState(1216);
					arithmetic_expression(0);
					}
				}

				setState(1219);
				match(T__2);
				}
				break;
			case TRIM:
				enterOuterAlt(_localctx, 3);
				{
				setState(1221);
				match(TRIM);
				setState(1222);
				match(T__1);
				setState(1230);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,122,_ctx) ) {
				case 1:
					{
					setState(1224);
					_errHandler.sync(this);
					_la = _input.LA(1);
					if (_la==BOTH || _la==LEADING || _la==TRAILING) {
						{
						setState(1223);
						trim_specification();
						}
					}

					setState(1227);
					_errHandler.sync(this);
					_la = _input.LA(1);
					if (_la==T__12 || _la==T__13 || _la==CHARACTER) {
						{
						setState(1226);
						trim_character();
						}
					}

					setState(1229);
					match(FROM);
					}
					break;
				}
				setState(1232);
				string_expression();
				setState(1233);
				match(T__2);
				}
				break;
			case LOWER:
				enterOuterAlt(_localctx, 4);
				{
				setState(1235);
				match(LOWER);
				setState(1236);
				match(T__1);
				setState(1237);
				string_expression();
				setState(1238);
				match(T__2);
				}
				break;
			case UPPER:
				enterOuterAlt(_localctx, 5);
				{
				setState(1240);
				match(UPPER);
				setState(1241);
				match(T__1);
				setState(1242);
				string_expression();
				setState(1243);
				match(T__2);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Trim_specificationContext extends ParserRuleContext {
		public TerminalNode LEADING() { return getToken(JpqlParser.LEADING, 0); }
		public TerminalNode TRAILING() { return getToken(JpqlParser.TRAILING, 0); }
		public TerminalNode BOTH() { return getToken(JpqlParser.BOTH, 0); }
		public Trim_specificationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_trim_specification; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterTrim_specification(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitTrim_specification(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitTrim_specification(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Trim_specificationContext trim_specification() throws RecognitionException {
		Trim_specificationContext _localctx = new Trim_specificationContext(_ctx, getState());
		enterRule(_localctx, 178, RULE_trim_specification);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1247);
			_la = _input.LA(1);
			if ( !(_la==BOTH || _la==LEADING || _la==TRAILING) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Arithmetic_cast_functionContext extends ParserRuleContext {
		public Token f;
		public TerminalNode CAST() { return getToken(JpqlParser.CAST, 0); }
		public String_expressionContext string_expression() {
			return getRuleContext(String_expressionContext.class,0);
		}
		public TerminalNode INTEGER() { return getToken(JpqlParser.INTEGER, 0); }
		public TerminalNode LONG() { return getToken(JpqlParser.LONG, 0); }
		public TerminalNode FLOAT() { return getToken(JpqlParser.FLOAT, 0); }
		public TerminalNode DOUBLE() { return getToken(JpqlParser.DOUBLE, 0); }
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public Arithmetic_cast_functionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_arithmetic_cast_function; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterArithmetic_cast_function(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitArithmetic_cast_function(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitArithmetic_cast_function(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Arithmetic_cast_functionContext arithmetic_cast_function() throws RecognitionException {
		Arithmetic_cast_functionContext _localctx = new Arithmetic_cast_functionContext(_ctx, getState());
		enterRule(_localctx, 180, RULE_arithmetic_cast_function);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1249);
			match(CAST);
			setState(1250);
			match(T__1);
			setState(1251);
			string_expression();
			setState(1253);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==AS) {
				{
				setState(1252);
				match(AS);
				}
			}

			setState(1255);
			((Arithmetic_cast_functionContext)_localctx).f = _input.LT(1);
			_la = _input.LA(1);
			if ( !(((((_la - 40)) & ~0x3f) == 0 && ((1L << (_la - 40)) & 17188265985L) != 0)) ) {
				((Arithmetic_cast_functionContext)_localctx).f = (Token)_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			setState(1256);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Type_cast_functionContext extends ParserRuleContext {
		public TerminalNode CAST() { return getToken(JpqlParser.CAST, 0); }
		public Scalar_expressionContext scalar_expression() {
			return getRuleContext(Scalar_expressionContext.class,0);
		}
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public List<Numeric_literalContext> numeric_literal() {
			return getRuleContexts(Numeric_literalContext.class);
		}
		public Numeric_literalContext numeric_literal(int i) {
			return getRuleContext(Numeric_literalContext.class,i);
		}
		public Type_cast_functionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_type_cast_function; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterType_cast_function(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitType_cast_function(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitType_cast_function(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Type_cast_functionContext type_cast_function() throws RecognitionException {
		Type_cast_functionContext _localctx = new Type_cast_functionContext(_ctx, getState());
		enterRule(_localctx, 182, RULE_type_cast_function);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1258);
			match(CAST);
			setState(1259);
			match(T__1);
			setState(1260);
			scalar_expression();
			setState(1262);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==AS) {
				{
				setState(1261);
				match(AS);
				}
			}

			setState(1264);
			identification_variable();
			setState(1276);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__1) {
				{
				setState(1265);
				match(T__1);
				setState(1266);
				numeric_literal();
				setState(1271);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__0) {
					{
					{
					setState(1267);
					match(T__0);
					setState(1268);
					numeric_literal();
					}
					}
					setState(1273);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(1274);
				match(T__2);
				}
			}

			setState(1278);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class String_cast_functionContext extends ParserRuleContext {
		public TerminalNode CAST() { return getToken(JpqlParser.CAST, 0); }
		public Scalar_expressionContext scalar_expression() {
			return getRuleContext(Scalar_expressionContext.class,0);
		}
		public TerminalNode STRING() { return getToken(JpqlParser.STRING, 0); }
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public String_cast_functionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_string_cast_function; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterString_cast_function(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitString_cast_function(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitString_cast_function(this);
			else return visitor.visitChildren(this);
		}
	}

	public final String_cast_functionContext string_cast_function() throws RecognitionException {
		String_cast_functionContext _localctx = new String_cast_functionContext(_ctx, getState());
		enterRule(_localctx, 184, RULE_string_cast_function);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1280);
			match(CAST);
			setState(1281);
			match(T__1);
			setState(1282);
			scalar_expression();
			setState(1284);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==AS) {
				{
				setState(1283);
				match(AS);
				}
			}

			setState(1286);
			match(STRING);
			setState(1287);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Function_invocationContext extends ParserRuleContext {
		public TerminalNode FUNCTION() { return getToken(JpqlParser.FUNCTION, 0); }
		public Function_nameContext function_name() {
			return getRuleContext(Function_nameContext.class,0);
		}
		public List<Function_argContext> function_arg() {
			return getRuleContexts(Function_argContext.class);
		}
		public Function_argContext function_arg(int i) {
			return getRuleContext(Function_argContext.class,i);
		}
		public Function_invocationContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_function_invocation; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterFunction_invocation(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitFunction_invocation(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitFunction_invocation(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Function_invocationContext function_invocation() throws RecognitionException {
		Function_invocationContext _localctx = new Function_invocationContext(_ctx, getState());
		enterRule(_localctx, 186, RULE_function_invocation);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1289);
			match(FUNCTION);
			setState(1290);
			match(T__1);
			setState(1291);
			function_name();
			setState(1296);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__0) {
				{
				{
				setState(1292);
				match(T__0);
				setState(1293);
				function_arg();
				}
				}
				setState(1298);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1299);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Extract_datetime_fieldContext extends ParserRuleContext {
		public TerminalNode EXTRACT() { return getToken(JpqlParser.EXTRACT, 0); }
		public Datetime_fieldContext datetime_field() {
			return getRuleContext(Datetime_fieldContext.class,0);
		}
		public TerminalNode FROM() { return getToken(JpqlParser.FROM, 0); }
		public Datetime_expressionContext datetime_expression() {
			return getRuleContext(Datetime_expressionContext.class,0);
		}
		public Extract_datetime_fieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_extract_datetime_field; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterExtract_datetime_field(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitExtract_datetime_field(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitExtract_datetime_field(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Extract_datetime_fieldContext extract_datetime_field() throws RecognitionException {
		Extract_datetime_fieldContext _localctx = new Extract_datetime_fieldContext(_ctx, getState());
		enterRule(_localctx, 188, RULE_extract_datetime_field);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1301);
			match(EXTRACT);
			setState(1302);
			match(T__1);
			setState(1303);
			datetime_field();
			setState(1304);
			match(FROM);
			setState(1305);
			datetime_expression();
			setState(1306);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Datetime_fieldContext extends ParserRuleContext {
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Datetime_fieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_datetime_field; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterDatetime_field(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitDatetime_field(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitDatetime_field(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Datetime_fieldContext datetime_field() throws RecognitionException {
		Datetime_fieldContext _localctx = new Datetime_fieldContext(_ctx, getState());
		enterRule(_localctx, 190, RULE_datetime_field);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1308);
			identification_variable();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Extract_datetime_partContext extends ParserRuleContext {
		public TerminalNode EXTRACT() { return getToken(JpqlParser.EXTRACT, 0); }
		public Datetime_partContext datetime_part() {
			return getRuleContext(Datetime_partContext.class,0);
		}
		public TerminalNode FROM() { return getToken(JpqlParser.FROM, 0); }
		public Datetime_expressionContext datetime_expression() {
			return getRuleContext(Datetime_expressionContext.class,0);
		}
		public Extract_datetime_partContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_extract_datetime_part; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterExtract_datetime_part(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitExtract_datetime_part(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitExtract_datetime_part(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Extract_datetime_partContext extract_datetime_part() throws RecognitionException {
		Extract_datetime_partContext _localctx = new Extract_datetime_partContext(_ctx, getState());
		enterRule(_localctx, 192, RULE_extract_datetime_part);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1310);
			match(EXTRACT);
			setState(1311);
			match(T__1);
			setState(1312);
			datetime_part();
			setState(1313);
			match(FROM);
			setState(1314);
			datetime_expression();
			setState(1315);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Datetime_partContext extends ParserRuleContext {
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Datetime_partContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_datetime_part; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterDatetime_part(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitDatetime_part(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitDatetime_part(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Datetime_partContext datetime_part() throws RecognitionException {
		Datetime_partContext _localctx = new Datetime_partContext(_ctx, getState());
		enterRule(_localctx, 194, RULE_datetime_part);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1317);
			identification_variable();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Function_argContext extends ParserRuleContext {
		public LiteralContext literal() {
			return getRuleContext(LiteralContext.class,0);
		}
		public State_valued_path_expressionContext state_valued_path_expression() {
			return getRuleContext(State_valued_path_expressionContext.class,0);
		}
		public Input_parameterContext input_parameter() {
			return getRuleContext(Input_parameterContext.class,0);
		}
		public Scalar_expressionContext scalar_expression() {
			return getRuleContext(Scalar_expressionContext.class,0);
		}
		public Function_argContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_function_arg; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterFunction_arg(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitFunction_arg(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitFunction_arg(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Function_argContext function_arg() throws RecognitionException {
		Function_argContext _localctx = new Function_argContext(_ctx, getState());
		enterRule(_localctx, 196, RULE_function_arg);
		try {
			setState(1323);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,130,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1319);
				literal();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1320);
				state_valued_path_expression();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1321);
				input_parameter();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(1322);
				scalar_expression();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Case_expressionContext extends ParserRuleContext {
		public General_case_expressionContext general_case_expression() {
			return getRuleContext(General_case_expressionContext.class,0);
		}
		public Simple_case_expressionContext simple_case_expression() {
			return getRuleContext(Simple_case_expressionContext.class,0);
		}
		public Coalesce_expressionContext coalesce_expression() {
			return getRuleContext(Coalesce_expressionContext.class,0);
		}
		public Nullif_expressionContext nullif_expression() {
			return getRuleContext(Nullif_expressionContext.class,0);
		}
		public Case_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_case_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterCase_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitCase_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitCase_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Case_expressionContext case_expression() throws RecognitionException {
		Case_expressionContext _localctx = new Case_expressionContext(_ctx, getState());
		enterRule(_localctx, 198, RULE_case_expression);
		try {
			setState(1329);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,131,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1325);
				general_case_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1326);
				simple_case_expression();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1327);
				coalesce_expression();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(1328);
				nullif_expression();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class General_case_expressionContext extends ParserRuleContext {
		public TerminalNode CASE() { return getToken(JpqlParser.CASE, 0); }
		public List<When_clauseContext> when_clause() {
			return getRuleContexts(When_clauseContext.class);
		}
		public When_clauseContext when_clause(int i) {
			return getRuleContext(When_clauseContext.class,i);
		}
		public TerminalNode ELSE() { return getToken(JpqlParser.ELSE, 0); }
		public Scalar_expressionContext scalar_expression() {
			return getRuleContext(Scalar_expressionContext.class,0);
		}
		public TerminalNode END() { return getToken(JpqlParser.END, 0); }
		public General_case_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_general_case_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterGeneral_case_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitGeneral_case_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitGeneral_case_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final General_case_expressionContext general_case_expression() throws RecognitionException {
		General_case_expressionContext _localctx = new General_case_expressionContext(_ctx, getState());
		enterRule(_localctx, 200, RULE_general_case_expression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1331);
			match(CASE);
			setState(1332);
			when_clause();
			setState(1336);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==WHEN) {
				{
				{
				setState(1333);
				when_clause();
				}
				}
				setState(1338);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1339);
			match(ELSE);
			setState(1340);
			scalar_expression();
			setState(1341);
			match(END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class When_clauseContext extends ParserRuleContext {
		public TerminalNode WHEN() { return getToken(JpqlParser.WHEN, 0); }
		public Conditional_expressionContext conditional_expression() {
			return getRuleContext(Conditional_expressionContext.class,0);
		}
		public TerminalNode THEN() { return getToken(JpqlParser.THEN, 0); }
		public Scalar_expressionContext scalar_expression() {
			return getRuleContext(Scalar_expressionContext.class,0);
		}
		public When_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_when_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterWhen_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitWhen_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitWhen_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final When_clauseContext when_clause() throws RecognitionException {
		When_clauseContext _localctx = new When_clauseContext(_ctx, getState());
		enterRule(_localctx, 202, RULE_when_clause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1343);
			match(WHEN);
			setState(1344);
			conditional_expression(0);
			setState(1345);
			match(THEN);
			setState(1346);
			scalar_expression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Simple_case_expressionContext extends ParserRuleContext {
		public TerminalNode CASE() { return getToken(JpqlParser.CASE, 0); }
		public Case_operandContext case_operand() {
			return getRuleContext(Case_operandContext.class,0);
		}
		public List<Simple_when_clauseContext> simple_when_clause() {
			return getRuleContexts(Simple_when_clauseContext.class);
		}
		public Simple_when_clauseContext simple_when_clause(int i) {
			return getRuleContext(Simple_when_clauseContext.class,i);
		}
		public TerminalNode ELSE() { return getToken(JpqlParser.ELSE, 0); }
		public Scalar_expressionContext scalar_expression() {
			return getRuleContext(Scalar_expressionContext.class,0);
		}
		public TerminalNode END() { return getToken(JpqlParser.END, 0); }
		public Simple_case_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simple_case_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSimple_case_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSimple_case_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSimple_case_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Simple_case_expressionContext simple_case_expression() throws RecognitionException {
		Simple_case_expressionContext _localctx = new Simple_case_expressionContext(_ctx, getState());
		enterRule(_localctx, 204, RULE_simple_case_expression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1348);
			match(CASE);
			setState(1349);
			case_operand();
			setState(1350);
			simple_when_clause();
			setState(1354);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==WHEN) {
				{
				{
				setState(1351);
				simple_when_clause();
				}
				}
				setState(1356);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(1357);
			match(ELSE);
			setState(1358);
			scalar_expression();
			setState(1359);
			match(END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Case_operandContext extends ParserRuleContext {
		public State_valued_path_expressionContext state_valued_path_expression() {
			return getRuleContext(State_valued_path_expressionContext.class,0);
		}
		public Type_discriminatorContext type_discriminator() {
			return getRuleContext(Type_discriminatorContext.class,0);
		}
		public Case_operandContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_case_operand; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterCase_operand(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitCase_operand(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitCase_operand(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Case_operandContext case_operand() throws RecognitionException {
		Case_operandContext _localctx = new Case_operandContext(_ctx, getState());
		enterRule(_localctx, 206, RULE_case_operand);
		try {
			setState(1363);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,134,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1361);
				state_valued_path_expression();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1362);
				type_discriminator();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Simple_when_clauseContext extends ParserRuleContext {
		public TerminalNode WHEN() { return getToken(JpqlParser.WHEN, 0); }
		public List<Scalar_expressionContext> scalar_expression() {
			return getRuleContexts(Scalar_expressionContext.class);
		}
		public Scalar_expressionContext scalar_expression(int i) {
			return getRuleContext(Scalar_expressionContext.class,i);
		}
		public TerminalNode THEN() { return getToken(JpqlParser.THEN, 0); }
		public Simple_when_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_simple_when_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSimple_when_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSimple_when_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSimple_when_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Simple_when_clauseContext simple_when_clause() throws RecognitionException {
		Simple_when_clauseContext _localctx = new Simple_when_clauseContext(_ctx, getState());
		enterRule(_localctx, 208, RULE_simple_when_clause);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1365);
			match(WHEN);
			setState(1366);
			scalar_expression();
			setState(1367);
			match(THEN);
			setState(1368);
			scalar_expression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Coalesce_expressionContext extends ParserRuleContext {
		public TerminalNode COALESCE() { return getToken(JpqlParser.COALESCE, 0); }
		public List<Scalar_expressionContext> scalar_expression() {
			return getRuleContexts(Scalar_expressionContext.class);
		}
		public Scalar_expressionContext scalar_expression(int i) {
			return getRuleContext(Scalar_expressionContext.class,i);
		}
		public Coalesce_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_coalesce_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterCoalesce_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitCoalesce_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitCoalesce_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Coalesce_expressionContext coalesce_expression() throws RecognitionException {
		Coalesce_expressionContext _localctx = new Coalesce_expressionContext(_ctx, getState());
		enterRule(_localctx, 210, RULE_coalesce_expression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1370);
			match(COALESCE);
			setState(1371);
			match(T__1);
			setState(1372);
			scalar_expression();
			setState(1375); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(1373);
				match(T__0);
				setState(1374);
				scalar_expression();
				}
				}
				setState(1377); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==T__0 );
			setState(1379);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Nullif_expressionContext extends ParserRuleContext {
		public TerminalNode NULLIF() { return getToken(JpqlParser.NULLIF, 0); }
		public List<Scalar_expressionContext> scalar_expression() {
			return getRuleContexts(Scalar_expressionContext.class);
		}
		public Scalar_expressionContext scalar_expression(int i) {
			return getRuleContext(Scalar_expressionContext.class,i);
		}
		public Nullif_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_nullif_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterNullif_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitNullif_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitNullif_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Nullif_expressionContext nullif_expression() throws RecognitionException {
		Nullif_expressionContext _localctx = new Nullif_expressionContext(_ctx, getState());
		enterRule(_localctx, 212, RULE_nullif_expression);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1381);
			match(NULLIF);
			setState(1382);
			match(T__1);
			setState(1383);
			scalar_expression();
			setState(1384);
			match(T__0);
			setState(1385);
			scalar_expression();
			setState(1386);
			match(T__2);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Trim_characterContext extends ParserRuleContext {
		public TerminalNode CHARACTER() { return getToken(JpqlParser.CHARACTER, 0); }
		public Character_valued_input_parameterContext character_valued_input_parameter() {
			return getRuleContext(Character_valued_input_parameterContext.class,0);
		}
		public Trim_characterContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_trim_character; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterTrim_character(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitTrim_character(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitTrim_character(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Trim_characterContext trim_character() throws RecognitionException {
		Trim_characterContext _localctx = new Trim_characterContext(_ctx, getState());
		enterRule(_localctx, 214, RULE_trim_character);
		try {
			setState(1390);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,136,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1388);
				match(CHARACTER);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1389);
				character_valued_input_parameter();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Identification_variableContext extends ParserRuleContext {
		public Token f;
		public TerminalNode IDENTIFICATION_VARIABLE() { return getToken(JpqlParser.IDENTIFICATION_VARIABLE, 0); }
		public TerminalNode COUNT() { return getToken(JpqlParser.COUNT, 0); }
		public TerminalNode DATE() { return getToken(JpqlParser.DATE, 0); }
		public TerminalNode FROM() { return getToken(JpqlParser.FROM, 0); }
		public TerminalNode INNER() { return getToken(JpqlParser.INNER, 0); }
		public TerminalNode KEY() { return getToken(JpqlParser.KEY, 0); }
		public TerminalNode LEFT() { return getToken(JpqlParser.LEFT, 0); }
		public TerminalNode NEW() { return getToken(JpqlParser.NEW, 0); }
		public TerminalNode ORDER() { return getToken(JpqlParser.ORDER, 0); }
		public TerminalNode OUTER() { return getToken(JpqlParser.OUTER, 0); }
		public TerminalNode POWER() { return getToken(JpqlParser.POWER, 0); }
		public TerminalNode FLOOR() { return getToken(JpqlParser.FLOOR, 0); }
		public TerminalNode SIGN() { return getToken(JpqlParser.SIGN, 0); }
		public TerminalNode TIME() { return getToken(JpqlParser.TIME, 0); }
		public TerminalNode TYPE() { return getToken(JpqlParser.TYPE, 0); }
		public TerminalNode VALUE() { return getToken(JpqlParser.VALUE, 0); }
		public Identification_variableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_identification_variable; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterIdentification_variable(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitIdentification_variable(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitIdentification_variable(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Identification_variableContext identification_variable() throws RecognitionException {
		Identification_variableContext _localctx = new Identification_variableContext(_ctx, getState());
		enterRule(_localctx, 216, RULE_identification_variable);
		int _la;
		try {
			setState(1394);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case IDENTIFICATION_VARIABLE:
				enterOuterAlt(_localctx, 1);
				{
				setState(1392);
				match(IDENTIFICATION_VARIABLE);
				}
				break;
			case COUNT:
			case DATE:
			case FLOOR:
			case FROM:
			case INNER:
			case KEY:
			case LEFT:
			case NEW:
			case ORDER:
			case OUTER:
			case POWER:
			case SIGN:
			case TIME:
			case TYPE:
			case VALUE:
				enterOuterAlt(_localctx, 2);
				{
				setState(1393);
				((Identification_variableContext)_localctx).f = _input.LT(1);
				_la = _input.LA(1);
				if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 1175439539250921472L) != 0) || ((((_la - 65)) & ~0x3f) == 0 && ((1L << (_la - 65)) & 158881695170569L) != 0)) ) {
					((Identification_variableContext)_localctx).f = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Constructor_nameContext extends ParserRuleContext {
		public Entity_nameContext entity_name() {
			return getRuleContext(Entity_nameContext.class,0);
		}
		public Constructor_nameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_constructor_name; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterConstructor_name(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitConstructor_name(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitConstructor_name(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Constructor_nameContext constructor_name() throws RecognitionException {
		Constructor_nameContext _localctx = new Constructor_nameContext(_ctx, getState());
		enterRule(_localctx, 218, RULE_constructor_name);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1396);
			entity_name();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class LiteralContext extends ParserRuleContext {
		public TerminalNode STRINGLITERAL() { return getToken(JpqlParser.STRINGLITERAL, 0); }
		public TerminalNode JAVASTRINGLITERAL() { return getToken(JpqlParser.JAVASTRINGLITERAL, 0); }
		public TerminalNode INTLITERAL() { return getToken(JpqlParser.INTLITERAL, 0); }
		public TerminalNode FLOATLITERAL() { return getToken(JpqlParser.FLOATLITERAL, 0); }
		public TerminalNode LONGLITERAL() { return getToken(JpqlParser.LONGLITERAL, 0); }
		public Boolean_literalContext boolean_literal() {
			return getRuleContext(Boolean_literalContext.class,0);
		}
		public Entity_type_literalContext entity_type_literal() {
			return getRuleContext(Entity_type_literalContext.class,0);
		}
		public LiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_literal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LiteralContext literal() throws RecognitionException {
		LiteralContext _localctx = new LiteralContext(_ctx, getState());
		enterRule(_localctx, 220, RULE_literal);
		try {
			setState(1405);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case STRINGLITERAL:
				enterOuterAlt(_localctx, 1);
				{
				setState(1398);
				match(STRINGLITERAL);
				}
				break;
			case JAVASTRINGLITERAL:
				enterOuterAlt(_localctx, 2);
				{
				setState(1399);
				match(JAVASTRINGLITERAL);
				}
				break;
			case INTLITERAL:
				enterOuterAlt(_localctx, 3);
				{
				setState(1400);
				match(INTLITERAL);
				}
				break;
			case FLOATLITERAL:
				enterOuterAlt(_localctx, 4);
				{
				setState(1401);
				match(FLOATLITERAL);
				}
				break;
			case LONGLITERAL:
				enterOuterAlt(_localctx, 5);
				{
				setState(1402);
				match(LONGLITERAL);
				}
				break;
			case FALSE:
			case TRUE:
				enterOuterAlt(_localctx, 6);
				{
				setState(1403);
				boolean_literal();
				}
				break;
			case COUNT:
			case DATE:
			case FLOOR:
			case FROM:
			case INNER:
			case KEY:
			case LEFT:
			case NEW:
			case ORDER:
			case OUTER:
			case POWER:
			case SIGN:
			case TIME:
			case TYPE:
			case VALUE:
			case IDENTIFICATION_VARIABLE:
				enterOuterAlt(_localctx, 7);
				{
				setState(1404);
				entity_type_literal();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Input_parameterContext extends ParserRuleContext {
		public TerminalNode INTLITERAL() { return getToken(JpqlParser.INTLITERAL, 0); }
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Input_parameterContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_input_parameter; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterInput_parameter(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitInput_parameter(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitInput_parameter(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Input_parameterContext input_parameter() throws RecognitionException {
		Input_parameterContext _localctx = new Input_parameterContext(_ctx, getState());
		enterRule(_localctx, 222, RULE_input_parameter);
		try {
			setState(1411);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__12:
				enterOuterAlt(_localctx, 1);
				{
				setState(1407);
				match(T__12);
				setState(1408);
				match(INTLITERAL);
				}
				break;
			case T__13:
				enterOuterAlt(_localctx, 2);
				{
				setState(1409);
				match(T__13);
				setState(1410);
				identification_variable();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Pattern_valueContext extends ParserRuleContext {
		public String_expressionContext string_expression() {
			return getRuleContext(String_expressionContext.class,0);
		}
		public Pattern_valueContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_pattern_value; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterPattern_value(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitPattern_value(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitPattern_value(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Pattern_valueContext pattern_value() throws RecognitionException {
		Pattern_valueContext _localctx = new Pattern_valueContext(_ctx, getState());
		enterRule(_localctx, 224, RULE_pattern_value);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1413);
			string_expression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Date_time_timestamp_literalContext extends ParserRuleContext {
		public TerminalNode STRINGLITERAL() { return getToken(JpqlParser.STRINGLITERAL, 0); }
		public Date_time_timestamp_literalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_date_time_timestamp_literal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterDate_time_timestamp_literal(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitDate_time_timestamp_literal(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitDate_time_timestamp_literal(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Date_time_timestamp_literalContext date_time_timestamp_literal() throws RecognitionException {
		Date_time_timestamp_literalContext _localctx = new Date_time_timestamp_literalContext(_ctx, getState());
		enterRule(_localctx, 226, RULE_date_time_timestamp_literal);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1415);
			match(STRINGLITERAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Entity_type_literalContext extends ParserRuleContext {
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Entity_type_literalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_entity_type_literal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterEntity_type_literal(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitEntity_type_literal(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitEntity_type_literal(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Entity_type_literalContext entity_type_literal() throws RecognitionException {
		Entity_type_literalContext _localctx = new Entity_type_literalContext(_ctx, getState());
		enterRule(_localctx, 228, RULE_entity_type_literal);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1417);
			identification_variable();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Escape_characterContext extends ParserRuleContext {
		public TerminalNode CHARACTER() { return getToken(JpqlParser.CHARACTER, 0); }
		public String_literalContext string_literal() {
			return getRuleContext(String_literalContext.class,0);
		}
		public Character_valued_input_parameterContext character_valued_input_parameter() {
			return getRuleContext(Character_valued_input_parameterContext.class,0);
		}
		public Escape_characterContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_escape_character; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterEscape_character(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitEscape_character(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitEscape_character(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Escape_characterContext escape_character() throws RecognitionException {
		Escape_characterContext _localctx = new Escape_characterContext(_ctx, getState());
		enterRule(_localctx, 230, RULE_escape_character);
		try {
			setState(1422);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,140,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1419);
				match(CHARACTER);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1420);
				string_literal();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(1421);
				character_valued_input_parameter();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Numeric_literalContext extends ParserRuleContext {
		public TerminalNode INTLITERAL() { return getToken(JpqlParser.INTLITERAL, 0); }
		public TerminalNode FLOATLITERAL() { return getToken(JpqlParser.FLOATLITERAL, 0); }
		public TerminalNode LONGLITERAL() { return getToken(JpqlParser.LONGLITERAL, 0); }
		public Numeric_literalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_numeric_literal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterNumeric_literal(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitNumeric_literal(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitNumeric_literal(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Numeric_literalContext numeric_literal() throws RecognitionException {
		Numeric_literalContext _localctx = new Numeric_literalContext(_ctx, getState());
		enterRule(_localctx, 232, RULE_numeric_literal);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1424);
			_la = _input.LA(1);
			if ( !(((((_la - 121)) & ~0x3f) == 0 && ((1L << (_la - 121)) & 7L) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Boolean_literalContext extends ParserRuleContext {
		public TerminalNode TRUE() { return getToken(JpqlParser.TRUE, 0); }
		public TerminalNode FALSE() { return getToken(JpqlParser.FALSE, 0); }
		public Boolean_literalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_boolean_literal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterBoolean_literal(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitBoolean_literal(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitBoolean_literal(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Boolean_literalContext boolean_literal() throws RecognitionException {
		Boolean_literalContext _localctx = new Boolean_literalContext(_ctx, getState());
		enterRule(_localctx, 234, RULE_boolean_literal);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1426);
			_la = _input.LA(1);
			if ( !(_la==FALSE || _la==TRUE) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Enum_literalContext extends ParserRuleContext {
		public State_field_path_expressionContext state_field_path_expression() {
			return getRuleContext(State_field_path_expressionContext.class,0);
		}
		public Enum_literalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_enum_literal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterEnum_literal(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitEnum_literal(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitEnum_literal(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Enum_literalContext enum_literal() throws RecognitionException {
		Enum_literalContext _localctx = new Enum_literalContext(_ctx, getState());
		enterRule(_localctx, 236, RULE_enum_literal);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1428);
			state_field_path_expression();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class String_literalContext extends ParserRuleContext {
		public TerminalNode CHARACTER() { return getToken(JpqlParser.CHARACTER, 0); }
		public TerminalNode STRINGLITERAL() { return getToken(JpqlParser.STRINGLITERAL, 0); }
		public String_literalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_string_literal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterString_literal(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitString_literal(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitString_literal(this);
			else return visitor.visitChildren(this);
		}
	}

	public final String_literalContext string_literal() throws RecognitionException {
		String_literalContext _localctx = new String_literalContext(_ctx, getState());
		enterRule(_localctx, 238, RULE_string_literal);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1430);
			_la = _input.LA(1);
			if ( !(_la==CHARACTER || _la==STRINGLITERAL) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Single_valued_embeddable_object_fieldContext extends ParserRuleContext {
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Single_valued_embeddable_object_fieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_single_valued_embeddable_object_field; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSingle_valued_embeddable_object_field(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSingle_valued_embeddable_object_field(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSingle_valued_embeddable_object_field(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Single_valued_embeddable_object_fieldContext single_valued_embeddable_object_field() throws RecognitionException {
		Single_valued_embeddable_object_fieldContext _localctx = new Single_valued_embeddable_object_fieldContext(_ctx, getState());
		enterRule(_localctx, 240, RULE_single_valued_embeddable_object_field);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1432);
			identification_variable();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SubtypeContext extends ParserRuleContext {
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public SubtypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_subtype; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSubtype(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSubtype(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSubtype(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SubtypeContext subtype() throws RecognitionException {
		SubtypeContext _localctx = new SubtypeContext(_ctx, getState());
		enterRule(_localctx, 242, RULE_subtype);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1434);
			identification_variable();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Collection_valued_fieldContext extends ParserRuleContext {
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Reserved_wordContext reserved_word() {
			return getRuleContext(Reserved_wordContext.class,0);
		}
		public Collection_valued_fieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_collection_valued_field; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterCollection_valued_field(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitCollection_valued_field(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitCollection_valued_field(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Collection_valued_fieldContext collection_valued_field() throws RecognitionException {
		Collection_valued_fieldContext _localctx = new Collection_valued_fieldContext(_ctx, getState());
		enterRule(_localctx, 244, RULE_collection_valued_field);
		try {
			setState(1438);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,141,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1436);
				identification_variable();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1437);
				reserved_word();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Single_valued_object_fieldContext extends ParserRuleContext {
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Reserved_wordContext reserved_word() {
			return getRuleContext(Reserved_wordContext.class,0);
		}
		public Single_valued_object_fieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_single_valued_object_field; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSingle_valued_object_field(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSingle_valued_object_field(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSingle_valued_object_field(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Single_valued_object_fieldContext single_valued_object_field() throws RecognitionException {
		Single_valued_object_fieldContext _localctx = new Single_valued_object_fieldContext(_ctx, getState());
		enterRule(_localctx, 246, RULE_single_valued_object_field);
		try {
			setState(1442);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,142,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1440);
				identification_variable();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1441);
				reserved_word();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class State_fieldContext extends ParserRuleContext {
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Reserved_wordContext reserved_word() {
			return getRuleContext(Reserved_wordContext.class,0);
		}
		public State_fieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_state_field; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterState_field(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitState_field(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitState_field(this);
			else return visitor.visitChildren(this);
		}
	}

	public final State_fieldContext state_field() throws RecognitionException {
		State_fieldContext _localctx = new State_fieldContext(_ctx, getState());
		enterRule(_localctx, 248, RULE_state_field);
		try {
			setState(1446);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,143,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1444);
				identification_variable();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1445);
				reserved_word();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Collection_value_fieldContext extends ParserRuleContext {
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Reserved_wordContext reserved_word() {
			return getRuleContext(Reserved_wordContext.class,0);
		}
		public Collection_value_fieldContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_collection_value_field; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterCollection_value_field(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitCollection_value_field(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitCollection_value_field(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Collection_value_fieldContext collection_value_field() throws RecognitionException {
		Collection_value_fieldContext _localctx = new Collection_value_fieldContext(_ctx, getState());
		enterRule(_localctx, 250, RULE_collection_value_field);
		try {
			setState(1450);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,144,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(1448);
				identification_variable();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(1449);
				reserved_word();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Entity_nameContext extends ParserRuleContext {
		public List<Reserved_wordContext> reserved_word() {
			return getRuleContexts(Reserved_wordContext.class);
		}
		public Reserved_wordContext reserved_word(int i) {
			return getRuleContext(Reserved_wordContext.class,i);
		}
		public Entity_nameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_entity_name; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterEntity_name(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitEntity_name(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitEntity_name(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Entity_nameContext entity_name() throws RecognitionException {
		Entity_nameContext _localctx = new Entity_nameContext(_ctx, getState());
		enterRule(_localctx, 252, RULE_entity_name);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1452);
			reserved_word();
			setState(1457);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==T__3) {
				{
				{
				setState(1453);
				match(T__3);
				setState(1454);
				reserved_word();
				}
				}
				setState(1459);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Result_variableContext extends ParserRuleContext {
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Result_variableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_result_variable; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterResult_variable(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitResult_variable(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitResult_variable(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Result_variableContext result_variable() throws RecognitionException {
		Result_variableContext _localctx = new Result_variableContext(_ctx, getState());
		enterRule(_localctx, 254, RULE_result_variable);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1460);
			identification_variable();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Superquery_identification_variableContext extends ParserRuleContext {
		public Identification_variableContext identification_variable() {
			return getRuleContext(Identification_variableContext.class,0);
		}
		public Superquery_identification_variableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_superquery_identification_variable; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSuperquery_identification_variable(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSuperquery_identification_variable(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSuperquery_identification_variable(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Superquery_identification_variableContext superquery_identification_variable() throws RecognitionException {
		Superquery_identification_variableContext _localctx = new Superquery_identification_variableContext(_ctx, getState());
		enterRule(_localctx, 256, RULE_superquery_identification_variable);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1462);
			identification_variable();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Collection_valued_input_parameterContext extends ParserRuleContext {
		public Input_parameterContext input_parameter() {
			return getRuleContext(Input_parameterContext.class,0);
		}
		public Collection_valued_input_parameterContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_collection_valued_input_parameter; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterCollection_valued_input_parameter(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitCollection_valued_input_parameter(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitCollection_valued_input_parameter(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Collection_valued_input_parameterContext collection_valued_input_parameter() throws RecognitionException {
		Collection_valued_input_parameterContext _localctx = new Collection_valued_input_parameterContext(_ctx, getState());
		enterRule(_localctx, 258, RULE_collection_valued_input_parameter);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1464);
			input_parameter();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Single_valued_input_parameterContext extends ParserRuleContext {
		public Input_parameterContext input_parameter() {
			return getRuleContext(Input_parameterContext.class,0);
		}
		public Single_valued_input_parameterContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_single_valued_input_parameter; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterSingle_valued_input_parameter(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitSingle_valued_input_parameter(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitSingle_valued_input_parameter(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Single_valued_input_parameterContext single_valued_input_parameter() throws RecognitionException {
		Single_valued_input_parameterContext _localctx = new Single_valued_input_parameterContext(_ctx, getState());
		enterRule(_localctx, 260, RULE_single_valued_input_parameter);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1466);
			input_parameter();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Function_nameContext extends ParserRuleContext {
		public String_literalContext string_literal() {
			return getRuleContext(String_literalContext.class,0);
		}
		public Function_nameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_function_name; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterFunction_name(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitFunction_name(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitFunction_name(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Function_nameContext function_name() throws RecognitionException {
		Function_nameContext _localctx = new Function_nameContext(_ctx, getState());
		enterRule(_localctx, 262, RULE_function_name);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(1468);
			string_literal();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Character_valued_input_parameterContext extends ParserRuleContext {
		public TerminalNode CHARACTER() { return getToken(JpqlParser.CHARACTER, 0); }
		public Input_parameterContext input_parameter() {
			return getRuleContext(Input_parameterContext.class,0);
		}
		public Character_valued_input_parameterContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_character_valued_input_parameter; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterCharacter_valued_input_parameter(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitCharacter_valued_input_parameter(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitCharacter_valued_input_parameter(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Character_valued_input_parameterContext character_valued_input_parameter() throws RecognitionException {
		Character_valued_input_parameterContext _localctx = new Character_valued_input_parameterContext(_ctx, getState());
		enterRule(_localctx, 264, RULE_character_valued_input_parameter);
		try {
			setState(1472);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case CHARACTER:
				enterOuterAlt(_localctx, 1);
				{
				setState(1470);
				match(CHARACTER);
				}
				break;
			case T__12:
			case T__13:
				enterOuterAlt(_localctx, 2);
				{
				setState(1471);
				input_parameter();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class Reserved_wordContext extends ParserRuleContext {
		public Token f;
		public TerminalNode IDENTIFICATION_VARIABLE() { return getToken(JpqlParser.IDENTIFICATION_VARIABLE, 0); }
		public TerminalNode ABS() { return getToken(JpqlParser.ABS, 0); }
		public TerminalNode ALL() { return getToken(JpqlParser.ALL, 0); }
		public TerminalNode AND() { return getToken(JpqlParser.AND, 0); }
		public TerminalNode ANY() { return getToken(JpqlParser.ANY, 0); }
		public TerminalNode AS() { return getToken(JpqlParser.AS, 0); }
		public TerminalNode ASC() { return getToken(JpqlParser.ASC, 0); }
		public TerminalNode AVG() { return getToken(JpqlParser.AVG, 0); }
		public TerminalNode BETWEEN() { return getToken(JpqlParser.BETWEEN, 0); }
		public TerminalNode BOTH() { return getToken(JpqlParser.BOTH, 0); }
		public TerminalNode BY() { return getToken(JpqlParser.BY, 0); }
		public TerminalNode CASE() { return getToken(JpqlParser.CASE, 0); }
		public TerminalNode CAST() { return getToken(JpqlParser.CAST, 0); }
		public TerminalNode CEILING() { return getToken(JpqlParser.CEILING, 0); }
		public TerminalNode COALESCE() { return getToken(JpqlParser.COALESCE, 0); }
		public TerminalNode CONCAT() { return getToken(JpqlParser.CONCAT, 0); }
		public TerminalNode COUNT() { return getToken(JpqlParser.COUNT, 0); }
		public TerminalNode CURRENT_DATE() { return getToken(JpqlParser.CURRENT_DATE, 0); }
		public TerminalNode CURRENT_TIME() { return getToken(JpqlParser.CURRENT_TIME, 0); }
		public TerminalNode CURRENT_TIMESTAMP() { return getToken(JpqlParser.CURRENT_TIMESTAMP, 0); }
		public TerminalNode DATE() { return getToken(JpqlParser.DATE, 0); }
		public TerminalNode DATETIME() { return getToken(JpqlParser.DATETIME, 0); }
		public TerminalNode DELETE() { return getToken(JpqlParser.DELETE, 0); }
		public TerminalNode DESC() { return getToken(JpqlParser.DESC, 0); }
		public TerminalNode DISTINCT() { return getToken(JpqlParser.DISTINCT, 0); }
		public TerminalNode END() { return getToken(JpqlParser.END, 0); }
		public TerminalNode ELSE() { return getToken(JpqlParser.ELSE, 0); }
		public TerminalNode EMPTY() { return getToken(JpqlParser.EMPTY, 0); }
		public TerminalNode ENTRY() { return getToken(JpqlParser.ENTRY, 0); }
		public TerminalNode ESCAPE() { return getToken(JpqlParser.ESCAPE, 0); }
		public TerminalNode EXISTS() { return getToken(JpqlParser.EXISTS, 0); }
		public TerminalNode EXP() { return getToken(JpqlParser.EXP, 0); }
		public TerminalNode EXTRACT() { return getToken(JpqlParser.EXTRACT, 0); }
		public TerminalNode FALSE() { return getToken(JpqlParser.FALSE, 0); }
		public TerminalNode FETCH() { return getToken(JpqlParser.FETCH, 0); }
		public TerminalNode FLOOR() { return getToken(JpqlParser.FLOOR, 0); }
		public TerminalNode FUNCTION() { return getToken(JpqlParser.FUNCTION, 0); }
		public TerminalNode IN() { return getToken(JpqlParser.IN, 0); }
		public TerminalNode INDEX() { return getToken(JpqlParser.INDEX, 0); }
		public TerminalNode INNER() { return getToken(JpqlParser.INNER, 0); }
		public TerminalNode IS() { return getToken(JpqlParser.IS, 0); }
		public TerminalNode KEY() { return getToken(JpqlParser.KEY, 0); }
		public TerminalNode LEFT() { return getToken(JpqlParser.LEFT, 0); }
		public TerminalNode LENGTH() { return getToken(JpqlParser.LENGTH, 0); }
		public TerminalNode LIKE() { return getToken(JpqlParser.LIKE, 0); }
		public TerminalNode LN() { return getToken(JpqlParser.LN, 0); }
		public TerminalNode LOCAL() { return getToken(JpqlParser.LOCAL, 0); }
		public TerminalNode LOCATE() { return getToken(JpqlParser.LOCATE, 0); }
		public TerminalNode LOWER() { return getToken(JpqlParser.LOWER, 0); }
		public TerminalNode MAX() { return getToken(JpqlParser.MAX, 0); }
		public TerminalNode MEMBER() { return getToken(JpqlParser.MEMBER, 0); }
		public TerminalNode MIN() { return getToken(JpqlParser.MIN, 0); }
		public TerminalNode MOD() { return getToken(JpqlParser.MOD, 0); }
		public TerminalNode NEW() { return getToken(JpqlParser.NEW, 0); }
		public TerminalNode NOT() { return getToken(JpqlParser.NOT, 0); }
		public TerminalNode NULL() { return getToken(JpqlParser.NULL, 0); }
		public TerminalNode NULLIF() { return getToken(JpqlParser.NULLIF, 0); }
		public TerminalNode OBJECT() { return getToken(JpqlParser.OBJECT, 0); }
		public TerminalNode OF() { return getToken(JpqlParser.OF, 0); }
		public TerminalNode ON() { return getToken(JpqlParser.ON, 0); }
		public TerminalNode OR() { return getToken(JpqlParser.OR, 0); }
		public TerminalNode ORDER() { return getToken(JpqlParser.ORDER, 0); }
		public TerminalNode OUTER() { return getToken(JpqlParser.OUTER, 0); }
		public TerminalNode POWER() { return getToken(JpqlParser.POWER, 0); }
		public TerminalNode ROUND() { return getToken(JpqlParser.ROUND, 0); }
		public TerminalNode SELECT() { return getToken(JpqlParser.SELECT, 0); }
		public TerminalNode SET() { return getToken(JpqlParser.SET, 0); }
		public TerminalNode SIGN() { return getToken(JpqlParser.SIGN, 0); }
		public TerminalNode SIZE() { return getToken(JpqlParser.SIZE, 0); }
		public TerminalNode SOME() { return getToken(JpqlParser.SOME, 0); }
		public TerminalNode SQRT() { return getToken(JpqlParser.SQRT, 0); }
		public TerminalNode SUBSTRING() { return getToken(JpqlParser.SUBSTRING, 0); }
		public TerminalNode SUM() { return getToken(JpqlParser.SUM, 0); }
		public TerminalNode THEN() { return getToken(JpqlParser.THEN, 0); }
		public TerminalNode TIME() { return getToken(JpqlParser.TIME, 0); }
		public TerminalNode TRAILING() { return getToken(JpqlParser.TRAILING, 0); }
		public TerminalNode TREAT() { return getToken(JpqlParser.TREAT, 0); }
		public TerminalNode TRIM() { return getToken(JpqlParser.TRIM, 0); }
		public TerminalNode TRUE() { return getToken(JpqlParser.TRUE, 0); }
		public TerminalNode TYPE() { return getToken(JpqlParser.TYPE, 0); }
		public TerminalNode UPDATE() { return getToken(JpqlParser.UPDATE, 0); }
		public TerminalNode UPPER() { return getToken(JpqlParser.UPPER, 0); }
		public TerminalNode VALUE() { return getToken(JpqlParser.VALUE, 0); }
		public Reserved_wordContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_reserved_word; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).enterReserved_word(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof JpqlListener ) ((JpqlListener)listener).exitReserved_word(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof JpqlVisitor ) return ((JpqlVisitor<? extends T>)visitor).visitReserved_word(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Reserved_wordContext reserved_word() throws RecognitionException {
		Reserved_wordContext _localctx = new Reserved_wordContext(_ctx, getState());
		enterRule(_localctx, 266, RULE_reserved_word);
		int _la;
		try {
			setState(1476);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case IDENTIFICATION_VARIABLE:
				enterOuterAlt(_localctx, 1);
				{
				setState(1474);
				match(IDENTIFICATION_VARIABLE);
				}
				break;
			case ABS:
			case ALL:
			case AND:
			case ANY:
			case AS:
			case ASC:
			case AVG:
			case BETWEEN:
			case BOTH:
			case BY:
			case CASE:
			case CAST:
			case CEILING:
			case COALESCE:
			case CONCAT:
			case COUNT:
			case CURRENT_DATE:
			case CURRENT_TIME:
			case CURRENT_TIMESTAMP:
			case DATE:
			case DATETIME:
			case DELETE:
			case DESC:
			case DISTINCT:
			case END:
			case ELSE:
			case EMPTY:
			case ENTRY:
			case ESCAPE:
			case EXISTS:
			case EXP:
			case EXTRACT:
			case FALSE:
			case FETCH:
			case FLOOR:
			case FUNCTION:
			case IN:
			case INDEX:
			case INNER:
			case IS:
			case KEY:
			case LEFT:
			case LENGTH:
			case LIKE:
			case LN:
			case LOCAL:
			case LOCATE:
			case LOWER:
			case MAX:
			case MEMBER:
			case MIN:
			case MOD:
			case NEW:
			case NOT:
			case NULL:
			case NULLIF:
			case OBJECT:
			case OF:
			case ON:
			case OR:
			case ORDER:
			case OUTER:
			case POWER:
			case ROUND:
			case SELECT:
			case SET:
			case SIGN:
			case SIZE:
			case SOME:
			case SQRT:
			case SUBSTRING:
			case SUM:
			case THEN:
			case TIME:
			case TRAILING:
			case TREAT:
			case TRIM:
			case TRUE:
			case TYPE:
			case UPDATE:
			case UPPER:
			case VALUE:
				enterOuterAlt(_localctx, 2);
				{
				setState(1475);
				((Reserved_wordContext)_localctx).f = _input.LT(1);
				_la = _input.LA(1);
				if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 6672081748437696512L) != 0) || ((((_la - 65)) & ~0x3f) == 0 && ((1L << (_la - 65)) & 281406122491385L) != 0)) ) {
					((Reserved_wordContext)_localctx).f = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 56:
			return conditional_expression_sempred((Conditional_expressionContext)_localctx, predIndex);
		case 57:
			return conditional_term_sempred((Conditional_termContext)_localctx, predIndex);
		case 74:
			return arithmetic_expression_sempred((Arithmetic_expressionContext)_localctx, predIndex);
		case 75:
			return arithmetic_term_sempred((Arithmetic_termContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean conditional_expression_sempred(Conditional_expressionContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return precpred(_ctx, 1);
		}
		return true;
	}
	private boolean conditional_term_sempred(Conditional_termContext _localctx, int predIndex) {
		switch (predIndex) {
		case 1:
			return precpred(_ctx, 1);
		}
		return true;
	}
	private boolean arithmetic_expression_sempred(Arithmetic_expressionContext _localctx, int predIndex) {
		switch (predIndex) {
		case 2:
			return precpred(_ctx, 1);
		}
		return true;
	}
	private boolean arithmetic_term_sempred(Arithmetic_termContext _localctx, int predIndex) {
		switch (predIndex) {
		case 3:
			return precpred(_ctx, 1);
		}
		return true;
	}

	public static final String _serializedATN =
		"\u0004\u0001{\u05c7\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001\u0002"+
		"\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004\u0002"+
		"\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002\u0007\u0007\u0007\u0002"+
		"\b\u0007\b\u0002\t\u0007\t\u0002\n\u0007\n\u0002\u000b\u0007\u000b\u0002"+
		"\f\u0007\f\u0002\r\u0007\r\u0002\u000e\u0007\u000e\u0002\u000f\u0007\u000f"+
		"\u0002\u0010\u0007\u0010\u0002\u0011\u0007\u0011\u0002\u0012\u0007\u0012"+
		"\u0002\u0013\u0007\u0013\u0002\u0014\u0007\u0014\u0002\u0015\u0007\u0015"+
		"\u0002\u0016\u0007\u0016\u0002\u0017\u0007\u0017\u0002\u0018\u0007\u0018"+
		"\u0002\u0019\u0007\u0019\u0002\u001a\u0007\u001a\u0002\u001b\u0007\u001b"+
		"\u0002\u001c\u0007\u001c\u0002\u001d\u0007\u001d\u0002\u001e\u0007\u001e"+
		"\u0002\u001f\u0007\u001f\u0002 \u0007 \u0002!\u0007!\u0002\"\u0007\"\u0002"+
		"#\u0007#\u0002$\u0007$\u0002%\u0007%\u0002&\u0007&\u0002\'\u0007\'\u0002"+
		"(\u0007(\u0002)\u0007)\u0002*\u0007*\u0002+\u0007+\u0002,\u0007,\u0002"+
		"-\u0007-\u0002.\u0007.\u0002/\u0007/\u00020\u00070\u00021\u00071\u0002"+
		"2\u00072\u00023\u00073\u00024\u00074\u00025\u00075\u00026\u00076\u0002"+
		"7\u00077\u00028\u00078\u00029\u00079\u0002:\u0007:\u0002;\u0007;\u0002"+
		"<\u0007<\u0002=\u0007=\u0002>\u0007>\u0002?\u0007?\u0002@\u0007@\u0002"+
		"A\u0007A\u0002B\u0007B\u0002C\u0007C\u0002D\u0007D\u0002E\u0007E\u0002"+
		"F\u0007F\u0002G\u0007G\u0002H\u0007H\u0002I\u0007I\u0002J\u0007J\u0002"+
		"K\u0007K\u0002L\u0007L\u0002M\u0007M\u0002N\u0007N\u0002O\u0007O\u0002"+
		"P\u0007P\u0002Q\u0007Q\u0002R\u0007R\u0002S\u0007S\u0002T\u0007T\u0002"+
		"U\u0007U\u0002V\u0007V\u0002W\u0007W\u0002X\u0007X\u0002Y\u0007Y\u0002"+
		"Z\u0007Z\u0002[\u0007[\u0002\\\u0007\\\u0002]\u0007]\u0002^\u0007^\u0002"+
		"_\u0007_\u0002`\u0007`\u0002a\u0007a\u0002b\u0007b\u0002c\u0007c\u0002"+
		"d\u0007d\u0002e\u0007e\u0002f\u0007f\u0002g\u0007g\u0002h\u0007h\u0002"+
		"i\u0007i\u0002j\u0007j\u0002k\u0007k\u0002l\u0007l\u0002m\u0007m\u0002"+
		"n\u0007n\u0002o\u0007o\u0002p\u0007p\u0002q\u0007q\u0002r\u0007r\u0002"+
		"s\u0007s\u0002t\u0007t\u0002u\u0007u\u0002v\u0007v\u0002w\u0007w\u0002"+
		"x\u0007x\u0002y\u0007y\u0002z\u0007z\u0002{\u0007{\u0002|\u0007|\u0002"+
		"}\u0007}\u0002~\u0007~\u0002\u007f\u0007\u007f\u0002\u0080\u0007\u0080"+
		"\u0002\u0081\u0007\u0081\u0002\u0082\u0007\u0082\u0002\u0083\u0007\u0083"+
		"\u0002\u0084\u0007\u0084\u0002\u0085\u0007\u0085\u0001\u0000\u0001\u0000"+
		"\u0001\u0000\u0001\u0001\u0001\u0001\u0001\u0001\u0003\u0001\u0113\b\u0001"+
		"\u0001\u0002\u0001\u0002\u0001\u0002\u0003\u0002\u0118\b\u0002\u0001\u0002"+
		"\u0003\u0002\u011b\b\u0002\u0001\u0002\u0003\u0002\u011e\b\u0002\u0001"+
		"\u0002\u0003\u0002\u0121\b\u0002\u0001\u0003\u0001\u0003\u0003\u0003\u0125"+
		"\b\u0003\u0001\u0004\u0001\u0004\u0003\u0004\u0129\b\u0004\u0001\u0005"+
		"\u0001\u0005\u0001\u0005\u0001\u0005\u0005\u0005\u012f\b\u0005\n\u0005"+
		"\f\u0005\u0132\t\u0005\u0001\u0006\u0001\u0006\u0003\u0006\u0136\b\u0006"+
		"\u0001\u0007\u0001\u0007\u0001\u0007\u0005\u0007\u013b\b\u0007\n\u0007"+
		"\f\u0007\u013e\t\u0007\u0001\b\u0001\b\u0003\b\u0142\b\b\u0001\b\u0001"+
		"\b\u0001\t\u0001\t\u0001\t\u0003\t\u0149\b\t\u0001\t\u0001\t\u0003\t\u014d"+
		"\b\t\u0001\n\u0001\n\u0001\n\u0001\n\u0001\u000b\u0001\u000b\u0003\u000b"+
		"\u0155\b\u000b\u0001\u000b\u0003\u000b\u0158\b\u000b\u0001\u000b\u0001"+
		"\u000b\u0001\f\u0001\f\u0001\f\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r"+
		"\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001"+
		"\r\u0001\r\u0001\r\u0003\r\u016f\b\r\u0001\u000e\u0001\u000e\u0001\u000e"+
		"\u0001\u000e\u0001\u000e\u0005\u000e\u0176\b\u000e\n\u000e\f\u000e\u0179"+
		"\t\u000e\u0001\u000e\u0001\u000e\u0001\u000f\u0001\u000f\u0001\u000f\u0001"+
		"\u000f\u0001\u000f\u0005\u000f\u0182\b\u000f\n\u000f\f\u000f\u0185\t\u000f"+
		"\u0001\u000f\u0001\u000f\u0001\u0010\u0001\u0010\u0001\u0010\u0001\u0010"+
		"\u0001\u0010\u0003\u0010\u018e\b\u0010\u0001\u0010\u0001\u0010\u0001\u0011"+
		"\u0001\u0011\u0001\u0011\u0001\u0011\u0001\u0011\u0001\u0011\u0003\u0011"+
		"\u0198\b\u0011\u0001\u0012\u0001\u0012\u0001\u0012\u0001\u0012\u0001\u0012"+
		"\u0001\u0012\u0001\u0012\u0001\u0012\u0001\u0012\u0001\u0012\u0003\u0012"+
		"\u01a4\b\u0012\u0001\u0013\u0001\u0013\u0001\u0013\u0001\u0013\u0001\u0013"+
		"\u0001\u0013\u0001\u0013\u0001\u0013\u0001\u0013\u0001\u0013\u0003\u0013"+
		"\u01b0\b\u0013\u0001\u0014\u0001\u0014\u0003\u0014\u01b4\b\u0014\u0001"+
		"\u0015\u0001\u0015\u0001\u0015\u0001\u0015\u0005\u0015\u01ba\b\u0015\n"+
		"\u0015\f\u0015\u01bd\t\u0015\u0003\u0015\u01bf\b\u0015\u0001\u0016\u0001"+
		"\u0016\u0001\u0016\u0001\u0016\u0005\u0016\u01c5\b\u0016\n\u0016\f\u0016"+
		"\u01c8\t\u0016\u0003\u0016\u01ca\b\u0016\u0001\u0017\u0001\u0017\u0001"+
		"\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0017\u0001\u0018\u0001"+
		"\u0018\u0001\u0018\u0001\u0018\u0001\u0019\u0001\u0019\u0003\u0019\u01d9"+
		"\b\u0019\u0001\u001a\u0001\u001a\u0001\u001a\u0001\u001a\u0001\u001b\u0001"+
		"\u001b\u0001\u001b\u0001\u001b\u0001\u001c\u0001\u001c\u0001\u001c\u0003"+
		"\u001c\u01e6\b\u001c\u0001\u001c\u0003\u001c\u01e9\b\u001c\u0001\u001c"+
		"\u0001\u001c\u0001\u001c\u0001\u001c\u0005\u001c\u01ef\b\u001c\n\u001c"+
		"\f\u001c\u01f2\t\u001c\u0001\u001d\u0001\u001d\u0001\u001d\u0003\u001d"+
		"\u01f7\b\u001d\u0001\u001d\u0001\u001d\u0001\u001d\u0005\u001d\u01fc\b"+
		"\u001d\n\u001d\f\u001d\u01ff\t\u001d\u0001\u001d\u0001\u001d\u0003\u001d"+
		"\u0203\b\u001d\u0001\u001d\u0001\u001d\u0001\u001d\u0001\u001e\u0001\u001e"+
		"\u0001\u001e\u0003\u001e\u020b\b\u001e\u0001\u001f\u0001\u001f\u0001\u001f"+
		"\u0001\u001f\u0003\u001f\u0211\b\u001f\u0001\u001f\u0003\u001f\u0214\b"+
		"\u001f\u0001 \u0001 \u0003 \u0218\b \u0001 \u0001 \u0001 \u0005 \u021d"+
		"\b \n \f \u0220\t \u0001!\u0001!\u0003!\u0224\b!\u0001!\u0003!\u0227\b"+
		"!\u0001\"\u0001\"\u0001\"\u0001\"\u0001\"\u0001\"\u0001\"\u0001\"\u0001"+
		"\"\u0001\"\u0003\"\u0233\b\"\u0001#\u0001#\u0001#\u0001#\u0001#\u0001"+
		"#\u0005#\u023b\b#\n#\f#\u023e\t#\u0001#\u0001#\u0001$\u0001$\u0001$\u0001"+
		"$\u0001$\u0003$\u0247\b$\u0001%\u0001%\u0001%\u0003%\u024c\b%\u0001%\u0001"+
		"%\u0001%\u0001%\u0001%\u0001%\u0003%\u0254\b%\u0001%\u0001%\u0001%\u0003"+
		"%\u0259\b%\u0001%\u0001%\u0001%\u0003%\u025e\b%\u0001&\u0001&\u0001&\u0001"+
		"\'\u0001\'\u0001\'\u0001\'\u0001\'\u0005\'\u0268\b\'\n\'\f\'\u026b\t\'"+
		"\u0001(\u0001(\u0003(\u026f\b(\u0001)\u0001)\u0001)\u0001*\u0001*\u0001"+
		"*\u0001*\u0001*\u0005*\u0279\b*\n*\f*\u027c\t*\u0001+\u0001+\u0001+\u0003"+
		"+\u0281\b+\u0001+\u0003+\u0284\b+\u0001+\u0003+\u0287\b+\u0001,\u0001"+
		",\u0001,\u0001-\u0001-\u0001-\u0003-\u028f\b-\u0001-\u0003-\u0292\b-\u0001"+
		"-\u0003-\u0295\b-\u0001.\u0001.\u0001.\u0001.\u0001.\u0003.\u029c\b.\u0005"+
		".\u029e\b.\n.\f.\u02a1\t.\u0001/\u0001/\u0001/\u0003/\u02a6\b/\u0001/"+
		"\u0001/\u0005/\u02aa\b/\n/\f/\u02ad\t/\u0001/\u0003/\u02b0\b/\u00010\u0001"+
		"0\u00010\u00010\u00010\u00010\u00010\u00010\u00030\u02ba\b0\u00011\u0001"+
		"1\u00011\u00011\u00051\u02c0\b1\n1\f1\u02c3\t1\u00031\u02c5\b1\u00012"+
		"\u00012\u00012\u00052\u02ca\b2\n2\f2\u02cd\t2\u00013\u00013\u00013\u0001"+
		"3\u00013\u00013\u00013\u00014\u00014\u00014\u00014\u00014\u00014\u0005"+
		"4\u02dc\b4\n4\f4\u02df\t4\u00014\u00014\u00015\u00015\u00035\u02e5\b5"+
		"\u00015\u00015\u00016\u00016\u00016\u00016\u00036\u02ed\b6\u00017\u0001"+
		"7\u00017\u00017\u00017\u00017\u00017\u00037\u02f6\b7\u00018\u00018\u0001"+
		"8\u00018\u00018\u00018\u00058\u02fe\b8\n8\f8\u0301\t8\u00019\u00019\u0001"+
		"9\u00019\u00019\u00019\u00059\u0309\b9\n9\f9\u030c\t9\u0001:\u0003:\u030f"+
		"\b:\u0001:\u0001:\u0001;\u0001;\u0001;\u0001;\u0001;\u0003;\u0318\b;\u0001"+
		"<\u0001<\u0001<\u0001<\u0001<\u0001<\u0001<\u0001<\u0003<\u0322\b<\u0001"+
		"=\u0001=\u0003=\u0326\b=\u0001=\u0001=\u0001=\u0001=\u0001=\u0001=\u0001"+
		"=\u0003=\u032f\b=\u0001=\u0001=\u0001=\u0001=\u0001=\u0001=\u0001=\u0003"+
		"=\u0338\b=\u0001=\u0001=\u0001=\u0001=\u0001=\u0003=\u033f\b=\u0001>\u0001"+
		">\u0003>\u0343\b>\u0001>\u0003>\u0346\b>\u0001>\u0001>\u0001>\u0001>\u0001"+
		">\u0005>\u034d\b>\n>\f>\u0350\t>\u0001>\u0001>\u0001>\u0001>\u0001>\u0001"+
		">\u0001>\u0003>\u0359\b>\u0001?\u0001?\u0001?\u0001?\u0001?\u0001?\u0001"+
		"?\u0003?\u0362\b?\u0001@\u0001@\u0003@\u0366\b@\u0001@\u0001@\u0001@\u0001"+
		"@\u0003@\u036c\b@\u0001A\u0001A\u0003A\u0370\bA\u0001A\u0001A\u0003A\u0374"+
		"\bA\u0001A\u0001A\u0001B\u0001B\u0001B\u0003B\u037b\bB\u0001B\u0001B\u0001"+
		"C\u0001C\u0003C\u0381\bC\u0001C\u0001C\u0003C\u0385\bC\u0001C\u0001C\u0001"+
		"D\u0001D\u0001D\u0003D\u038c\bD\u0001E\u0001E\u0001E\u0003E\u0391\bE\u0001"+
		"F\u0003F\u0394\bF\u0001F\u0001F\u0001F\u0001F\u0001F\u0001G\u0001G\u0001"+
		"G\u0001G\u0001G\u0001H\u0001H\u0001H\u0001H\u0003H\u03a4\bH\u0001H\u0001"+
		"H\u0001H\u0001H\u0003H\u03aa\bH\u0001H\u0001H\u0001H\u0001H\u0001H\u0003"+
		"H\u03b1\bH\u0001H\u0001H\u0001H\u0001H\u0003H\u03b7\bH\u0001H\u0001H\u0001"+
		"H\u0001H\u0003H\u03bd\bH\u0001H\u0001H\u0001H\u0001H\u0003H\u03c3\bH\u0001"+
		"H\u0001H\u0001H\u0001H\u0001H\u0001H\u0001H\u0001H\u0003H\u03cd\bH\u0001"+
		"I\u0001I\u0001I\u0001I\u0001I\u0001I\u0003I\u03d5\bI\u0001J\u0001J\u0001"+
		"J\u0001J\u0001J\u0001J\u0005J\u03dd\bJ\nJ\fJ\u03e0\tJ\u0001K\u0001K\u0001"+
		"K\u0001K\u0001K\u0001K\u0005K\u03e8\bK\nK\fK\u03eb\tK\u0001L\u0003L\u03ee"+
		"\bL\u0001L\u0001L\u0001M\u0001M\u0001M\u0001M\u0001M\u0001M\u0001M\u0001"+
		"M\u0001M\u0001M\u0001M\u0001M\u0001M\u0001M\u0001M\u0001M\u0001M\u0003"+
		"M\u0403\bM\u0001N\u0001N\u0001N\u0001N\u0001N\u0001N\u0001N\u0001N\u0001"+
		"N\u0001N\u0001N\u0001N\u0001N\u0003N\u0412\bN\u0001O\u0001O\u0001O\u0001"+
		"O\u0001O\u0001O\u0001O\u0001O\u0001O\u0001O\u0001O\u0003O\u041f\bO\u0001"+
		"P\u0001P\u0001P\u0001P\u0001P\u0001P\u0001P\u0001P\u0001P\u0003P\u042a"+
		"\bP\u0001Q\u0001Q\u0001Q\u0001Q\u0001Q\u0001Q\u0001Q\u0001Q\u0003Q\u0434"+
		"\bQ\u0001R\u0001R\u0003R\u0438\bR\u0001S\u0001S\u0003S\u043c\bS\u0001"+
		"T\u0001T\u0001T\u0003T\u0441\bT\u0001U\u0001U\u0001U\u0001U\u0001U\u0003"+
		"U\u0448\bU\u0001U\u0001U\u0001V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001"+
		"V\u0001V\u0001V\u0001V\u0001V\u0001V\u0003V\u0458\bV\u0001V\u0001V\u0001"+
		"V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001"+
		"V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001"+
		"V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001"+
		"V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001"+
		"V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001"+
		"V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001"+
		"V\u0001V\u0001V\u0001V\u0001V\u0001V\u0001V\u0003V\u049f\bV\u0001W\u0001"+
		"W\u0001W\u0001W\u0001W\u0001W\u0001W\u0001W\u0001W\u0001W\u0003W\u04ab"+
		"\bW\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0005X\u04b4\bX\n"+
		"X\fX\u04b7\tX\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X"+
		"\u0001X\u0003X\u04c2\bX\u0001X\u0001X\u0001X\u0001X\u0001X\u0003X\u04c9"+
		"\bX\u0001X\u0003X\u04cc\bX\u0001X\u0003X\u04cf\bX\u0001X\u0001X\u0001"+
		"X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001X\u0001"+
		"X\u0003X\u04de\bX\u0001Y\u0001Y\u0001Z\u0001Z\u0001Z\u0001Z\u0003Z\u04e6"+
		"\bZ\u0001Z\u0001Z\u0001Z\u0001[\u0001[\u0001[\u0001[\u0003[\u04ef\b[\u0001"+
		"[\u0001[\u0001[\u0001[\u0001[\u0005[\u04f6\b[\n[\f[\u04f9\t[\u0001[\u0001"+
		"[\u0003[\u04fd\b[\u0001[\u0001[\u0001\\\u0001\\\u0001\\\u0001\\\u0003"+
		"\\\u0505\b\\\u0001\\\u0001\\\u0001\\\u0001]\u0001]\u0001]\u0001]\u0001"+
		"]\u0005]\u050f\b]\n]\f]\u0512\t]\u0001]\u0001]\u0001^\u0001^\u0001^\u0001"+
		"^\u0001^\u0001^\u0001^\u0001_\u0001_\u0001`\u0001`\u0001`\u0001`\u0001"+
		"`\u0001`\u0001`\u0001a\u0001a\u0001b\u0001b\u0001b\u0001b\u0003b\u052c"+
		"\bb\u0001c\u0001c\u0001c\u0001c\u0003c\u0532\bc\u0001d\u0001d\u0001d\u0005"+
		"d\u0537\bd\nd\fd\u053a\td\u0001d\u0001d\u0001d\u0001d\u0001e\u0001e\u0001"+
		"e\u0001e\u0001e\u0001f\u0001f\u0001f\u0001f\u0005f\u0549\bf\nf\ff\u054c"+
		"\tf\u0001f\u0001f\u0001f\u0001f\u0001g\u0001g\u0003g\u0554\bg\u0001h\u0001"+
		"h\u0001h\u0001h\u0001h\u0001i\u0001i\u0001i\u0001i\u0001i\u0004i\u0560"+
		"\bi\u000bi\fi\u0561\u0001i\u0001i\u0001j\u0001j\u0001j\u0001j\u0001j\u0001"+
		"j\u0001j\u0001k\u0001k\u0003k\u056f\bk\u0001l\u0001l\u0003l\u0573\bl\u0001"+
		"m\u0001m\u0001n\u0001n\u0001n\u0001n\u0001n\u0001n\u0001n\u0003n\u057e"+
		"\bn\u0001o\u0001o\u0001o\u0001o\u0003o\u0584\bo\u0001p\u0001p\u0001q\u0001"+
		"q\u0001r\u0001r\u0001s\u0001s\u0001s\u0003s\u058f\bs\u0001t\u0001t\u0001"+
		"u\u0001u\u0001v\u0001v\u0001w\u0001w\u0001x\u0001x\u0001y\u0001y\u0001"+
		"z\u0001z\u0003z\u059f\bz\u0001{\u0001{\u0003{\u05a3\b{\u0001|\u0001|\u0003"+
		"|\u05a7\b|\u0001}\u0001}\u0003}\u05ab\b}\u0001~\u0001~\u0001~\u0005~\u05b0"+
		"\b~\n~\f~\u05b3\t~\u0001\u007f\u0001\u007f\u0001\u0080\u0001\u0080\u0001"+
		"\u0081\u0001\u0081\u0001\u0082\u0001\u0082\u0001\u0083\u0001\u0083\u0001"+
		"\u0084\u0001\u0084\u0003\u0084\u05c1\b\u0084\u0001\u0085\u0001\u0085\u0003"+
		"\u0085\u05c5\b\u0085\u0001\u0085\u0000\u0004pr\u0094\u0096\u0086\u0000"+
		"\u0002\u0004\u0006\b\n\f\u000e\u0010\u0012\u0014\u0016\u0018\u001a\u001c"+
		"\u001e \"$&(*,.02468:<>@BDFHJLNPRTVXZ\\^`bdfhjlnprtvxz|~\u0080\u0082\u0084"+
		"\u0086\u0088\u008a\u008c\u008e\u0090\u0092\u0094\u0096\u0098\u009a\u009c"+
		"\u009e\u00a0\u00a2\u00a4\u00a6\u00a8\u00aa\u00ac\u00ae\u00b0\u00b2\u00b4"+
		"\u00b6\u00b8\u00ba\u00bc\u00be\u00c0\u00c2\u00c4\u00c6\u00c8\u00ca\u00cc"+
		"\u00ce\u00d0\u00d2\u00d4\u00d6\u00d8\u00da\u00dc\u00de\u00e0\u00e2\u00e4"+
		"\u00e6\u00e8\u00ea\u00ec\u00ee\u00f0\u00f2\u00f4\u00f6\u00f8\u00fa\u00fc"+
		"\u00fe\u0100\u0102\u0104\u0106\u0108\u010a\u0000\u000e\u0004\u0000\u0016"+
		"\u0016LLNNff\u0002\u0000\u0015\u0015&&\u0002\u000033BB\u0003\u0000\u0011"+
		"\u0011\u0013\u0013bb\u0001\u0000st\u0001\u0000\t\n\u0001\u0000\u000b\f"+
		"\u0003\u0000\u0018\u0018CCii\u0004\u0000((55??JJ\r\u0000\u001f\u001f#"+
		"#4466<<AADDPPY[``hhmmpp\u0001\u0000y{\u0002\u000011ll\u0002\u0000uuww"+
		"\f\u0000\u0010\')24477:<>>AADIKSU[]dfp\u0646\u0000\u010c\u0001\u0000\u0000"+
		"\u0000\u0002\u0112\u0001\u0000\u0000\u0000\u0004\u0114\u0001\u0000\u0000"+
		"\u0000\u0006\u0122\u0001\u0000\u0000\u0000\b\u0126\u0001\u0000\u0000\u0000"+
		"\n\u012a\u0001\u0000\u0000\u0000\f\u0135\u0001\u0000\u0000\u0000\u000e"+
		"\u0137\u0001\u0000\u0000\u0000\u0010\u013f\u0001\u0000\u0000\u0000\u0012"+
		"\u0145\u0001\u0000\u0000\u0000\u0014\u014e\u0001\u0000\u0000\u0000\u0016"+
		"\u0157\u0001\u0000\u0000\u0000\u0018\u015b\u0001\u0000\u0000\u0000\u001a"+
		"\u016e\u0001\u0000\u0000\u0000\u001c\u0170\u0001\u0000\u0000\u0000\u001e"+
		"\u017c\u0001\u0000\u0000\u0000 \u0188\u0001\u0000\u0000\u0000\"\u0197"+
		"\u0001\u0000\u0000\u0000$\u01a3\u0001\u0000\u0000\u0000&\u01af\u0001\u0000"+
		"\u0000\u0000(\u01b3\u0001\u0000\u0000\u0000*\u01be\u0001\u0000\u0000\u0000"+
		",\u01c9\u0001\u0000\u0000\u0000.\u01cb\u0001\u0000\u0000\u00000\u01d2"+
		"\u0001\u0000\u0000\u00002\u01d8\u0001\u0000\u0000\u00004\u01da\u0001\u0000"+
		"\u0000\u00006\u01de\u0001\u0000\u0000\u00008\u01e2\u0001\u0000\u0000\u0000"+
		":\u01f6\u0001\u0000\u0000\u0000<\u020a\u0001\u0000\u0000\u0000>\u020c"+
		"\u0001\u0000\u0000\u0000@\u0215\u0001\u0000\u0000\u0000B\u0221\u0001\u0000"+
		"\u0000\u0000D\u0232\u0001\u0000\u0000\u0000F\u0234\u0001\u0000\u0000\u0000"+
		"H\u0246\u0001\u0000\u0000\u0000J\u025d\u0001\u0000\u0000\u0000L\u025f"+
		"\u0001\u0000\u0000\u0000N\u0262\u0001\u0000\u0000\u0000P\u026e\u0001\u0000"+
		"\u0000\u0000R\u0270\u0001\u0000\u0000\u0000T\u0273\u0001\u0000\u0000\u0000"+
		"V\u0280\u0001\u0000\u0000\u0000X\u0288\u0001\u0000\u0000\u0000Z\u028b"+
		"\u0001\u0000\u0000\u0000\\\u0296\u0001\u0000\u0000\u0000^\u02af\u0001"+
		"\u0000\u0000\u0000`\u02b9\u0001\u0000\u0000\u0000b\u02c4\u0001\u0000\u0000"+
		"\u0000d\u02c6\u0001\u0000\u0000\u0000f\u02ce\u0001\u0000\u0000\u0000h"+
		"\u02d5\u0001\u0000\u0000\u0000j\u02e2\u0001\u0000\u0000\u0000l\u02ec\u0001"+
		"\u0000\u0000\u0000n\u02f5\u0001\u0000\u0000\u0000p\u02f7\u0001\u0000\u0000"+
		"\u0000r\u0302\u0001\u0000\u0000\u0000t\u030e\u0001\u0000\u0000\u0000v"+
		"\u0317\u0001\u0000\u0000\u0000x\u0321\u0001\u0000\u0000\u0000z\u033e\u0001"+
		"\u0000\u0000\u0000|\u0342\u0001\u0000\u0000\u0000~\u0361\u0001\u0000\u0000"+
		"\u0000\u0080\u0363\u0001\u0000\u0000\u0000\u0082\u036f\u0001\u0000\u0000"+
		"\u0000\u0084\u0377\u0001\u0000\u0000\u0000\u0086\u037e\u0001\u0000\u0000"+
		"\u0000\u0088\u038b\u0001\u0000\u0000\u0000\u008a\u0390\u0001\u0000\u0000"+
		"\u0000\u008c\u0393\u0001\u0000\u0000\u0000\u008e\u039a\u0001\u0000\u0000"+
		"\u0000\u0090\u03cc\u0001\u0000\u0000\u0000\u0092\u03d4\u0001\u0000\u0000"+
		"\u0000\u0094\u03d6\u0001\u0000\u0000\u0000\u0096\u03e1\u0001\u0000\u0000"+
		"\u0000\u0098\u03ed\u0001\u0000\u0000\u0000\u009a\u0402\u0001\u0000\u0000"+
		"\u0000\u009c\u0411\u0001\u0000\u0000\u0000\u009e\u041e\u0001\u0000\u0000"+
		"\u0000\u00a0\u0429\u0001\u0000\u0000\u0000\u00a2\u0433\u0001\u0000\u0000"+
		"\u0000\u00a4\u0437\u0001\u0000\u0000\u0000\u00a6\u043b\u0001\u0000\u0000"+
		"\u0000\u00a8\u0440\u0001\u0000\u0000\u0000\u00aa\u0442\u0001\u0000\u0000"+
		"\u0000\u00ac\u049e\u0001\u0000\u0000\u0000\u00ae\u04aa\u0001\u0000\u0000"+
		"\u0000\u00b0\u04dd\u0001\u0000\u0000\u0000\u00b2\u04df\u0001\u0000\u0000"+
		"\u0000\u00b4\u04e1\u0001\u0000\u0000\u0000\u00b6\u04ea\u0001\u0000\u0000"+
		"\u0000\u00b8\u0500\u0001\u0000\u0000\u0000\u00ba\u0509\u0001\u0000\u0000"+
		"\u0000\u00bc\u0515\u0001\u0000\u0000\u0000\u00be\u051c\u0001\u0000\u0000"+
		"\u0000\u00c0\u051e\u0001\u0000\u0000\u0000\u00c2\u0525\u0001\u0000\u0000"+
		"\u0000\u00c4\u052b\u0001\u0000\u0000\u0000\u00c6\u0531\u0001\u0000\u0000"+
		"\u0000\u00c8\u0533\u0001\u0000\u0000\u0000\u00ca\u053f\u0001\u0000\u0000"+
		"\u0000\u00cc\u0544\u0001\u0000\u0000\u0000\u00ce\u0553\u0001\u0000\u0000"+
		"\u0000\u00d0\u0555\u0001\u0000\u0000\u0000\u00d2\u055a\u0001\u0000\u0000"+
		"\u0000\u00d4\u0565\u0001\u0000\u0000\u0000\u00d6\u056e\u0001\u0000\u0000"+
		"\u0000\u00d8\u0572\u0001\u0000\u0000\u0000\u00da\u0574\u0001\u0000\u0000"+
		"\u0000\u00dc\u057d\u0001\u0000\u0000\u0000\u00de\u0583\u0001\u0000\u0000"+
		"\u0000\u00e0\u0585\u0001\u0000\u0000\u0000\u00e2\u0587\u0001\u0000\u0000"+
		"\u0000\u00e4\u0589\u0001\u0000\u0000\u0000\u00e6\u058e\u0001\u0000\u0000"+
		"\u0000\u00e8\u0590\u0001\u0000\u0000\u0000\u00ea\u0592\u0001\u0000\u0000"+
		"\u0000\u00ec\u0594\u0001\u0000\u0000\u0000\u00ee\u0596\u0001\u0000\u0000"+
		"\u0000\u00f0\u0598\u0001\u0000\u0000\u0000\u00f2\u059a\u0001\u0000\u0000"+
		"\u0000\u00f4\u059e\u0001\u0000\u0000\u0000\u00f6\u05a2\u0001\u0000\u0000"+
		"\u0000\u00f8\u05a6\u0001\u0000\u0000\u0000\u00fa\u05aa\u0001\u0000\u0000"+
		"\u0000\u00fc\u05ac\u0001\u0000\u0000\u0000\u00fe\u05b4\u0001\u0000\u0000"+
		"\u0000\u0100\u05b6\u0001\u0000\u0000\u0000\u0102\u05b8\u0001\u0000\u0000"+
		"\u0000\u0104\u05ba\u0001\u0000\u0000\u0000\u0106\u05bc\u0001\u0000\u0000"+
		"\u0000\u0108\u05c0\u0001\u0000\u0000\u0000\u010a\u05c4\u0001\u0000\u0000"+
		"\u0000\u010c\u010d\u0003\u0002\u0001\u0000\u010d\u010e\u0005\u0000\u0000"+
		"\u0001\u010e\u0001\u0001\u0000\u0000\u0000\u010f\u0113\u0003\u0004\u0002"+
		"\u0000\u0110\u0113\u0003\u0006\u0003\u0000\u0111\u0113\u0003\b\u0004\u0000"+
		"\u0112\u010f\u0001\u0000\u0000\u0000\u0112\u0110\u0001\u0000\u0000\u0000"+
		"\u0112\u0111\u0001\u0000\u0000\u0000\u0113\u0003\u0001\u0000\u0000\u0000"+
		"\u0114\u0115\u0003@ \u0000\u0115\u0117\u0003\n\u0005\u0000\u0116\u0118"+
		"\u0003L&\u0000\u0117\u0116\u0001\u0000\u0000\u0000\u0117\u0118\u0001\u0000"+
		"\u0000\u0000\u0118\u011a\u0001\u0000\u0000\u0000\u0119\u011b\u0003N\'"+
		"\u0000\u011a\u0119\u0001\u0000\u0000\u0000\u011a\u011b\u0001\u0000\u0000"+
		"\u0000\u011b\u011d\u0001\u0000\u0000\u0000\u011c\u011e\u0003R)\u0000\u011d"+
		"\u011c\u0001\u0000\u0000\u0000\u011d\u011e\u0001\u0000\u0000\u0000\u011e"+
		"\u0120\u0001\u0000\u0000\u0000\u011f\u0121\u0003T*\u0000\u0120\u011f\u0001"+
		"\u0000\u0000\u0000\u0120\u0121\u0001\u0000\u0000\u0000\u0121\u0005\u0001"+
		"\u0000\u0000\u0000\u0122\u0124\u00038\u001c\u0000\u0123\u0125\u0003L&"+
		"\u0000\u0124\u0123\u0001\u0000\u0000\u0000\u0124\u0125\u0001\u0000\u0000"+
		"\u0000\u0125\u0007\u0001\u0000\u0000\u0000\u0126\u0128\u0003>\u001f\u0000"+
		"\u0127\u0129\u0003L&\u0000\u0128\u0127\u0001\u0000\u0000\u0000\u0128\u0129"+
		"\u0001\u0000\u0000\u0000\u0129\t\u0001\u0000\u0000\u0000\u012a\u012b\u0005"+
		"6\u0000\u0000\u012b\u0130\u0003\u000e\u0007\u0000\u012c\u012d\u0005\u0001"+
		"\u0000\u0000\u012d\u012f\u0003\f\u0006\u0000\u012e\u012c\u0001\u0000\u0000"+
		"\u0000\u012f\u0132\u0001\u0000\u0000\u0000\u0130\u012e\u0001\u0000\u0000"+
		"\u0000\u0130\u0131\u0001\u0000\u0000\u0000\u0131\u000b\u0001\u0000\u0000"+
		"\u0000\u0132\u0130\u0001\u0000\u0000\u0000\u0133\u0136\u0003\u000e\u0007"+
		"\u0000\u0134\u0136\u0003 \u0010\u0000\u0135\u0133\u0001\u0000\u0000\u0000"+
		"\u0135\u0134\u0001\u0000\u0000\u0000\u0136\r\u0001\u0000\u0000\u0000\u0137"+
		"\u013c\u0003\u0010\b\u0000\u0138\u013b\u0003\u0012\t\u0000\u0139\u013b"+
		"\u0003\u0014\n\u0000\u013a\u0138\u0001\u0000\u0000\u0000\u013a\u0139\u0001"+
		"\u0000\u0000\u0000\u013b\u013e\u0001\u0000\u0000\u0000\u013c\u013a\u0001"+
		"\u0000\u0000\u0000\u013c\u013d\u0001\u0000\u0000\u0000\u013d\u000f\u0001"+
		"\u0000\u0000\u0000\u013e\u013c\u0001\u0000\u0000\u0000\u013f\u0141\u0003"+
		"\u00fc~\u0000\u0140\u0142\u0005\u0014\u0000\u0000\u0141\u0140\u0001\u0000"+
		"\u0000\u0000\u0141\u0142\u0001\u0000\u0000\u0000\u0142\u0143\u0001\u0000"+
		"\u0000\u0000\u0143\u0144\u0003\u00d8l\u0000\u0144\u0011\u0001\u0000\u0000"+
		"\u0000\u0145\u0146\u0003\u0016\u000b\u0000\u0146\u0148\u0003\u001a\r\u0000"+
		"\u0147\u0149\u0005\u0014\u0000\u0000\u0148\u0147\u0001\u0000\u0000\u0000"+
		"\u0148\u0149\u0001\u0000\u0000\u0000\u0149\u014a\u0001\u0000\u0000\u0000"+
		"\u014a\u014c\u0003\u00d8l\u0000\u014b\u014d\u0003\u0018\f\u0000\u014c"+
		"\u014b\u0001\u0000\u0000\u0000\u014c\u014d\u0001\u0000\u0000\u0000\u014d"+
		"\u0013\u0001\u0000\u0000\u0000\u014e\u014f\u0003\u0016\u000b\u0000\u014f"+
		"\u0150\u00052\u0000\u0000\u0150\u0151\u0003\u001a\r\u0000\u0151\u0015"+
		"\u0001\u0000\u0000\u0000\u0152\u0154\u0005D\u0000\u0000\u0153\u0155\u0005"+
		"Z\u0000\u0000\u0154\u0153\u0001\u0000\u0000\u0000\u0154\u0155\u0001\u0000"+
		"\u0000\u0000\u0155\u0158\u0001\u0000\u0000\u0000\u0156\u0158\u0005<\u0000"+
		"\u0000\u0157\u0152\u0001\u0000\u0000\u0000\u0157\u0156\u0001\u0000\u0000"+
		"\u0000\u0157\u0158\u0001\u0000\u0000\u0000\u0158\u0159\u0001\u0000\u0000"+
		"\u0000\u0159\u015a\u0005@\u0000\u0000\u015a\u0017\u0001\u0000\u0000\u0000"+
		"\u015b\u015c\u0005W\u0000\u0000\u015c\u015d\u0003p8\u0000\u015d\u0019"+
		"\u0001\u0000\u0000\u0000\u015e\u016f\u0003\u001c\u000e\u0000\u015f\u016f"+
		"\u0003\u001e\u000f\u0000\u0160\u0161\u0005j\u0000\u0000\u0161\u0162\u0005"+
		"\u0002\u0000\u0000\u0162\u0163\u0003\u001c\u000e\u0000\u0163\u0164\u0005"+
		"\u0014\u0000\u0000\u0164\u0165\u0003\u00f2y\u0000\u0165\u0166\u0005\u0003"+
		"\u0000\u0000\u0166\u016f\u0001\u0000\u0000\u0000\u0167\u0168\u0005j\u0000"+
		"\u0000\u0168\u0169\u0005\u0002\u0000\u0000\u0169\u016a\u0003\u001e\u000f"+
		"\u0000\u016a\u016b\u0005\u0014\u0000\u0000\u016b\u016c\u0003\u00f2y\u0000"+
		"\u016c\u016d\u0005\u0003\u0000\u0000\u016d\u016f\u0001\u0000\u0000\u0000"+
		"\u016e\u015e\u0001\u0000\u0000\u0000\u016e\u015f\u0001\u0000\u0000\u0000"+
		"\u016e\u0160\u0001\u0000\u0000\u0000\u016e\u0167\u0001\u0000\u0000\u0000"+
		"\u016f\u001b\u0001\u0000\u0000\u0000\u0170\u0171\u0003\u00d8l\u0000\u0171"+
		"\u0177\u0005\u0004\u0000\u0000\u0172\u0173\u0003\u00f0x\u0000\u0173\u0174"+
		"\u0005\u0004\u0000\u0000\u0174\u0176\u0001\u0000\u0000\u0000\u0175\u0172"+
		"\u0001\u0000\u0000\u0000\u0176\u0179\u0001\u0000\u0000\u0000\u0177\u0175"+
		"\u0001\u0000\u0000\u0000\u0177\u0178\u0001\u0000\u0000\u0000\u0178\u017a"+
		"\u0001\u0000\u0000\u0000\u0179\u0177\u0001\u0000\u0000\u0000\u017a\u017b"+
		"\u0003\u00f4z\u0000\u017b\u001d\u0001\u0000\u0000\u0000\u017c\u017d\u0003"+
		"\u00d8l\u0000\u017d\u0183\u0005\u0004\u0000\u0000\u017e\u017f\u0003\u00f0"+
		"x\u0000\u017f\u0180\u0005\u0004\u0000\u0000\u0180\u0182\u0001\u0000\u0000"+
		"\u0000\u0181\u017e\u0001\u0000\u0000\u0000\u0182\u0185\u0001\u0000\u0000"+
		"\u0000\u0183\u0181\u0001\u0000\u0000\u0000\u0183\u0184\u0001\u0000\u0000"+
		"\u0000\u0184\u0186\u0001\u0000\u0000\u0000\u0185\u0183\u0001\u0000\u0000"+
		"\u0000\u0186\u0187\u0003\u00f6{\u0000\u0187\u001f\u0001\u0000\u0000\u0000"+
		"\u0188\u0189\u0005:\u0000\u0000\u0189\u018a\u0005\u0002\u0000\u0000\u018a"+
		"\u018b\u00036\u001b\u0000\u018b\u018d\u0005\u0003\u0000\u0000\u018c\u018e"+
		"\u0005\u0014\u0000\u0000\u018d\u018c\u0001\u0000\u0000\u0000\u018d\u018e"+
		"\u0001\u0000\u0000\u0000\u018e\u018f\u0001\u0000\u0000\u0000\u018f\u0190"+
		"\u0003\u00d8l\u0000\u0190!\u0001\u0000\u0000\u0000\u0191\u0198\u0003$"+
		"\u0012\u0000\u0192\u0193\u0005,\u0000\u0000\u0193\u0194\u0005\u0002\u0000"+
		"\u0000\u0194\u0195\u0003\u00d8l\u0000\u0195\u0196\u0005\u0003\u0000\u0000"+
		"\u0196\u0198\u0001\u0000\u0000\u0000\u0197\u0191\u0001\u0000\u0000\u0000"+
		"\u0197\u0192\u0001\u0000\u0000\u0000\u0198#\u0001\u0000\u0000\u0000\u0199"+
		"\u019a\u0005A\u0000\u0000\u019a\u019b\u0005\u0002\u0000\u0000\u019b\u019c"+
		"\u0003\u00d8l\u0000\u019c\u019d\u0005\u0003\u0000\u0000\u019d\u01a4\u0001"+
		"\u0000\u0000\u0000\u019e\u019f\u0005p\u0000\u0000\u019f\u01a0\u0005\u0002"+
		"\u0000\u0000\u01a0\u01a1\u0003\u00d8l\u0000\u01a1\u01a2\u0005\u0003\u0000"+
		"\u0000\u01a2\u01a4\u0001\u0000\u0000\u0000\u01a3\u0199\u0001\u0000\u0000"+
		"\u0000\u01a3\u019e\u0001\u0000\u0000\u0000\u01a4%\u0001\u0000\u0000\u0000"+
		"\u01a5\u01b0\u0003\"\u0011\u0000\u01a6\u01a7\u0005j\u0000\u0000\u01a7"+
		"\u01a8\u0005\u0002\u0000\u0000\u01a8\u01a9\u0003\"\u0011\u0000\u01a9\u01aa"+
		"\u0005\u0014\u0000\u0000\u01aa\u01ab\u0003\u00f2y\u0000\u01ab\u01ac\u0005"+
		"\u0003\u0000\u0000\u01ac\u01b0\u0001\u0000\u0000\u0000\u01ad\u01b0\u0003"+
		"0\u0018\u0000\u01ae\u01b0\u00034\u001a\u0000\u01af\u01a5\u0001\u0000\u0000"+
		"\u0000\u01af\u01a6\u0001\u0000\u0000\u0000\u01af\u01ad\u0001\u0000\u0000"+
		"\u0000\u01af\u01ae\u0001\u0000\u0000\u0000\u01b0\'\u0001\u0000\u0000\u0000"+
		"\u01b1\u01b4\u0003\u00d8l\u0000\u01b2\u01b4\u0003$\u0012\u0000\u01b3\u01b1"+
		"\u0001\u0000\u0000\u0000\u01b3\u01b2\u0001\u0000\u0000\u0000\u01b4)\u0001"+
		"\u0000\u0000\u0000\u01b5\u01bf\u0003,\u0016\u0000\u01b6\u01bb\u0003.\u0017"+
		"\u0000\u01b7\u01b8\u0005\u0004\u0000\u0000\u01b8\u01ba\u0003\u00f6{\u0000"+
		"\u01b9\u01b7\u0001\u0000\u0000\u0000\u01ba\u01bd\u0001\u0000\u0000\u0000"+
		"\u01bb\u01b9\u0001\u0000\u0000\u0000\u01bb\u01bc\u0001\u0000\u0000\u0000"+
		"\u01bc\u01bf\u0001\u0000\u0000\u0000\u01bd\u01bb\u0001\u0000\u0000\u0000"+
		"\u01be\u01b5\u0001\u0000\u0000\u0000\u01be\u01b6\u0001\u0000\u0000\u0000"+
		"\u01bf+\u0001\u0000\u0000\u0000\u01c0\u01ca\u0003(\u0014\u0000\u01c1\u01c6"+
		"\u0003(\u0014\u0000\u01c2\u01c3\u0005\u0004\u0000\u0000\u01c3\u01c5\u0003"+
		"\u00f6{\u0000\u01c4\u01c2\u0001\u0000\u0000\u0000\u01c5\u01c8\u0001\u0000"+
		"\u0000\u0000\u01c6\u01c4\u0001\u0000\u0000\u0000\u01c6\u01c7\u0001\u0000"+
		"\u0000\u0000\u01c7\u01ca\u0001\u0000\u0000\u0000\u01c8\u01c6\u0001\u0000"+
		"\u0000\u0000\u01c9\u01c0\u0001\u0000\u0000\u0000\u01c9\u01c1\u0001\u0000"+
		"\u0000\u0000\u01ca-\u0001\u0000\u0000\u0000\u01cb\u01cc\u0005j\u0000\u0000"+
		"\u01cc\u01cd\u0005\u0002\u0000\u0000\u01cd\u01ce\u0003*\u0015\u0000\u01ce"+
		"\u01cf\u0005\u0014\u0000\u0000\u01cf\u01d0\u0003\u00f2y\u0000\u01d0\u01d1"+
		"\u0005\u0003\u0000\u0000\u01d1/\u0001\u0000\u0000\u0000\u01d2\u01d3\u0003"+
		"*\u0015\u0000\u01d3\u01d4\u0005\u0004\u0000\u0000\u01d4\u01d5\u0003\u00f8"+
		"|\u0000\u01d51\u0001\u0000\u0000\u0000\u01d6\u01d9\u00030\u0018\u0000"+
		"\u01d7\u01d9\u0003(\u0014\u0000\u01d8\u01d6\u0001\u0000\u0000\u0000\u01d8"+
		"\u01d7\u0001\u0000\u0000\u0000\u01d93\u0001\u0000\u0000\u0000\u01da\u01db"+
		"\u0003*\u0015\u0000\u01db\u01dc\u0005\u0004\u0000\u0000\u01dc\u01dd\u0003"+
		"\u00f6{\u0000\u01dd5\u0001\u0000\u0000\u0000\u01de\u01df\u0003*\u0015"+
		"\u0000\u01df\u01e0\u0005\u0004\u0000\u0000\u01e0\u01e1\u0003\u00fa}\u0000"+
		"\u01e17\u0001\u0000\u0000\u0000\u01e2\u01e3\u0005n\u0000\u0000\u01e3\u01e8"+
		"\u0003\u00fc~\u0000\u01e4\u01e6\u0005\u0014\u0000\u0000\u01e5\u01e4\u0001"+
		"\u0000\u0000\u0000\u01e5\u01e6\u0001\u0000\u0000\u0000\u01e6\u01e7\u0001"+
		"\u0000\u0000\u0000\u01e7\u01e9\u0003\u00d8l\u0000\u01e8\u01e5\u0001\u0000"+
		"\u0000\u0000\u01e8\u01e9\u0001\u0000\u0000\u0000\u01e9\u01ea\u0001\u0000"+
		"\u0000\u0000\u01ea\u01eb\u0005_\u0000\u0000\u01eb\u01f0\u0003:\u001d\u0000"+
		"\u01ec\u01ed\u0005\u0001\u0000\u0000\u01ed\u01ef\u0003:\u001d\u0000\u01ee"+
		"\u01ec\u0001\u0000\u0000\u0000\u01ef\u01f2\u0001\u0000\u0000\u0000\u01f0"+
		"\u01ee\u0001\u0000\u0000\u0000\u01f0\u01f1\u0001\u0000\u0000\u0000\u01f1"+
		"9\u0001\u0000\u0000\u0000\u01f2\u01f0\u0001\u0000\u0000\u0000\u01f3\u01f4"+
		"\u0003\u00d8l\u0000\u01f4\u01f5\u0005\u0004\u0000\u0000\u01f5\u01f7\u0001"+
		"\u0000\u0000\u0000\u01f6\u01f3\u0001\u0000\u0000\u0000\u01f6\u01f7\u0001"+
		"\u0000\u0000\u0000\u01f7\u01fd\u0001\u0000\u0000\u0000\u01f8\u01f9\u0003"+
		"\u00f0x\u0000\u01f9\u01fa\u0005\u0004\u0000\u0000\u01fa\u01fc\u0001\u0000"+
		"\u0000\u0000\u01fb\u01f8\u0001\u0000\u0000\u0000\u01fc\u01ff\u0001\u0000"+
		"\u0000\u0000\u01fd\u01fb\u0001\u0000\u0000\u0000\u01fd\u01fe\u0001\u0000"+
		"\u0000\u0000\u01fe\u0202\u0001\u0000\u0000\u0000\u01ff\u01fd\u0001\u0000"+
		"\u0000\u0000\u0200\u0203\u0003\u00f8|\u0000\u0201\u0203\u0003\u00f6{\u0000"+
		"\u0202\u0200\u0001\u0000\u0000\u0000\u0202\u0201\u0001\u0000\u0000\u0000"+
		"\u0203\u0204\u0001\u0000\u0000\u0000\u0204\u0205\u0005s\u0000\u0000\u0205"+
		"\u0206\u0003<\u001e\u0000\u0206;\u0001\u0000\u0000\u0000\u0207\u020b\u0003"+
		"n7\u0000\u0208\u020b\u0003\u00a6S\u0000\u0209\u020b\u0005R\u0000\u0000"+
		"\u020a\u0207\u0001\u0000\u0000\u0000\u020a\u0208\u0001\u0000\u0000\u0000"+
		"\u020a\u0209\u0001\u0000\u0000\u0000\u020b=\u0001\u0000\u0000\u0000\u020c"+
		"\u020d\u0005%\u0000\u0000\u020d\u020e\u00056\u0000\u0000\u020e\u0213\u0003"+
		"\u00fc~\u0000\u020f\u0211\u0005\u0014\u0000\u0000\u0210\u020f\u0001\u0000"+
		"\u0000\u0000\u0210\u0211\u0001\u0000\u0000\u0000\u0211\u0212\u0001\u0000"+
		"\u0000\u0000\u0212\u0214\u0003\u00d8l\u0000\u0213\u0210\u0001\u0000\u0000"+
		"\u0000\u0213\u0214\u0001\u0000\u0000\u0000\u0214?\u0001\u0000\u0000\u0000"+
		"\u0215\u0217\u0005^\u0000\u0000\u0216\u0218\u0005\'\u0000\u0000\u0217"+
		"\u0216\u0001\u0000\u0000\u0000\u0217\u0218\u0001\u0000\u0000\u0000\u0218"+
		"\u0219\u0001\u0000\u0000\u0000\u0219\u021e\u0003B!\u0000\u021a\u021b\u0005"+
		"\u0001\u0000\u0000\u021b\u021d\u0003B!\u0000\u021c\u021a\u0001\u0000\u0000"+
		"\u0000\u021d\u0220\u0001\u0000\u0000\u0000\u021e\u021c\u0001\u0000\u0000"+
		"\u0000\u021e\u021f\u0001\u0000\u0000\u0000\u021fA\u0001\u0000\u0000\u0000"+
		"\u0220\u021e\u0001\u0000\u0000\u0000\u0221\u0226\u0003D\"\u0000\u0222"+
		"\u0224\u0005\u0014\u0000\u0000\u0223\u0222\u0001\u0000\u0000\u0000\u0223"+
		"\u0224\u0001\u0000\u0000\u0000\u0224\u0225\u0001\u0000\u0000\u0000\u0225"+
		"\u0227\u0003\u00fe\u007f\u0000\u0226\u0223\u0001\u0000\u0000\u0000\u0226"+
		"\u0227\u0001\u0000\u0000\u0000\u0227C\u0001\u0000\u0000\u0000\u0228\u0233"+
		"\u0003&\u0013\u0000\u0229\u0233\u0003n7\u0000\u022a\u0233\u0003J%\u0000"+
		"\u022b\u0233\u0003\u00d8l\u0000\u022c\u022d\u0005U\u0000\u0000\u022d\u022e"+
		"\u0005\u0002\u0000\u0000\u022e\u022f\u0003\u00d8l\u0000\u022f\u0230\u0005"+
		"\u0003\u0000\u0000\u0230\u0233\u0001\u0000\u0000\u0000\u0231\u0233\u0003"+
		"F#\u0000\u0232\u0228\u0001\u0000\u0000\u0000\u0232\u0229\u0001\u0000\u0000"+
		"\u0000\u0232\u022a\u0001\u0000\u0000\u0000\u0232\u022b\u0001\u0000\u0000"+
		"\u0000\u0232\u022c\u0001\u0000\u0000\u0000\u0232\u0231\u0001\u0000\u0000"+
		"\u0000\u0233E\u0001\u0000\u0000\u0000\u0234\u0235\u0005P\u0000\u0000\u0235"+
		"\u0236\u0003\u00dam\u0000\u0236\u0237\u0005\u0002\u0000\u0000\u0237\u023c"+
		"\u0003H$\u0000\u0238\u0239\u0005\u0001\u0000\u0000\u0239\u023b\u0003H"+
		"$\u0000\u023a\u0238\u0001\u0000\u0000\u0000\u023b\u023e\u0001\u0000\u0000"+
		"\u0000\u023c\u023a\u0001\u0000\u0000\u0000\u023c\u023d\u0001\u0000\u0000"+
		"\u0000\u023d\u023f\u0001\u0000\u0000\u0000\u023e\u023c\u0001\u0000\u0000"+
		"\u0000\u023f\u0240\u0005\u0003\u0000\u0000\u0240G\u0001\u0000\u0000\u0000"+
		"\u0241\u0247\u0003&\u0013\u0000\u0242\u0247\u0003n7\u0000\u0243\u0247"+
		"\u0003J%\u0000\u0244\u0247\u0003\u00d8l\u0000\u0245\u0247\u0003\u00dc"+
		"n\u0000\u0246\u0241\u0001\u0000\u0000\u0000\u0246\u0242\u0001\u0000\u0000"+
		"\u0000\u0246\u0243\u0001\u0000\u0000\u0000\u0246\u0244\u0001\u0000\u0000"+
		"\u0000\u0246\u0245\u0001\u0000\u0000\u0000\u0247I\u0001\u0000\u0000\u0000"+
		"\u0248\u0249\u0007\u0000\u0000\u0000\u0249\u024b\u0005\u0002\u0000\u0000"+
		"\u024a\u024c\u0005\'\u0000\u0000\u024b\u024a\u0001\u0000\u0000\u0000\u024b"+
		"\u024c\u0001\u0000\u0000\u0000\u024c\u024d\u0001\u0000\u0000\u0000\u024d"+
		"\u024e\u00032\u0019\u0000\u024e\u024f\u0005\u0003\u0000\u0000\u024f\u025e"+
		"\u0001\u0000\u0000\u0000\u0250\u0251\u0005\u001f\u0000\u0000\u0251\u0253"+
		"\u0005\u0002\u0000\u0000\u0252\u0254\u0005\'\u0000\u0000\u0253\u0252\u0001"+
		"\u0000\u0000\u0000\u0253\u0254\u0001\u0000\u0000\u0000\u0254\u0258\u0001"+
		"\u0000\u0000\u0000\u0255\u0259\u0003\u00d8l\u0000\u0256\u0259\u00032\u0019"+
		"\u0000\u0257\u0259\u00034\u001a\u0000\u0258\u0255\u0001\u0000\u0000\u0000"+
		"\u0258\u0256\u0001\u0000\u0000\u0000\u0258\u0257\u0001\u0000\u0000\u0000"+
		"\u0259\u025a\u0001\u0000\u0000\u0000\u025a\u025b\u0005\u0003\u0000\u0000"+
		"\u025b\u025e\u0001\u0000\u0000\u0000\u025c\u025e\u0003\u00ba]\u0000\u025d"+
		"\u0248\u0001\u0000\u0000\u0000\u025d\u0250\u0001\u0000\u0000\u0000\u025d"+
		"\u025c\u0001\u0000\u0000\u0000\u025eK\u0001\u0000\u0000\u0000\u025f\u0260"+
		"\u0005r\u0000\u0000\u0260\u0261\u0003p8\u0000\u0261M\u0001\u0000\u0000"+
		"\u0000\u0262\u0263\u00058\u0000\u0000\u0263\u0264\u0005\u0019\u0000\u0000"+
		"\u0264\u0269\u0003P(\u0000\u0265\u0266\u0005\u0001\u0000\u0000\u0266\u0268"+
		"\u0003P(\u0000\u0267\u0265\u0001\u0000\u0000\u0000\u0268\u026b\u0001\u0000"+
		"\u0000\u0000\u0269\u0267\u0001\u0000\u0000\u0000\u0269\u026a\u0001\u0000"+
		"\u0000\u0000\u026aO\u0001\u0000\u0000\u0000\u026b\u0269\u0001\u0000\u0000"+
		"\u0000\u026c\u026f\u0003&\u0013\u0000\u026d\u026f\u0003\u00d8l\u0000\u026e"+
		"\u026c\u0001\u0000\u0000\u0000\u026e\u026d\u0001\u0000\u0000\u0000\u026f"+
		"Q\u0001\u0000\u0000\u0000\u0270\u0271\u00059\u0000\u0000\u0271\u0272\u0003"+
		"p8\u0000\u0272S\u0001\u0000\u0000\u0000\u0273\u0274\u0005Y\u0000\u0000"+
		"\u0274\u0275\u0005\u0019\u0000\u0000\u0275\u027a\u0003V+\u0000\u0276\u0277"+
		"\u0005\u0001\u0000\u0000\u0277\u0279\u0003V+\u0000\u0278\u0276\u0001\u0000"+
		"\u0000\u0000\u0279\u027c\u0001\u0000\u0000\u0000\u027a\u0278\u0001\u0000"+
		"\u0000\u0000\u027a\u027b\u0001\u0000\u0000\u0000\u027bU\u0001\u0000\u0000"+
		"\u0000\u027c\u027a\u0001\u0000\u0000\u0000\u027d\u0281\u00030\u0018\u0000"+
		"\u027e\u0281\u0003(\u0014\u0000\u027f\u0281\u0003\u00fe\u007f\u0000\u0280"+
		"\u027d\u0001\u0000\u0000\u0000\u0280\u027e\u0001\u0000\u0000\u0000\u0280"+
		"\u027f\u0001\u0000\u0000\u0000\u0281\u0283\u0001\u0000\u0000\u0000\u0282"+
		"\u0284\u0007\u0001\u0000\u0000\u0283\u0282\u0001\u0000\u0000\u0000\u0283"+
		"\u0284\u0001\u0000\u0000\u0000\u0284\u0286\u0001\u0000\u0000\u0000\u0285"+
		"\u0287\u0003X,\u0000\u0286\u0285\u0001\u0000\u0000\u0000\u0286\u0287\u0001"+
		"\u0000\u0000\u0000\u0287W\u0001\u0000\u0000\u0000\u0288\u0289\u0005T\u0000"+
		"\u0000\u0289\u028a\u0007\u0002\u0000\u0000\u028aY\u0001\u0000\u0000\u0000"+
		"\u028b\u028c\u0003j5\u0000\u028c\u028e\u0003\\.\u0000\u028d\u028f\u0003"+
		"L&\u0000\u028e\u028d\u0001\u0000\u0000\u0000\u028e\u028f\u0001\u0000\u0000"+
		"\u0000\u028f\u0291\u0001\u0000\u0000\u0000\u0290\u0292\u0003N\'\u0000"+
		"\u0291\u0290\u0001\u0000\u0000\u0000\u0291\u0292\u0001\u0000\u0000\u0000"+
		"\u0292\u0294\u0001\u0000\u0000\u0000\u0293\u0295\u0003R)\u0000\u0294\u0293"+
		"\u0001\u0000\u0000\u0000\u0294\u0295\u0001\u0000\u0000\u0000\u0295[\u0001"+
		"\u0000\u0000\u0000\u0296\u0297\u00056\u0000\u0000\u0297\u029f\u0003^/"+
		"\u0000\u0298\u029b\u0005\u0001\u0000\u0000\u0299\u029c\u0003^/\u0000\u029a"+
		"\u029c\u0003 \u0010\u0000\u029b\u0299\u0001\u0000\u0000\u0000\u029b\u029a"+
		"\u0001\u0000\u0000\u0000\u029c\u029e\u0001\u0000\u0000\u0000\u029d\u0298"+
		"\u0001\u0000\u0000\u0000\u029e\u02a1\u0001\u0000\u0000\u0000\u029f\u029d"+
		"\u0001\u0000\u0000\u0000\u029f\u02a0\u0001\u0000\u0000\u0000\u02a0]\u0001"+
		"\u0000\u0000\u0000\u02a1\u029f\u0001\u0000\u0000\u0000\u02a2\u02b0\u0003"+
		"\u000e\u0007\u0000\u02a3\u02a5\u0003`0\u0000\u02a4\u02a6\u0005\u0014\u0000"+
		"\u0000\u02a5\u02a4\u0001\u0000\u0000\u0000\u02a5\u02a6\u0001\u0000\u0000"+
		"\u0000\u02a6\u02a7\u0001\u0000\u0000\u0000\u02a7\u02ab\u0003\u00d8l\u0000"+
		"\u02a8\u02aa\u0003\u0012\t\u0000\u02a9\u02a8\u0001\u0000\u0000\u0000\u02aa"+
		"\u02ad\u0001\u0000\u0000\u0000\u02ab\u02a9\u0001\u0000\u0000\u0000\u02ab"+
		"\u02ac\u0001\u0000\u0000\u0000\u02ac\u02b0\u0001\u0000\u0000\u0000\u02ad"+
		"\u02ab\u0001\u0000\u0000\u0000\u02ae\u02b0\u0003h4\u0000\u02af\u02a2\u0001"+
		"\u0000\u0000\u0000\u02af\u02a3\u0001\u0000\u0000\u0000\u02af\u02ae\u0001"+
		"\u0000\u0000\u0000\u02b0_\u0001\u0000\u0000\u0000\u02b1\u02b2\u0003b1"+
		"\u0000\u02b2\u02b3\u0005\u0004\u0000\u0000\u02b3\u02b4\u0003\u00f6{\u0000"+
		"\u02b4\u02ba\u0001\u0000\u0000\u0000\u02b5\u02b6\u0003b1\u0000\u02b6\u02b7"+
		"\u0005\u0004\u0000\u0000\u02b7\u02b8\u0003\u00f4z\u0000\u02b8\u02ba\u0001"+
		"\u0000\u0000\u0000\u02b9\u02b1\u0001\u0000\u0000\u0000\u02b9\u02b5\u0001"+
		"\u0000\u0000\u0000\u02baa\u0001\u0000\u0000\u0000\u02bb\u02c5\u0003d2"+
		"\u0000\u02bc\u02c1\u0003f3\u0000\u02bd\u02be\u0005\u0004\u0000\u0000\u02be"+
		"\u02c0\u0003\u00f6{\u0000\u02bf\u02bd\u0001\u0000\u0000\u0000\u02c0\u02c3"+
		"\u0001\u0000\u0000\u0000\u02c1\u02bf\u0001\u0000\u0000\u0000\u02c1\u02c2"+
		"\u0001\u0000\u0000\u0000\u02c2\u02c5\u0001\u0000\u0000\u0000\u02c3\u02c1"+
		"\u0001\u0000\u0000\u0000\u02c4\u02bb\u0001\u0000\u0000\u0000\u02c4\u02bc"+
		"\u0001\u0000\u0000\u0000\u02c5c\u0001\u0000\u0000\u0000\u02c6\u02cb\u0003"+
		"\u0100\u0080\u0000\u02c7\u02c8\u0005\u0004\u0000\u0000\u02c8\u02ca\u0003"+
		"\u00f6{\u0000\u02c9\u02c7\u0001\u0000\u0000\u0000\u02ca\u02cd\u0001\u0000"+
		"\u0000\u0000\u02cb\u02c9\u0001\u0000\u0000\u0000\u02cb\u02cc\u0001\u0000"+
		"\u0000\u0000\u02cce\u0001\u0000\u0000\u0000\u02cd\u02cb\u0001\u0000\u0000"+
		"\u0000\u02ce\u02cf\u0005j\u0000\u0000\u02cf\u02d0\u0005\u0002\u0000\u0000"+
		"\u02d0\u02d1\u0003b1\u0000\u02d1\u02d2\u0005\u0014\u0000\u0000\u02d2\u02d3"+
		"\u0003\u00f2y\u0000\u02d3\u02d4\u0005\u0003\u0000\u0000\u02d4g\u0001\u0000"+
		"\u0000\u0000\u02d5\u02d6\u0005:\u0000\u0000\u02d6\u02d7\u0003\u0100\u0080"+
		"\u0000\u02d7\u02dd\u0005\u0004\u0000\u0000\u02d8\u02d9\u0003\u00f6{\u0000"+
		"\u02d9\u02da\u0005\u0004\u0000\u0000\u02da\u02dc\u0001\u0000\u0000\u0000"+
		"\u02db\u02d8\u0001\u0000\u0000\u0000\u02dc\u02df\u0001\u0000\u0000\u0000"+
		"\u02dd\u02db\u0001\u0000\u0000\u0000\u02dd\u02de\u0001\u0000\u0000\u0000"+
		"\u02de\u02e0\u0001\u0000\u0000\u0000\u02df\u02dd\u0001\u0000\u0000\u0000"+
		"\u02e0\u02e1\u0003\u00f4z\u0000\u02e1i\u0001\u0000\u0000\u0000\u02e2\u02e4"+
		"\u0005^\u0000\u0000\u02e3\u02e5\u0005\'\u0000\u0000\u02e4\u02e3\u0001"+
		"\u0000\u0000\u0000\u02e4\u02e5\u0001\u0000\u0000\u0000\u02e5\u02e6\u0001"+
		"\u0000\u0000\u0000\u02e6\u02e7\u0003l6\u0000\u02e7k\u0001\u0000\u0000"+
		"\u0000\u02e8\u02ed\u0003&\u0013\u0000\u02e9\u02ed\u0003n7\u0000\u02ea"+
		"\u02ed\u0003J%\u0000\u02eb\u02ed\u0003\u00d8l\u0000\u02ec\u02e8\u0001"+
		"\u0000\u0000\u0000\u02ec\u02e9\u0001\u0000\u0000\u0000\u02ec\u02ea\u0001"+
		"\u0000\u0000\u0000\u02ec\u02eb\u0001\u0000\u0000\u0000\u02edm\u0001\u0000"+
		"\u0000\u0000\u02ee\u02f6\u0003\u0094J\u0000\u02ef\u02f6\u0003\u009cN\u0000"+
		"\u02f0\u02f6\u0003\u00a2Q\u0000\u02f1\u02f6\u0003\u009eO\u0000\u02f2\u02f6"+
		"\u0003\u00a0P\u0000\u02f3\u02f6\u0003\u00c6c\u0000\u02f4\u02f6\u0003\u00a8"+
		"T\u0000\u02f5\u02ee\u0001\u0000\u0000\u0000\u02f5\u02ef\u0001\u0000\u0000"+
		"\u0000\u02f5\u02f0\u0001\u0000\u0000\u0000\u02f5\u02f1\u0001\u0000\u0000"+
		"\u0000\u02f5\u02f2\u0001\u0000\u0000\u0000\u02f5\u02f3\u0001\u0000\u0000"+
		"\u0000\u02f5\u02f4\u0001\u0000\u0000\u0000\u02f6o\u0001\u0000\u0000\u0000"+
		"\u02f7\u02f8\u00068\uffff\uffff\u0000\u02f8\u02f9\u0003r9\u0000\u02f9"+
		"\u02ff\u0001\u0000\u0000\u0000\u02fa\u02fb\n\u0001\u0000\u0000\u02fb\u02fc"+
		"\u0005X\u0000\u0000\u02fc\u02fe\u0003r9\u0000\u02fd\u02fa\u0001\u0000"+
		"\u0000\u0000\u02fe\u0301\u0001\u0000\u0000\u0000\u02ff\u02fd\u0001\u0000"+
		"\u0000\u0000\u02ff\u0300\u0001\u0000\u0000\u0000\u0300q\u0001\u0000\u0000"+
		"\u0000\u0301\u02ff\u0001\u0000\u0000\u0000\u0302\u0303\u00069\uffff\uffff"+
		"\u0000\u0303\u0304\u0003t:\u0000\u0304\u030a\u0001\u0000\u0000\u0000\u0305"+
		"\u0306\n\u0001\u0000\u0000\u0306\u0307\u0005\u0012\u0000\u0000\u0307\u0309"+
		"\u0003t:\u0000\u0308\u0305\u0001\u0000\u0000\u0000\u0309\u030c\u0001\u0000"+
		"\u0000\u0000\u030a\u0308\u0001\u0000\u0000\u0000\u030a\u030b\u0001\u0000"+
		"\u0000\u0000\u030bs\u0001\u0000\u0000\u0000\u030c\u030a\u0001\u0000\u0000"+
		"\u0000\u030d\u030f\u0005Q\u0000\u0000\u030e\u030d\u0001\u0000\u0000\u0000"+
		"\u030e\u030f\u0001\u0000\u0000\u0000\u030f\u0310\u0001\u0000\u0000\u0000"+
		"\u0310\u0311\u0003v;\u0000\u0311u\u0001\u0000\u0000\u0000\u0312\u0318"+
		"\u0003x<\u0000\u0313\u0314\u0005\u0002\u0000\u0000\u0314\u0315\u0003p"+
		"8\u0000\u0315\u0316\u0005\u0003\u0000\u0000\u0316\u0318\u0001\u0000\u0000"+
		"\u0000\u0317\u0312\u0001\u0000\u0000\u0000\u0317\u0313\u0001\u0000\u0000"+
		"\u0000\u0318w\u0001\u0000\u0000\u0000\u0319\u0322\u0003\u0090H\u0000\u031a"+
		"\u0322\u0003z=\u0000\u031b\u0322\u0003|>\u0000\u031c\u0322\u0003\u0080"+
		"@\u0000\u031d\u0322\u0003\u0082A\u0000\u031e\u0322\u0003\u0084B\u0000"+
		"\u031f\u0322\u0003\u0086C\u0000\u0320\u0322\u0003\u008cF\u0000\u0321\u0319"+
		"\u0001\u0000\u0000\u0000\u0321\u031a\u0001\u0000\u0000\u0000\u0321\u031b"+
		"\u0001\u0000\u0000\u0000\u0321\u031c\u0001\u0000\u0000\u0000\u0321\u031d"+
		"\u0001\u0000\u0000\u0000\u0321\u031e\u0001\u0000\u0000\u0000\u0321\u031f"+
		"\u0001\u0000\u0000\u0000\u0321\u0320\u0001\u0000\u0000\u0000\u0322y\u0001"+
		"\u0000\u0000\u0000\u0323\u0325\u0003\u0094J\u0000\u0324\u0326\u0005Q\u0000"+
		"\u0000\u0325\u0324\u0001\u0000\u0000\u0000\u0325\u0326\u0001\u0000\u0000"+
		"\u0000\u0326\u0327\u0001\u0000\u0000\u0000\u0327\u0328\u0005\u0017\u0000"+
		"\u0000\u0328\u0329\u0003\u0094J\u0000\u0329\u032a\u0005\u0012\u0000\u0000"+
		"\u032a\u032b\u0003\u0094J\u0000\u032b\u033f\u0001\u0000\u0000\u0000\u032c"+
		"\u032e\u0003\u009cN\u0000\u032d\u032f\u0005Q\u0000\u0000\u032e\u032d\u0001"+
		"\u0000\u0000\u0000\u032e\u032f\u0001\u0000\u0000\u0000\u032f\u0330\u0001"+
		"\u0000\u0000\u0000\u0330\u0331\u0005\u0017\u0000\u0000\u0331\u0332\u0003"+
		"\u009cN\u0000\u0332\u0333\u0005\u0012\u0000\u0000\u0333\u0334\u0003\u009c"+
		"N\u0000\u0334\u033f\u0001\u0000\u0000\u0000\u0335\u0337\u0003\u009eO\u0000"+
		"\u0336\u0338\u0005Q\u0000\u0000\u0337\u0336\u0001\u0000\u0000\u0000\u0337"+
		"\u0338\u0001\u0000\u0000\u0000\u0338\u0339\u0001\u0000\u0000\u0000\u0339"+
		"\u033a\u0005\u0017\u0000\u0000\u033a\u033b\u0003\u009eO\u0000\u033b\u033c"+
		"\u0005\u0012\u0000\u0000\u033c\u033d\u0003\u009eO\u0000\u033d\u033f\u0001"+
		"\u0000\u0000\u0000\u033e\u0323\u0001\u0000\u0000\u0000\u033e\u032c\u0001"+
		"\u0000\u0000\u0000\u033e\u0335\u0001\u0000\u0000\u0000\u033f{\u0001\u0000"+
		"\u0000\u0000\u0340\u0343\u0003\u009cN\u0000\u0341\u0343\u0003\u00aaU\u0000"+
		"\u0342\u0340\u0001\u0000\u0000\u0000\u0342\u0341\u0001\u0000\u0000\u0000"+
		"\u0343\u0345\u0001\u0000\u0000\u0000\u0344\u0346\u0005Q\u0000\u0000\u0345"+
		"\u0344\u0001\u0000\u0000\u0000\u0345\u0346\u0001\u0000\u0000\u0000\u0346"+
		"\u0347\u0001\u0000\u0000\u0000\u0347\u0358\u0005:\u0000\u0000\u0348\u0349"+
		"\u0005\u0002\u0000\u0000\u0349\u034e\u0003~?\u0000\u034a\u034b\u0005\u0001"+
		"\u0000\u0000\u034b\u034d\u0003~?\u0000\u034c\u034a\u0001\u0000\u0000\u0000"+
		"\u034d\u0350\u0001\u0000\u0000\u0000\u034e\u034c\u0001\u0000\u0000\u0000"+
		"\u034e\u034f\u0001\u0000\u0000\u0000\u034f\u0351\u0001\u0000\u0000\u0000"+
		"\u0350\u034e\u0001\u0000\u0000\u0000\u0351\u0352\u0005\u0003\u0000\u0000"+
		"\u0352\u0359\u0001\u0000\u0000\u0000\u0353\u0354\u0005\u0002\u0000\u0000"+
		"\u0354\u0355\u0003Z-\u0000\u0355\u0356\u0005\u0003\u0000\u0000\u0356\u0359"+
		"\u0001\u0000\u0000\u0000\u0357\u0359\u0003\u0102\u0081\u0000\u0358\u0348"+
		"\u0001\u0000\u0000\u0000\u0358\u0353\u0001\u0000\u0000\u0000\u0358\u0357"+
		"\u0001\u0000\u0000\u0000\u0359}\u0001\u0000\u0000\u0000\u035a\u0362\u0003"+
		"\u00dcn\u0000\u035b\u0362\u0003\u009cN\u0000\u035c\u0362\u0003\u00eau"+
		"\u0000\u035d\u0362\u0003\u00e8t\u0000\u035e\u0362\u0003\u00e2q\u0000\u035f"+
		"\u0362\u0003\u0104\u0082\u0000\u0360\u0362\u0003p8\u0000\u0361\u035a\u0001"+
		"\u0000\u0000\u0000\u0361\u035b\u0001\u0000\u0000\u0000\u0361\u035c\u0001"+
		"\u0000\u0000\u0000\u0361\u035d\u0001\u0000\u0000\u0000\u0361\u035e\u0001"+
		"\u0000\u0000\u0000\u0361\u035f\u0001\u0000\u0000\u0000\u0361\u0360\u0001"+
		"\u0000\u0000\u0000\u0362\u007f\u0001\u0000\u0000\u0000\u0363\u0365\u0003"+
		"\u009cN\u0000\u0364\u0366\u0005Q\u0000\u0000\u0365\u0364\u0001\u0000\u0000"+
		"\u0000\u0365\u0366\u0001\u0000\u0000\u0000\u0366\u0367\u0001\u0000\u0000"+
		"\u0000\u0367\u0368\u0005F\u0000\u0000\u0368\u036b\u0003\u00e0p\u0000\u0369"+
		"\u036a\u0005-\u0000\u0000\u036a\u036c\u0003\u00e6s\u0000\u036b\u0369\u0001"+
		"\u0000\u0000\u0000\u036b\u036c\u0001\u0000\u0000\u0000\u036c\u0081\u0001"+
		"\u0000\u0000\u0000\u036d\u0370\u0003&\u0013\u0000\u036e\u0370\u0003\u00de"+
		"o\u0000\u036f\u036d\u0001\u0000\u0000\u0000\u036f\u036e\u0001\u0000\u0000"+
		"\u0000\u0370\u0371\u0001\u0000\u0000\u0000\u0371\u0373\u0005>\u0000\u0000"+
		"\u0372\u0374\u0005Q\u0000\u0000\u0373\u0372\u0001\u0000\u0000\u0000\u0373"+
		"\u0374\u0001\u0000\u0000\u0000\u0374\u0375\u0001\u0000\u0000\u0000\u0375"+
		"\u0376\u0005R\u0000\u0000\u0376\u0083\u0001\u0000\u0000\u0000\u0377\u0378"+
		"\u00036\u001b\u0000\u0378\u037a\u0005>\u0000\u0000\u0379\u037b\u0005Q"+
		"\u0000\u0000\u037a\u0379\u0001\u0000\u0000\u0000\u037a\u037b\u0001\u0000"+
		"\u0000\u0000\u037b\u037c\u0001\u0000\u0000\u0000\u037c\u037d\u0005+\u0000"+
		"\u0000\u037d\u0085\u0001\u0000\u0000\u0000\u037e\u0380\u0003\u0088D\u0000"+
		"\u037f\u0381\u0005Q\u0000\u0000\u0380\u037f\u0001\u0000\u0000\u0000\u0380"+
		"\u0381\u0001\u0000\u0000\u0000\u0381\u0382\u0001\u0000\u0000\u0000\u0382"+
		"\u0384\u0005M\u0000\u0000\u0383\u0385\u0005V\u0000\u0000\u0384\u0383\u0001"+
		"\u0000\u0000\u0000\u0384\u0385\u0001\u0000\u0000\u0000\u0385\u0386\u0001"+
		"\u0000\u0000\u0000\u0386\u0387\u00036\u001b\u0000\u0387\u0087\u0001\u0000"+
		"\u0000\u0000\u0388\u038c\u00034\u001a\u0000\u0389\u038c\u00030\u0018\u0000"+
		"\u038a\u038c\u0003\u008aE\u0000\u038b\u0388\u0001\u0000\u0000\u0000\u038b"+
		"\u0389\u0001\u0000\u0000\u0000\u038b\u038a\u0001\u0000\u0000\u0000\u038c"+
		"\u0089\u0001\u0000\u0000\u0000\u038d\u0391\u0003\u00d8l\u0000\u038e\u0391"+
		"\u0003\u00deo\u0000\u038f\u0391\u0003\u00dcn\u0000\u0390\u038d\u0001\u0000"+
		"\u0000\u0000\u0390\u038e\u0001\u0000\u0000\u0000\u0390\u038f\u0001\u0000"+
		"\u0000\u0000\u0391\u008b\u0001\u0000\u0000\u0000\u0392\u0394\u0005Q\u0000"+
		"\u0000\u0393\u0392\u0001\u0000\u0000\u0000\u0393\u0394\u0001\u0000\u0000"+
		"\u0000\u0394\u0395\u0001\u0000\u0000\u0000\u0395\u0396\u0005.\u0000\u0000"+
		"\u0396\u0397\u0005\u0002\u0000\u0000\u0397\u0398\u0003Z-\u0000\u0398\u0399"+
		"\u0005\u0003\u0000\u0000\u0399\u008d\u0001\u0000\u0000\u0000\u039a\u039b"+
		"\u0007\u0003\u0000\u0000\u039b\u039c\u0005\u0002\u0000\u0000\u039c\u039d"+
		"\u0003Z-\u0000\u039d\u039e\u0005\u0003\u0000\u0000\u039e\u008f\u0001\u0000"+
		"\u0000\u0000\u039f\u03a0\u0003\u009cN\u0000\u03a0\u03a3\u0003\u0092I\u0000"+
		"\u03a1\u03a4\u0003\u009cN\u0000\u03a2\u03a4\u0003\u008eG\u0000\u03a3\u03a1"+
		"\u0001\u0000\u0000\u0000\u03a3\u03a2\u0001\u0000\u0000\u0000\u03a4\u03cd"+
		"\u0001\u0000\u0000\u0000\u03a5\u03a6\u0003\u00a0P\u0000\u03a6\u03a9\u0007"+
		"\u0004\u0000\u0000\u03a7\u03aa\u0003\u00a0P\u0000\u03a8\u03aa\u0003\u008e"+
		"G\u0000\u03a9\u03a7\u0001\u0000\u0000\u0000\u03a9\u03a8\u0001\u0000\u0000"+
		"\u0000\u03aa\u03cd\u0001\u0000\u0000\u0000\u03ab\u03cd\u0003\u00a0P\u0000"+
		"\u03ac\u03ad\u0003\u00a2Q\u0000\u03ad\u03b0\u0007\u0004\u0000\u0000\u03ae"+
		"\u03b1\u0003\u00a2Q\u0000\u03af\u03b1\u0003\u008eG\u0000\u03b0\u03ae\u0001"+
		"\u0000\u0000\u0000\u03b0\u03af\u0001\u0000\u0000\u0000\u03b1\u03cd\u0001"+
		"\u0000\u0000\u0000\u03b2\u03b3\u0003\u009eO\u0000\u03b3\u03b6\u0003\u0092"+
		"I\u0000\u03b4\u03b7\u0003\u009eO\u0000\u03b5\u03b7\u0003\u008eG\u0000"+
		"\u03b6\u03b4\u0001\u0000\u0000\u0000\u03b6\u03b5\u0001\u0000\u0000\u0000"+
		"\u03b7\u03cd\u0001\u0000\u0000\u0000\u03b8\u03b9\u0003\u00a4R\u0000\u03b9"+
		"\u03bc\u0007\u0004\u0000\u0000\u03ba\u03bd\u0003\u00a4R\u0000\u03bb\u03bd"+
		"\u0003\u008eG\u0000\u03bc\u03ba\u0001\u0000\u0000\u0000\u03bc\u03bb\u0001"+
		"\u0000\u0000\u0000\u03bd\u03cd\u0001\u0000\u0000\u0000\u03be\u03bf\u0003"+
		"\u0094J\u0000\u03bf\u03c2\u0003\u0092I\u0000\u03c0\u03c3\u0003\u0094J"+
		"\u0000\u03c1\u03c3\u0003\u008eG\u0000\u03c2\u03c0\u0001\u0000\u0000\u0000"+
		"\u03c2\u03c1\u0001\u0000\u0000\u0000\u03c3\u03cd\u0001\u0000\u0000\u0000"+
		"\u03c4\u03c5\u0003\u00a8T\u0000\u03c5\u03c6\u0007\u0004\u0000\u0000\u03c6"+
		"\u03c7\u0003\u00a8T\u0000\u03c7\u03cd\u0001\u0000\u0000\u0000\u03c8\u03c9"+
		"\u0003\u009cN\u0000\u03c9\u03ca\u0005\\\u0000\u0000\u03ca\u03cb\u0003"+
		"\u00eew\u0000\u03cb\u03cd\u0001\u0000\u0000\u0000\u03cc\u039f\u0001\u0000"+
		"\u0000\u0000\u03cc\u03a5\u0001\u0000\u0000\u0000\u03cc\u03ab\u0001\u0000"+
		"\u0000\u0000\u03cc\u03ac\u0001\u0000\u0000\u0000\u03cc\u03b2\u0001\u0000"+
		"\u0000\u0000\u03cc\u03b8\u0001\u0000\u0000\u0000\u03cc\u03be\u0001\u0000"+
		"\u0000\u0000\u03cc\u03c4\u0001\u0000\u0000\u0000\u03cc\u03c8\u0001\u0000"+
		"\u0000\u0000\u03cd\u0091\u0001\u0000\u0000\u0000\u03ce\u03d5\u0005s\u0000"+
		"\u0000\u03cf\u03d5\u0005\u0005\u0000\u0000\u03d0\u03d5\u0005\u0006\u0000"+
		"\u0000\u03d1\u03d5\u0005\u0007\u0000\u0000\u03d2\u03d5\u0005\b\u0000\u0000"+
		"\u03d3\u03d5\u0005t\u0000\u0000\u03d4\u03ce\u0001\u0000\u0000\u0000\u03d4"+
		"\u03cf\u0001\u0000\u0000\u0000\u03d4\u03d0\u0001\u0000\u0000\u0000\u03d4"+
		"\u03d1\u0001\u0000\u0000\u0000\u03d4\u03d2\u0001\u0000\u0000\u0000\u03d4"+
		"\u03d3\u0001\u0000\u0000\u0000\u03d5\u0093\u0001\u0000\u0000\u0000\u03d6"+
		"\u03d7\u0006J\uffff\uffff\u0000\u03d7\u03d8\u0003\u0096K\u0000\u03d8\u03de"+
		"\u0001\u0000\u0000\u0000\u03d9\u03da\n\u0001\u0000\u0000\u03da\u03db\u0007"+
		"\u0005\u0000\u0000\u03db\u03dd\u0003\u0096K\u0000\u03dc\u03d9\u0001\u0000"+
		"\u0000\u0000\u03dd\u03e0\u0001\u0000\u0000\u0000\u03de\u03dc\u0001\u0000"+
		"\u0000\u0000\u03de\u03df\u0001\u0000\u0000\u0000\u03df\u0095\u0001\u0000"+
		"\u0000\u0000\u03e0\u03de\u0001\u0000\u0000\u0000\u03e1\u03e2\u0006K\uffff"+
		"\uffff\u0000\u03e2\u03e3\u0003\u0098L\u0000\u03e3\u03e9\u0001\u0000\u0000"+
		"\u0000\u03e4\u03e5\n\u0001\u0000\u0000\u03e5\u03e6\u0007\u0006\u0000\u0000"+
		"\u03e6\u03e8\u0003\u0098L\u0000\u03e7\u03e4\u0001\u0000\u0000\u0000\u03e8"+
		"\u03eb\u0001\u0000\u0000\u0000\u03e9\u03e7\u0001\u0000\u0000\u0000\u03e9"+
		"\u03ea\u0001\u0000\u0000\u0000\u03ea\u0097\u0001\u0000\u0000\u0000\u03eb"+
		"\u03e9\u0001\u0000\u0000\u0000\u03ec\u03ee\u0007\u0005\u0000\u0000\u03ed"+
		"\u03ec\u0001\u0000\u0000\u0000\u03ed\u03ee\u0001\u0000\u0000\u0000\u03ee"+
		"\u03ef\u0001\u0000\u0000\u0000\u03ef\u03f0\u0003\u009aM\u0000\u03f0\u0099"+
		"\u0001\u0000\u0000\u0000\u03f1\u0403\u00032\u0019\u0000\u03f2\u0403\u0003"+
		"\u00e8t\u0000\u03f3\u03f4\u0005\u0002\u0000\u0000\u03f4\u03f5\u0003\u0094"+
		"J\u0000\u03f5\u03f6\u0005\u0003\u0000\u0000\u03f6\u0403\u0001\u0000\u0000"+
		"\u0000\u03f7\u0403\u0003\u00deo\u0000\u03f8\u0403\u0003\u00acV\u0000\u03f9"+
		"\u0403\u0003J%\u0000\u03fa\u0403\u0003\u00c6c\u0000\u03fb\u0403\u0003"+
		"\u00b4Z\u0000\u03fc\u0403\u0003\u00b6[\u0000\u03fd\u0403\u0003\u00ba]"+
		"\u0000\u03fe\u03ff\u0005\u0002\u0000\u0000\u03ff\u0400\u0003Z-\u0000\u0400"+
		"\u0401\u0005\u0003\u0000\u0000\u0401\u0403\u0001\u0000\u0000\u0000\u0402"+
		"\u03f1\u0001\u0000\u0000\u0000\u0402\u03f2\u0001\u0000\u0000\u0000\u0402"+
		"\u03f3\u0001\u0000\u0000\u0000\u0402\u03f7\u0001\u0000\u0000\u0000\u0402"+
		"\u03f8\u0001\u0000\u0000\u0000\u0402\u03f9\u0001\u0000\u0000\u0000\u0402"+
		"\u03fa\u0001\u0000\u0000\u0000\u0402\u03fb\u0001\u0000\u0000\u0000\u0402"+
		"\u03fc\u0001\u0000\u0000\u0000\u0402\u03fd\u0001\u0000\u0000\u0000\u0402"+
		"\u03fe\u0001\u0000\u0000\u0000\u0403\u009b\u0001\u0000\u0000\u0000\u0404"+
		"\u0412\u00032\u0019\u0000\u0405\u0412\u0003\u00eew\u0000\u0406\u0412\u0003"+
		"\u00deo\u0000\u0407\u0412\u0003\u00b0X\u0000\u0408\u0412\u0003J%\u0000"+
		"\u0409\u0412\u0003\u00c6c\u0000\u040a\u0412\u0003\u00ba]\u0000\u040b\u0412"+
		"\u0003\u00b8\\\u0000\u040c\u0412\u0003\u00b6[\u0000\u040d\u040e\u0005"+
		"\u0002\u0000\u0000\u040e\u040f\u0003Z-\u0000\u040f\u0410\u0005\u0003\u0000"+
		"\u0000\u0410\u0412\u0001\u0000\u0000\u0000\u0411\u0404\u0001\u0000\u0000"+
		"\u0000\u0411\u0405\u0001\u0000\u0000\u0000\u0411\u0406\u0001\u0000\u0000"+
		"\u0000\u0411\u0407\u0001\u0000\u0000\u0000\u0411\u0408\u0001\u0000\u0000"+
		"\u0000\u0411\u0409\u0001\u0000\u0000\u0000\u0411\u040a\u0001\u0000\u0000"+
		"\u0000\u0411\u040b\u0001\u0000\u0000\u0000\u0411\u040c\u0001\u0000\u0000"+
		"\u0000\u0411\u040d\u0001\u0000\u0000\u0000\u0412\u009d\u0001\u0000\u0000"+
		"\u0000\u0413\u041f\u00032\u0019\u0000\u0414\u041f\u0003\u00deo\u0000\u0415"+
		"\u041f\u0003\u00aeW\u0000\u0416\u041f\u0003J%\u0000\u0417\u041f\u0003"+
		"\u00c6c\u0000\u0418\u041f\u0003\u00ba]\u0000\u0419\u041f\u0003\u00e2q"+
		"\u0000\u041a\u041b\u0005\u0002\u0000\u0000\u041b\u041c\u0003Z-\u0000\u041c"+
		"\u041d\u0005\u0003\u0000\u0000\u041d\u041f\u0001\u0000\u0000\u0000\u041e"+
		"\u0413\u0001\u0000\u0000\u0000\u041e\u0414\u0001\u0000\u0000\u0000\u041e"+
		"\u0415\u0001\u0000\u0000\u0000\u041e\u0416\u0001\u0000\u0000\u0000\u041e"+
		"\u0417\u0001\u0000\u0000\u0000\u041e\u0418\u0001\u0000\u0000\u0000\u041e"+
		"\u0419\u0001\u0000\u0000\u0000\u041e\u041a\u0001\u0000\u0000\u0000\u041f"+
		"\u009f\u0001\u0000\u0000\u0000\u0420\u042a\u00032\u0019\u0000\u0421\u042a"+
		"\u0003\u00eau\u0000\u0422\u042a\u0003\u00deo\u0000\u0423\u042a\u0003\u00c6"+
		"c\u0000\u0424\u042a\u0003\u00ba]\u0000\u0425\u0426\u0005\u0002\u0000\u0000"+
		"\u0426\u0427\u0003Z-\u0000\u0427\u0428\u0005\u0003\u0000\u0000\u0428\u042a"+
		"\u0001\u0000\u0000\u0000\u0429\u0420\u0001\u0000\u0000\u0000\u0429\u0421"+
		"\u0001\u0000\u0000\u0000\u0429\u0422\u0001\u0000\u0000\u0000\u0429\u0423"+
		"\u0001\u0000\u0000\u0000\u0429\u0424\u0001\u0000\u0000\u0000\u0429\u0425"+
		"\u0001\u0000\u0000\u0000\u042a\u00a1\u0001\u0000\u0000\u0000\u042b\u0434"+
		"\u00032\u0019\u0000\u042c\u0434\u0003\u00ecv\u0000\u042d\u0434\u0003\u00de"+
		"o\u0000\u042e\u0434\u0003\u00c6c\u0000\u042f\u0430\u0005\u0002\u0000\u0000"+
		"\u0430\u0431\u0003Z-\u0000\u0431\u0432\u0005\u0003\u0000\u0000\u0432\u0434"+
		"\u0001\u0000\u0000\u0000\u0433\u042b\u0001\u0000\u0000\u0000\u0433\u042c"+
		"\u0001\u0000\u0000\u0000\u0433\u042d\u0001\u0000\u0000\u0000\u0433\u042e"+
		"\u0001\u0000\u0000\u0000\u0433\u042f\u0001\u0000\u0000\u0000\u0434\u00a3"+
		"\u0001\u0000\u0000\u0000\u0435\u0438\u00034\u001a\u0000\u0436\u0438\u0003"+
		"\u00a6S\u0000\u0437\u0435\u0001\u0000\u0000\u0000\u0437\u0436\u0001\u0000"+
		"\u0000\u0000\u0438\u00a5\u0001\u0000\u0000\u0000\u0439\u043c\u0003\u00d8"+
		"l\u0000\u043a\u043c\u0003\u00deo\u0000\u043b\u0439\u0001\u0000\u0000\u0000"+
		"\u043b\u043a\u0001\u0000\u0000\u0000\u043c\u00a7\u0001\u0000\u0000\u0000"+
		"\u043d\u0441\u0003\u00aaU\u0000\u043e\u0441\u0003\u00e4r\u0000\u043f\u0441"+
		"\u0003\u00deo\u0000\u0440\u043d\u0001\u0000\u0000\u0000\u0440\u043e\u0001"+
		"\u0000\u0000\u0000\u0440\u043f\u0001\u0000\u0000\u0000\u0441\u00a9\u0001"+
		"\u0000\u0000\u0000\u0442\u0443\u0005m\u0000\u0000\u0443\u0447\u0005\u0002"+
		"\u0000\u0000\u0444\u0448\u0003(\u0014\u0000\u0445\u0448\u00034\u001a\u0000"+
		"\u0446\u0448\u0003\u00deo\u0000\u0447\u0444\u0001\u0000\u0000\u0000\u0447"+
		"\u0445\u0001\u0000\u0000\u0000\u0447\u0446\u0001\u0000\u0000\u0000\u0448"+
		"\u0449\u0001\u0000\u0000\u0000\u0449\u044a\u0005\u0003\u0000\u0000\u044a"+
		"\u00ab\u0001\u0000\u0000\u0000\u044b\u044c\u0005E\u0000\u0000\u044c\u044d"+
		"\u0005\u0002\u0000\u0000\u044d\u044e\u0003\u009cN\u0000\u044e\u044f\u0005"+
		"\u0003\u0000\u0000\u044f\u049f\u0001\u0000\u0000\u0000\u0450\u0451\u0005"+
		"I\u0000\u0000\u0451\u0452\u0005\u0002\u0000\u0000\u0452\u0453\u0003\u009c"+
		"N\u0000\u0453\u0454\u0005\u0001\u0000\u0000\u0454\u0457\u0003\u009cN\u0000"+
		"\u0455\u0456\u0005\u0001\u0000\u0000\u0456\u0458\u0003\u0094J\u0000\u0457"+
		"\u0455\u0001\u0000\u0000\u0000\u0457\u0458\u0001\u0000\u0000\u0000\u0458"+
		"\u0459\u0001\u0000\u0000\u0000\u0459\u045a\u0005\u0003\u0000\u0000\u045a"+
		"\u049f\u0001\u0000\u0000\u0000\u045b\u045c\u0005\u0010\u0000\u0000\u045c"+
		"\u045d\u0005\u0002\u0000\u0000\u045d\u045e\u0003\u0094J\u0000\u045e\u045f"+
		"\u0005\u0003\u0000\u0000\u045f\u049f\u0001\u0000\u0000\u0000\u0460\u0461"+
		"\u0005\u001c\u0000\u0000\u0461\u0462\u0005\u0002\u0000\u0000\u0462\u0463"+
		"\u0003\u0094J\u0000\u0463\u0464\u0005\u0003\u0000\u0000\u0464\u049f\u0001"+
		"\u0000\u0000\u0000\u0465\u0466\u0005/\u0000\u0000\u0466\u0467\u0005\u0002"+
		"\u0000\u0000\u0467\u0468\u0003\u0094J\u0000\u0468\u0469\u0005\u0003\u0000"+
		"\u0000\u0469\u049f\u0001\u0000\u0000\u0000\u046a\u046b\u00054\u0000\u0000"+
		"\u046b\u046c\u0005\u0002\u0000\u0000\u046c\u046d\u0003\u0094J\u0000\u046d"+
		"\u046e\u0005\u0003\u0000\u0000\u046e\u049f\u0001\u0000\u0000\u0000\u046f"+
		"\u0470\u0005G\u0000\u0000\u0470\u0471\u0005\u0002\u0000\u0000\u0471\u0472"+
		"\u0003\u0094J\u0000\u0472\u0473\u0005\u0003\u0000\u0000\u0473\u049f\u0001"+
		"\u0000\u0000\u0000\u0474\u0475\u0005`\u0000\u0000\u0475\u0476\u0005\u0002"+
		"\u0000\u0000\u0476\u0477\u0003\u0094J\u0000\u0477\u0478\u0005\u0003\u0000"+
		"\u0000\u0478\u049f\u0001\u0000\u0000\u0000\u0479\u047a\u0005c\u0000\u0000"+
		"\u047a\u047b\u0005\u0002\u0000\u0000\u047b\u047c\u0003\u0094J\u0000\u047c"+
		"\u047d\u0005\u0003\u0000\u0000\u047d\u049f\u0001\u0000\u0000\u0000\u047e"+
		"\u047f\u0005O\u0000\u0000\u047f\u0480\u0005\u0002\u0000\u0000\u0480\u0481"+
		"\u0003\u0094J\u0000\u0481\u0482\u0005\u0001\u0000\u0000\u0482\u0483\u0003"+
		"\u0094J\u0000\u0483\u0484\u0005\u0003\u0000\u0000\u0484\u049f\u0001\u0000"+
		"\u0000\u0000\u0485\u0486\u0005[\u0000\u0000\u0486\u0487\u0005\u0002\u0000"+
		"\u0000\u0487\u0488\u0003\u0094J\u0000\u0488\u0489\u0005\u0001\u0000\u0000"+
		"\u0489\u048a\u0003\u0094J\u0000\u048a\u048b\u0005\u0003\u0000\u0000\u048b"+
		"\u049f\u0001\u0000\u0000\u0000\u048c\u048d\u0005]\u0000\u0000\u048d\u048e"+
		"\u0005\u0002\u0000\u0000\u048e\u048f\u0003\u0094J\u0000\u048f\u0490\u0005"+
		"\u0001\u0000\u0000\u0490\u0491\u0003\u0094J\u0000\u0491\u0492\u0005\u0003"+
		"\u0000\u0000\u0492\u049f\u0001\u0000\u0000\u0000\u0493\u0494\u0005a\u0000"+
		"\u0000\u0494\u0495\u0005\u0002\u0000\u0000\u0495\u0496\u00036\u001b\u0000"+
		"\u0496\u0497\u0005\u0003\u0000\u0000\u0497\u049f\u0001\u0000\u0000\u0000"+
		"\u0498\u0499\u0005;\u0000\u0000\u0499\u049a\u0005\u0002\u0000\u0000\u049a"+
		"\u049b\u0003\u00d8l\u0000\u049b\u049c\u0005\u0003\u0000\u0000\u049c\u049f"+
		"\u0001\u0000\u0000\u0000\u049d\u049f\u0003\u00bc^\u0000\u049e\u044b\u0001"+
		"\u0000\u0000\u0000\u049e\u0450\u0001\u0000\u0000\u0000\u049e\u045b\u0001"+
		"\u0000\u0000\u0000\u049e\u0460\u0001\u0000\u0000\u0000\u049e\u0465\u0001"+
		"\u0000\u0000\u0000\u049e\u046a\u0001\u0000\u0000\u0000\u049e\u046f\u0001"+
		"\u0000\u0000\u0000\u049e\u0474\u0001\u0000\u0000\u0000\u049e\u0479\u0001"+
		"\u0000\u0000\u0000\u049e\u047e\u0001\u0000\u0000\u0000\u049e\u0485\u0001"+
		"\u0000\u0000\u0000\u049e\u048c\u0001\u0000\u0000\u0000\u049e\u0493\u0001"+
		"\u0000\u0000\u0000\u049e\u0498\u0001\u0000\u0000\u0000\u049e\u049d\u0001"+
		"\u0000\u0000\u0000\u049f\u00ad\u0001\u0000\u0000\u0000\u04a0\u04ab\u0005"+
		" \u0000\u0000\u04a1\u04ab\u0005!\u0000\u0000\u04a2\u04ab\u0005\"\u0000"+
		"\u0000\u04a3\u04a4\u0005H\u0000\u0000\u04a4\u04ab\u0005#\u0000\u0000\u04a5"+
		"\u04a6\u0005H\u0000\u0000\u04a6\u04ab\u0005h\u0000\u0000\u04a7\u04a8\u0005"+
		"H\u0000\u0000\u04a8\u04ab\u0005$\u0000\u0000\u04a9\u04ab\u0003\u00c0`"+
		"\u0000\u04aa\u04a0\u0001\u0000\u0000\u0000\u04aa\u04a1\u0001\u0000\u0000"+
		"\u0000\u04aa\u04a2\u0001\u0000\u0000\u0000\u04aa\u04a3\u0001\u0000\u0000"+
		"\u0000\u04aa\u04a5\u0001\u0000\u0000\u0000\u04aa\u04a7\u0001\u0000\u0000"+
		"\u0000\u04aa\u04a9\u0001\u0000\u0000\u0000\u04ab\u00af\u0001\u0000\u0000"+
		"\u0000\u04ac\u04ad\u0005\u001e\u0000\u0000\u04ad\u04ae\u0005\u0002\u0000"+
		"\u0000\u04ae\u04af\u0003\u009cN\u0000\u04af\u04b0\u0005\u0001\u0000\u0000"+
		"\u04b0\u04b5\u0003\u009cN\u0000\u04b1\u04b2\u0005\u0001\u0000\u0000\u04b2"+
		"\u04b4\u0003\u009cN\u0000\u04b3\u04b1\u0001\u0000\u0000\u0000\u04b4\u04b7"+
		"\u0001\u0000\u0000\u0000\u04b5\u04b3\u0001\u0000\u0000\u0000\u04b5\u04b6"+
		"\u0001\u0000\u0000\u0000\u04b6\u04b8\u0001\u0000\u0000\u0000\u04b7\u04b5"+
		"\u0001\u0000\u0000\u0000\u04b8\u04b9\u0005\u0003\u0000\u0000\u04b9\u04de"+
		"\u0001\u0000\u0000\u0000\u04ba\u04bb\u0005d\u0000\u0000\u04bb\u04bc\u0005"+
		"\u0002\u0000\u0000\u04bc\u04bd\u0003\u009cN\u0000\u04bd\u04be\u0005\u0001"+
		"\u0000\u0000\u04be\u04c1\u0003\u0094J\u0000\u04bf\u04c0\u0005\u0001\u0000"+
		"\u0000\u04c0\u04c2\u0003\u0094J\u0000\u04c1\u04bf\u0001\u0000\u0000\u0000"+
		"\u04c1\u04c2\u0001\u0000\u0000\u0000\u04c2\u04c3\u0001\u0000\u0000\u0000"+
		"\u04c3\u04c4\u0005\u0003\u0000\u0000\u04c4\u04de\u0001\u0000\u0000\u0000"+
		"\u04c5\u04c6\u0005k\u0000\u0000\u04c6\u04ce\u0005\u0002\u0000\u0000\u04c7"+
		"\u04c9\u0003\u00b2Y\u0000\u04c8\u04c7\u0001\u0000\u0000\u0000\u04c8\u04c9"+
		"\u0001\u0000\u0000\u0000\u04c9\u04cb\u0001\u0000\u0000\u0000\u04ca\u04cc"+
		"\u0003\u00d6k\u0000\u04cb\u04ca\u0001\u0000\u0000\u0000\u04cb\u04cc\u0001"+
		"\u0000\u0000\u0000\u04cc\u04cd\u0001\u0000\u0000\u0000\u04cd\u04cf\u0005"+
		"6\u0000\u0000\u04ce\u04c8\u0001\u0000\u0000\u0000\u04ce\u04cf\u0001\u0000"+
		"\u0000\u0000\u04cf\u04d0\u0001\u0000\u0000\u0000\u04d0\u04d1\u0003\u009c"+
		"N\u0000\u04d1\u04d2\u0005\u0003\u0000\u0000\u04d2\u04de\u0001\u0000\u0000"+
		"\u0000\u04d3\u04d4\u0005K\u0000\u0000\u04d4\u04d5\u0005\u0002\u0000\u0000"+
		"\u04d5\u04d6\u0003\u009cN\u0000\u04d6\u04d7\u0005\u0003\u0000\u0000\u04d7"+
		"\u04de\u0001\u0000\u0000\u0000\u04d8\u04d9\u0005o\u0000\u0000\u04d9\u04da"+
		"\u0005\u0002\u0000\u0000\u04da\u04db\u0003\u009cN\u0000\u04db\u04dc\u0005"+
		"\u0003\u0000\u0000\u04dc\u04de\u0001\u0000\u0000\u0000\u04dd\u04ac\u0001"+
		"\u0000\u0000\u0000\u04dd\u04ba\u0001\u0000\u0000\u0000\u04dd\u04c5\u0001"+
		"\u0000\u0000\u0000\u04dd\u04d3\u0001\u0000\u0000\u0000\u04dd\u04d8\u0001"+
		"\u0000\u0000\u0000\u04de\u00b1\u0001\u0000\u0000\u0000\u04df\u04e0\u0007"+
		"\u0007\u0000\u0000\u04e0\u00b3\u0001\u0000\u0000\u0000\u04e1\u04e2\u0005"+
		"\u001b\u0000\u0000\u04e2\u04e3\u0005\u0002\u0000\u0000\u04e3\u04e5\u0003"+
		"\u009cN\u0000\u04e4\u04e6\u0005\u0014\u0000\u0000\u04e5\u04e4\u0001\u0000"+
		"\u0000\u0000\u04e5\u04e6\u0001\u0000\u0000\u0000\u04e6\u04e7\u0001\u0000"+
		"\u0000\u0000\u04e7\u04e8\u0007\b\u0000\u0000\u04e8\u04e9\u0005\u0003\u0000"+
		"\u0000\u04e9\u00b5\u0001\u0000\u0000\u0000\u04ea\u04eb\u0005\u001b\u0000"+
		"\u0000\u04eb\u04ec\u0005\u0002\u0000\u0000\u04ec\u04ee\u0003n7\u0000\u04ed"+
		"\u04ef\u0005\u0014\u0000\u0000\u04ee\u04ed\u0001\u0000\u0000\u0000\u04ee"+
		"\u04ef\u0001\u0000\u0000\u0000\u04ef\u04f0\u0001\u0000\u0000\u0000\u04f0"+
		"\u04fc\u0003\u00d8l\u0000\u04f1\u04f2\u0005\u0002\u0000\u0000\u04f2\u04f7"+
		"\u0003\u00e8t\u0000\u04f3\u04f4\u0005\u0001\u0000\u0000\u04f4\u04f6\u0003"+
		"\u00e8t\u0000\u04f5\u04f3\u0001\u0000\u0000\u0000\u04f6\u04f9\u0001\u0000"+
		"\u0000\u0000\u04f7\u04f5\u0001\u0000\u0000\u0000\u04f7\u04f8\u0001\u0000"+
		"\u0000\u0000\u04f8\u04fa\u0001\u0000\u0000\u0000\u04f9\u04f7\u0001\u0000"+
		"\u0000\u0000\u04fa\u04fb\u0005\u0003\u0000\u0000\u04fb\u04fd\u0001\u0000"+
		"\u0000\u0000\u04fc\u04f1\u0001\u0000\u0000\u0000\u04fc\u04fd\u0001\u0000"+
		"\u0000\u0000\u04fd\u04fe\u0001\u0000\u0000\u0000\u04fe\u04ff\u0005\u0003"+
		"\u0000\u0000\u04ff\u00b7\u0001\u0000\u0000\u0000\u0500\u0501\u0005\u001b"+
		"\u0000\u0000\u0501\u0502\u0005\u0002\u0000\u0000\u0502\u0504\u0003n7\u0000"+
		"\u0503\u0505\u0005\u0014\u0000\u0000\u0504\u0503\u0001\u0000\u0000\u0000"+
		"\u0504\u0505\u0001\u0000\u0000\u0000\u0505\u0506\u0001\u0000\u0000\u0000"+
		"\u0506\u0507\u0005e\u0000\u0000\u0507\u0508\u0005\u0003\u0000\u0000\u0508"+
		"\u00b9\u0001\u0000\u0000\u0000\u0509\u050a\u00057\u0000\u0000\u050a\u050b"+
		"\u0005\u0002\u0000\u0000\u050b\u0510\u0003\u0106\u0083\u0000\u050c\u050d"+
		"\u0005\u0001\u0000\u0000\u050d\u050f\u0003\u00c4b\u0000\u050e\u050c\u0001"+
		"\u0000\u0000\u0000\u050f\u0512\u0001\u0000\u0000\u0000\u0510\u050e\u0001"+
		"\u0000\u0000\u0000\u0510\u0511\u0001\u0000\u0000\u0000\u0511\u0513\u0001"+
		"\u0000\u0000\u0000\u0512\u0510\u0001\u0000\u0000\u0000\u0513\u0514\u0005"+
		"\u0003\u0000\u0000\u0514\u00bb\u0001\u0000\u0000\u0000\u0515\u0516\u0005"+
		"0\u0000\u0000\u0516\u0517\u0005\u0002\u0000\u0000\u0517\u0518\u0003\u00be"+
		"_\u0000\u0518\u0519\u00056\u0000\u0000\u0519\u051a\u0003\u009eO\u0000"+
		"\u051a\u051b\u0005\u0003\u0000\u0000\u051b\u00bd\u0001\u0000\u0000\u0000"+
		"\u051c\u051d\u0003\u00d8l\u0000\u051d\u00bf\u0001\u0000\u0000\u0000\u051e"+
		"\u051f\u00050\u0000\u0000\u051f\u0520\u0005\u0002\u0000\u0000\u0520\u0521"+
		"\u0003\u00c2a\u0000\u0521\u0522\u00056\u0000\u0000\u0522\u0523\u0003\u009e"+
		"O\u0000\u0523\u0524\u0005\u0003\u0000\u0000\u0524\u00c1\u0001\u0000\u0000"+
		"\u0000\u0525\u0526\u0003\u00d8l\u0000\u0526\u00c3\u0001\u0000\u0000\u0000"+
		"\u0527\u052c\u0003\u00dcn\u0000\u0528\u052c\u00032\u0019\u0000\u0529\u052c"+
		"\u0003\u00deo\u0000\u052a\u052c\u0003n7\u0000\u052b\u0527\u0001\u0000"+
		"\u0000\u0000\u052b\u0528\u0001\u0000\u0000\u0000\u052b\u0529\u0001\u0000"+
		"\u0000\u0000\u052b\u052a\u0001\u0000\u0000\u0000\u052c\u00c5\u0001\u0000"+
		"\u0000\u0000\u052d\u0532\u0003\u00c8d\u0000\u052e\u0532\u0003\u00ccf\u0000"+
		"\u052f\u0532\u0003\u00d2i\u0000\u0530\u0532\u0003\u00d4j\u0000\u0531\u052d"+
		"\u0001\u0000\u0000\u0000\u0531\u052e\u0001\u0000\u0000\u0000\u0531\u052f"+
		"\u0001\u0000\u0000\u0000\u0531\u0530\u0001\u0000\u0000\u0000\u0532\u00c7"+
		"\u0001\u0000\u0000\u0000\u0533\u0534\u0005\u001a\u0000\u0000\u0534\u0538"+
		"\u0003\u00cae\u0000\u0535\u0537\u0003\u00cae\u0000\u0536\u0535\u0001\u0000"+
		"\u0000\u0000\u0537\u053a\u0001\u0000\u0000\u0000\u0538\u0536\u0001\u0000"+
		"\u0000\u0000\u0538\u0539\u0001\u0000\u0000\u0000\u0539\u053b\u0001\u0000"+
		"\u0000\u0000\u053a\u0538\u0001\u0000\u0000\u0000\u053b\u053c\u0005*\u0000"+
		"\u0000\u053c\u053d\u0003n7\u0000\u053d\u053e\u0005)\u0000\u0000\u053e"+
		"\u00c9\u0001\u0000\u0000\u0000\u053f\u0540\u0005q\u0000\u0000\u0540\u0541"+
		"\u0003p8\u0000\u0541\u0542\u0005g\u0000\u0000\u0542\u0543\u0003n7\u0000"+
		"\u0543\u00cb\u0001\u0000\u0000\u0000\u0544\u0545\u0005\u001a\u0000\u0000"+
		"\u0545\u0546\u0003\u00ceg\u0000\u0546\u054a\u0003\u00d0h\u0000\u0547\u0549"+
		"\u0003\u00d0h\u0000\u0548\u0547\u0001\u0000\u0000\u0000\u0549\u054c\u0001"+
		"\u0000\u0000\u0000\u054a\u0548\u0001\u0000\u0000\u0000\u054a\u054b\u0001"+
		"\u0000\u0000\u0000\u054b\u054d\u0001\u0000\u0000\u0000\u054c\u054a\u0001"+
		"\u0000\u0000\u0000\u054d\u054e\u0005*\u0000\u0000\u054e\u054f\u0003n7"+
		"\u0000\u054f\u0550\u0005)\u0000\u0000\u0550\u00cd\u0001\u0000\u0000\u0000"+
		"\u0551\u0554\u00032\u0019\u0000\u0552\u0554\u0003\u00aaU\u0000\u0553\u0551"+
		"\u0001\u0000\u0000\u0000\u0553\u0552\u0001\u0000\u0000\u0000\u0554\u00cf"+
		"\u0001\u0000\u0000\u0000\u0555\u0556\u0005q\u0000\u0000\u0556\u0557\u0003"+
		"n7\u0000\u0557\u0558\u0005g\u0000\u0000\u0558\u0559\u0003n7\u0000\u0559"+
		"\u00d1\u0001\u0000\u0000\u0000\u055a\u055b\u0005\u001d\u0000\u0000\u055b"+
		"\u055c\u0005\u0002\u0000\u0000\u055c\u055f\u0003n7\u0000\u055d\u055e\u0005"+
		"\u0001\u0000\u0000\u055e\u0560\u0003n7\u0000\u055f\u055d\u0001\u0000\u0000"+
		"\u0000\u0560\u0561\u0001\u0000\u0000\u0000\u0561\u055f\u0001\u0000\u0000"+
		"\u0000\u0561\u0562\u0001\u0000\u0000\u0000\u0562\u0563\u0001\u0000\u0000"+
		"\u0000\u0563\u0564\u0005\u0003\u0000\u0000\u0564\u00d3\u0001\u0000\u0000"+
		"\u0000\u0565\u0566\u0005S\u0000\u0000\u0566\u0567\u0005\u0002\u0000\u0000"+
		"\u0567\u0568\u0003n7\u0000\u0568\u0569\u0005\u0001\u0000\u0000\u0569\u056a"+
		"\u0003n7\u0000\u056a\u056b\u0005\u0003\u0000\u0000\u056b\u00d5\u0001\u0000"+
		"\u0000\u0000\u056c\u056f\u0005u\u0000\u0000\u056d\u056f\u0003\u0108\u0084"+
		"\u0000\u056e\u056c\u0001\u0000\u0000\u0000\u056e\u056d\u0001\u0000\u0000"+
		"\u0000\u056f\u00d7\u0001\u0000\u0000\u0000\u0570\u0573\u0005v\u0000\u0000"+
		"\u0571\u0573\u0007\t\u0000\u0000\u0572\u0570\u0001\u0000\u0000\u0000\u0572"+
		"\u0571\u0001\u0000\u0000\u0000\u0573\u00d9\u0001\u0000\u0000\u0000\u0574"+
		"\u0575\u0003\u00fc~\u0000\u0575\u00db\u0001\u0000\u0000\u0000\u0576\u057e"+
		"\u0005w\u0000\u0000\u0577\u057e\u0005x\u0000\u0000\u0578\u057e\u0005z"+
		"\u0000\u0000\u0579\u057e\u0005y\u0000\u0000\u057a\u057e\u0005{\u0000\u0000"+
		"\u057b\u057e\u0003\u00eau\u0000\u057c\u057e\u0003\u00e4r\u0000\u057d\u0576"+
		"\u0001\u0000\u0000\u0000\u057d\u0577\u0001\u0000\u0000\u0000\u057d\u0578"+
		"\u0001\u0000\u0000\u0000\u057d\u0579\u0001\u0000\u0000\u0000\u057d\u057a"+
		"\u0001\u0000\u0000\u0000\u057d\u057b\u0001\u0000\u0000\u0000\u057d\u057c"+
		"\u0001\u0000\u0000\u0000\u057e\u00dd\u0001\u0000\u0000\u0000\u057f\u0580"+
		"\u0005\r\u0000\u0000\u0580\u0584\u0005z\u0000\u0000\u0581\u0582\u0005"+
		"\u000e\u0000\u0000\u0582\u0584\u0003\u00d8l\u0000\u0583\u057f\u0001\u0000"+
		"\u0000\u0000\u0583\u0581\u0001\u0000\u0000\u0000\u0584\u00df\u0001\u0000"+
		"\u0000\u0000\u0585\u0586\u0003\u009cN\u0000\u0586\u00e1\u0001\u0000\u0000"+
		"\u0000\u0587\u0588\u0005w\u0000\u0000\u0588\u00e3\u0001\u0000\u0000\u0000"+
		"\u0589\u058a\u0003\u00d8l\u0000\u058a\u00e5\u0001\u0000\u0000\u0000\u058b"+
		"\u058f\u0005u\u0000\u0000\u058c\u058f\u0003\u00eew\u0000\u058d\u058f\u0003"+
		"\u0108\u0084\u0000\u058e\u058b\u0001\u0000\u0000\u0000\u058e\u058c\u0001"+
		"\u0000\u0000\u0000\u058e\u058d\u0001\u0000\u0000\u0000\u058f\u00e7\u0001"+
		"\u0000\u0000\u0000\u0590\u0591\u0007\n\u0000\u0000\u0591\u00e9\u0001\u0000"+
		"\u0000\u0000\u0592\u0593\u0007\u000b\u0000\u0000\u0593\u00eb\u0001\u0000"+
		"\u0000\u0000\u0594\u0595\u00030\u0018\u0000\u0595\u00ed\u0001\u0000\u0000"+
		"\u0000\u0596\u0597\u0007\f\u0000\u0000\u0597\u00ef\u0001\u0000\u0000\u0000"+
		"\u0598\u0599\u0003\u00d8l\u0000\u0599\u00f1\u0001\u0000\u0000\u0000\u059a"+
		"\u059b\u0003\u00d8l\u0000\u059b\u00f3\u0001\u0000\u0000\u0000\u059c\u059f"+
		"\u0003\u00d8l\u0000\u059d\u059f\u0003\u010a\u0085\u0000\u059e\u059c\u0001"+
		"\u0000\u0000\u0000\u059e\u059d\u0001\u0000\u0000\u0000\u059f\u00f5\u0001"+
		"\u0000\u0000\u0000\u05a0\u05a3\u0003\u00d8l\u0000\u05a1\u05a3\u0003\u010a"+
		"\u0085\u0000\u05a2\u05a0\u0001\u0000\u0000\u0000\u05a2\u05a1\u0001\u0000"+
		"\u0000\u0000\u05a3\u00f7\u0001\u0000\u0000\u0000\u05a4\u05a7\u0003\u00d8"+
		"l\u0000\u05a5\u05a7\u0003\u010a\u0085\u0000\u05a6\u05a4\u0001\u0000\u0000"+
		"\u0000\u05a6\u05a5\u0001\u0000\u0000\u0000\u05a7\u00f9\u0001\u0000\u0000"+
		"\u0000\u05a8\u05ab\u0003\u00d8l\u0000\u05a9\u05ab\u0003\u010a\u0085\u0000"+
		"\u05aa\u05a8\u0001\u0000\u0000\u0000\u05aa\u05a9\u0001\u0000\u0000\u0000"+
		"\u05ab\u00fb\u0001\u0000\u0000\u0000\u05ac\u05b1\u0003\u010a\u0085\u0000"+
		"\u05ad\u05ae\u0005\u0004\u0000\u0000\u05ae\u05b0\u0003\u010a\u0085\u0000"+
		"\u05af\u05ad\u0001\u0000\u0000\u0000\u05b0\u05b3\u0001\u0000\u0000\u0000"+
		"\u05b1\u05af\u0001\u0000\u0000\u0000\u05b1\u05b2\u0001\u0000\u0000\u0000"+
		"\u05b2\u00fd\u0001\u0000\u0000\u0000\u05b3\u05b1\u0001\u0000\u0000\u0000"+
		"\u05b4\u05b5\u0003\u00d8l\u0000\u05b5\u00ff\u0001\u0000\u0000\u0000\u05b6"+
		"\u05b7\u0003\u00d8l\u0000\u05b7\u0101\u0001\u0000\u0000\u0000\u05b8\u05b9"+
		"\u0003\u00deo\u0000\u05b9\u0103\u0001\u0000\u0000\u0000\u05ba\u05bb\u0003"+
		"\u00deo\u0000\u05bb\u0105\u0001\u0000\u0000\u0000\u05bc\u05bd\u0003\u00ee"+
		"w\u0000\u05bd\u0107\u0001\u0000\u0000\u0000\u05be\u05c1\u0005u\u0000\u0000"+
		"\u05bf\u05c1\u0003\u00deo\u0000\u05c0\u05be\u0001\u0000\u0000\u0000\u05c0"+
		"\u05bf\u0001\u0000\u0000\u0000\u05c1\u0109\u0001\u0000\u0000\u0000\u05c2"+
		"\u05c5\u0005v\u0000\u0000\u05c3\u05c5\u0007\r\u0000\u0000\u05c4\u05c2"+
		"\u0001\u0000\u0000\u0000\u05c4\u05c3\u0001\u0000\u0000\u0000\u05c5\u010b"+
		"\u0001\u0000\u0000\u0000\u0094\u0112\u0117\u011a\u011d\u0120\u0124\u0128"+
		"\u0130\u0135\u013a\u013c\u0141\u0148\u014c\u0154\u0157\u016e\u0177\u0183"+
		"\u018d\u0197\u01a3\u01af\u01b3\u01bb\u01be\u01c6\u01c9\u01d8\u01e5\u01e8"+
		"\u01f0\u01f6\u01fd\u0202\u020a\u0210\u0213\u0217\u021e\u0223\u0226\u0232"+
		"\u023c\u0246\u024b\u0253\u0258\u025d\u0269\u026e\u027a\u0280\u0283\u0286"+
		"\u028e\u0291\u0294\u029b\u029f\u02a5\u02ab\u02af\u02b9\u02c1\u02c4\u02cb"+
		"\u02dd\u02e4\u02ec\u02f5\u02ff\u030a\u030e\u0317\u0321\u0325\u032e\u0337"+
		"\u033e\u0342\u0345\u034e\u0358\u0361\u0365\u036b\u036f\u0373\u037a\u0380"+
		"\u0384\u038b\u0390\u0393\u03a3\u03a9\u03b0\u03b6\u03bc\u03c2\u03cc\u03d4"+
		"\u03de\u03e9\u03ed\u0402\u0411\u041e\u0429\u0433\u0437\u043b\u0440\u0447"+
		"\u0457\u049e\u04aa\u04b5\u04c1\u04c8\u04cb\u04ce\u04dd\u04e5\u04ee\u04f7"+
		"\u04fc\u0504\u0510\u052b\u0531\u0538\u054a\u0553\u0561\u056e\u0572\u057d"+
		"\u0583\u058e\u059e\u05a2\u05a6\u05aa\u05b1\u05c0\u05c4";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}