package org.springframework.data.jpa.domain;

import jakarta.annotation.Generated;
import jakarta.persistence.metamodel.MappedSuperclassType;
import jakarta.persistence.metamodel.SingularAttribute;
import jakarta.persistence.metamodel.StaticMetamodel;
import java.io.Serializable;

@StaticMetamodel(AbstractPersistable.class)
@Generated("org.hibernate.processor.HibernateProcessor")
public abstract class AbstractPersistable_ {

	public static final String ID = "id";

	
	/**
	 * @see org.springframework.data.jpa.domain.AbstractPersistable#id
	 **/
	public static volatile SingularAttribute<AbstractPersistable, Serializable> id;
	
	/**
	 * @see org.springframework.data.jpa.domain.AbstractPersistable
	 **/
	public static volatile MappedSuperclassType<AbstractPersistable> class_;

}

